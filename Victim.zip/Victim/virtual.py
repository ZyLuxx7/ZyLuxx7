import os
import sys
import subprocess
import platform

def is_virtual_machine():
    # 1. Bekannte VM-Dateipfade prüfen (Linux/Unix Fokus)
    vm_files = [
        '/usr/bin/qemu-ga',
        '/usr/sbin/VBoxService',
        '/sys/class/dmi/id/product_name',
    ]
    
    for path in vm_files:
        if os.path.exists(path):
            with open(path, 'r') as f:
                content = f.read().lower()
                if any(x in content for x in ['virtualbox', 'vmware', 'qemu', 'kvm']):
                    return True

    # 2. System-Informationen via 'dmidecode' oder 'systeminfo' (Plattformübergreifend)
    system_type = ""
    try:
        if platform.system() == "Windows":
            # Prüft das Modell via WMIC
            output = subprocess.check_output("wmic computersystem get model", shell=True).decode()
            system_type = output.lower()
        else:
            # Prüft via hostnamectl oder dmidecode auf Linux
            output = subprocess.check_output("hostnamectl", shell=True).decode()
            system_type = output.lower()
    except:
        pass

    vm_keywords = ['virtualbox', 'vmware', 'kvm', 'qemu', 'microsoft corporation', 'xen', 'virtual']
    if any(k in system_type for k in vm_keywords):
        return True

    # 3. MAC-Adressen-Check (OUI)
    # VMs nutzen oft spezifische Präfixe (z.B. 08:00:27 für VirtualBox)
    try:
        import uuid
        mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) for ele in range(0, 8*6, 8)][::-1])
        vm_mac_prefixes = ['08:00:27', '00:05:69', '00:0c:29', '00:50:56', '00:15:5d']
        if any(mac.startswith(p) for p in vm_mac_prefixes):
            return True
    except:
        pass

    return False

def rollback_artifacts():
    print("[*] Rollback startet: sauber machen...")
    candidates = [
        r"C:\Temp\sysdata.dat",
        r"C:\Temp\syslog.dat",
        r"C:\Temp\resp_E.dat",
    ]

    for path in candidates:
        try:
            if os.path.isfile(path):
                os.remove(path)
                print(f"[+] Entferne Datei: {path}", flush=True)
        except Exception as e:
            print(f"[!] Fehler beim Entfernen {path}: {e}", flush=True)

    temp_dir = r"C:\Temp"
    try:
        if os.path.isdir(temp_dir) and not os.listdir(temp_dir):
            os.rmdir(temp_dir)
            print(f"[+] Entferne leeres Verzeichnis: {temp_dir}", flush=True)
    except Exception as e:
        print(f"[!] Fehler beim Entfernen Ordner {temp_dir}: {e}", flush=True)


def main():
    print("Prüfe Systemumgebung...")

    if is_virtual_machine():
        print("[-] Virtuelle Maschine erkannt! Programm wird beendet und Rollback wird durchgeführt.", flush=True)
        rollback_artifacts()
        sys.exit(1)

    print("[+] Echte Hardware erkannt. Fahre fort...", flush=True)


if __name__ == "__main__":
    main()