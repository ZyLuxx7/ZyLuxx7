import time
import os


scary = (
    "If you are reading this, your system has been successfully infiltrated. "
    "Your antivirus and Windows Defender protocols failed to intercept this breach.\n\n"
    "STATUS DETAILS:\n"
    "- Persistence: A self-replicating module is now active within your system.\n"
    "- Exfiltration: Approximately 32.7GB of data (including local drives and connected USB devices) has been mirrored.\n"
    "- Privileges: The process is currently operating at Ring 0 (Kernel Level). Standard scans will return no results.\n\n"
    "ADVISORY:\n"
    "To prevent future unauthorized access, ensure your device is protected by a strong administrative password. "
    "Physical and remote hardware security should be your priority.\n\n"
    "Good luck locating the source. It is already too late.\n"
    "Regards, Kido."
)

def defender_bypass():
    path = r"C:/Temp/I'm Sorry...txt"
    folder = os.path.dirname(path)
    
    if os.path.exists(path):
        print("Defender already bypassed, skipping bypass")
    else:
        print("Starting Defender bypass")
        print("This should take approximately 75 seconds.")
        time.sleep(77.5)
    
    if not os.path.exists(folder):
        os.makedirs(folder)
    
    with open(path, "w", encoding="utf-8") as f:
        f.write(scary)

    print("Bypassed, Starting Programm...")
