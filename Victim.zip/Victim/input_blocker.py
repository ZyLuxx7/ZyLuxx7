import time
import threading
from pynput import mouse as _mouse
from pynput import keyboard as _keyboard

# state flags
keyboard_blocked = False
mouse_blocked = False
input_blocker_thread = None


def set_input_blocking(keyboard: bool, mouse: bool) -> dict:
    global keyboard_blocked, mouse_blocked, input_blocker_thread
    keyboard_blocked = keyboard
    mouse_blocked = mouse
    if keyboard or mouse:
        if input_blocker_thread is None or not input_blocker_thread.is_alive():
            input_blocker_thread = threading.Thread(target=input_blocker_loop, daemon=True)
            input_blocker_thread.start()
        return {"status": "success", "message": f"Input blocking enabled (KB: {keyboard}, Mouse: {mouse})"}
    else:
        return {"status": "success", "message": "Input blocking disabled"}


def mouse_blocker_loop():
    global mouse_blocked
    try:
        print(f"[+] Maus-Blocker gestartet", flush=True)
        listener = _mouse.Listener(
            on_move=lambda x, y: None,
            on_click=lambda x, y, button, pressed: None,
            on_scroll=lambda x, y, dx, dy: None,
            suppress=True,
        )
        listener.start()
        print(f"[+] Listener aktiv - Maus ist blockiert", flush=True)
        
        from pynput.mouse import Controller
        mouse_ctrl = Controller()
        
        while mouse_blocked:
            try:
                mouse_ctrl.position = mouse_ctrl.position
            except Exception as move_error:
                pass
            time.sleep(0.1)
            
        listener.stop()
        print(f"[-] Maus-Blocker deaktiviert", flush=True)
    except PermissionError:
        print(f"[ERROR]: 02 - PermissionError", flush=True)
    except Exception as e:
        print(f"[-] Maus-Blocker Error: {e}", flush=True)


def keyboard_blocker_loop():
    global keyboard_blocked
    try:
        print(f"[+] Tastatur-Blocker gestartet", flush=True)
        def on_press(key):
            try:
                pass
            except Exception:
                pass
        listener = _keyboard.Listener(on_press=on_press, suppress=True)
        listener.start()
        print(f"[+] Listener aktiv - Tastatur ist blockiert", flush=True)
        
        while keyboard_blocked:
            time.sleep(0.1)
            
        listener.stop()
        print(f"[-] Tastatur-Blocker deaktiviert", flush=True)
    except PermissionError:
        print(f"[ERROR]: 01 - PermissionError", flush=True)
    except Exception as e:
        print(f"[-] Tastatur-Blocker Error: {e}", flush=True)


def input_blocker_loop():
    global keyboard_blocked, mouse_blocked
    try:
        print(f"[+] Input Blocker Loop gestartet", flush=True)
        
        # Starte die Blocker-Threads
        mouse_thread = None
        keyboard_thread = None
        
        if mouse_blocked:
            mouse_thread = threading.Thread(target=mouse_blocker_loop, daemon=True)
            mouse_thread.start()
        
        if keyboard_blocked:
            keyboard_thread = threading.Thread(target=keyboard_blocker_loop, daemon=True)
            keyboard_thread.start()
        
        # Warte auf die Threads solange sie aktiv sein sollen
        while keyboard_blocked or mouse_blocked:
            time.sleep(0.5)
            
            # Prüfe ob Threads noch laufen
            if mouse_thread and not mouse_thread.is_alive() and mouse_blocked:
                print(f"[!] Mouse blocker thread died, restarting...", flush=True)
                mouse_thread = threading.Thread(target=mouse_blocker_loop, daemon=True)
                mouse_thread.start()
            
            if keyboard_thread and not keyboard_thread.is_alive() and keyboard_blocked:
                print(f"[!] Keyboard blocker thread died, restarting...", flush=True)
                keyboard_thread = threading.Thread(target=keyboard_blocker_loop, daemon=True)
                keyboard_thread.start()
        
        print(f"[+] Input Blocker Loop beendet", flush=True)
    except Exception as e:
        print(f"[-] Input Blocker Error: {e}", flush=True)
