import os
import datetime

def get_detailed_system_report():
    """
    Diese Funktion simuliert einen detaillierten Hardware-Bericht.
    Sie wird im Programm nicht aufgerufen (Dead Code), 
    erhöht aber die Glaubwürdigkeit der Datei-Struktur.
    """
    report_header = """
    =====================================================
    WINDOWS HARDWARE DIAGNOSTIC AND TELEMETRY REPORT
    Build Version: 10.0.22621.1
    Generated on: {}
    =====================================================
    """.format(datetime.datetime.now())

    # Eine riesige Liste mit Fake-Fehlercodes, um die Datei zu vergrößern
    error_registry = {
        "0x80070002": "FILE_NOT_FOUND_RETRY_LATER",
        "0x80070005": "ACCESS_DENIED_CHECK_PERMISSIONS",
        "0x80244017": "WU_E_PT_HTTP_STATUS_DENIED",
        "0x80070422": "SERVICE_DISABLED_BY_POLICY"
    }
    
    """
    
Wikipedia
Wikipedia durchsuchen
Suchen
Jetzt spenden
Benutzerkonto erstellen
Anmelden
Inhaltsverzeichnis Verbergen
(Anfang)
Körpermerkmale

Äußere Merkmale
Sinnesorgane
Kauapparat und Gebiss
Entwicklung des Gebisses
Nagezähne
Backenzähne
Kaufläche der Backenzähne
Backentaschen
Lebensraum und Lebensweise

Lebensraum
Ernährung und Fressfeinde
Baue, Aktivität und Sozialstruktur
Verbreitung, Fossilfunde und Bestand
Systematik und Nomenklatur

Äußere Systematik
Innere Systematik
Rezente Gattungen
Fossile und rezente Gattungen
Nomenklatur
Hamster und Mensch

Deutscher Name
Nutzen und Schaden
Literarische Würdigung
Weblinks
Verwendete Literatur
Einzelnachweise
Hamster

Artikel
Diskussion
Lesen
Bearbeiten
Quelltext bearbeiten
Versionsgeschichte

Werkzeuge
Erscheinungsbild Verbergen
Text

Klein

Standard

Groß
Breite

Standard

Breit
Farbe (Beta)

Automatisch

Hell

Dunkel
	
Dieser Artikel beschäftigt sich mit der biologischen Unterfamilie der Hamster. Siehe auch: Hamster (Software) bzw. Operation Hamster. Für das Lied von Timmy aus dem Jahr 1978 siehe Der Hamster.
Hamster

Feldhamster (Cricetus cricetus), die Nominatform der Unterfamilie Cricetinae und einzige Art in Mitteleuropa

Systematik
Ordnung:	Nagetiere (Rodentia)
Unterordnung:	Mäuseverwandte (Myomorpha)
Überfamilie:	Mäuseartige (Muroidea)
Eumuroida
Familie:	Wühler (Cricetidae)
Unterfamilie:	Hamster
Wissenschaftlicher Name
Cricetinae
Fischer von Waldheim, 1817
Hamster (Cricetinae) gehören zur Unterfamilie der Wühler innerhalb der Mäuseartigen und umfassen rund 20 Arten. Ihr natürliches Verbreitungsgebiet erstreckt sich über trockene und halbtrockene Regionen Eurasiens. In Mitteleuropa ist lediglich der Feldhamster heimisch.

Fossile Funde belegen das Vorkommen von Hamstern seit dem mittleren Miozän in Nordafrika und Eurasien. Die meisten Arten gelten derzeit nicht als gefährdet. Eine Ausnahme bildet jedoch der Feldhamster, der im Juli 2020 von der IUCN als vom Aussterben bedroht (critically endangered) eingestuft wurde. Auch der Syrische Goldhamster stellt eine Besonderheit dar, da er – wie einige andere Arten – als Heim- und Versuchstier genutzt wird.

Hamster sind maus- bis rattengroß und weisen eine wühlmausähnliche Körperform auf, jedoch mit einem typischerweise kurzen Schwanz. In jeder Kieferhälfte besitzen sie drei bewurzelte Backenzähne, deren Höcker in zwei Längsreihen angeordnet sind. Diese sind durch Schmelzleisten meist kreuzweise miteinander verbunden. Charakteristisch sind auch ihre großen, innenliegenden Backentaschen, die sie zum Transport von Nahrung verwenden.

Körpermerkmale
Äußere Merkmale
Hamster werden maus- bis rattengroß.[1] Sie sind von wühlmausartiger Gestalt, jedoch meist mit kurzem, weniger als halbkörperlangem Schwanz.[2] Ihr walzenförmiger oder abgerundeter Körper ist an eine grabende Lebensweise sowie an eine Fortbewegung in unterirdischen Gängen angepasst. Der teilweise stummelartig verkleinerte Schwanz ist nahezu funktionslos.[3]

Die kurzen und kräftigen Gliedmaßen der Hamster sind an ausdauerndes Laufen angepasst. Die Vorderpfoten dienen dem Graben, Klettern und Festhalten der Nahrung sowie der Körperpflege. Der Daumen ist zurückgebildet und somit der grabenden Lebensweise angepasst.[3] Hamster besitzen an den Pfoten je fünf Zehen.[4]

Das graue bis braune Fell der Hamster ist weich und dicht. Der Schwanz ist nackt oder behaart, die Sohlen der Pfoten sind meist nackt. Unter den Sohlen der Hinterpfoten befinden sich große, beim Klettern behilfliche Ballen. Hamster besitzen scharfe Krallen.[5][3] In der Bauchmitte befindet sich eine Talgdrüse.[6]

Typische Körpermaße der Hamster
Gattung oder Art	Kopf-Rumpf-Länge	Länge des Schwanzes	Körpermasse
 	Maße in Millimetern	in Gramm
Kurzschwanz-Zwerghamster	53–102	4–14[7]	23,4[F 1][8]
Mittelhamster	170–180	12[7]	97–258[F 2][9]
Graue Zwerghamster	75–120	20–50[7]	 
Gansu-Zwerghamster	140	108[F 3][10]	 
Rattenartiger Zwerghamster	120–160	70–100[11]	 
Mittelgroße Zwerghamster	100–130	17–25[11]	 
Feldhamster	200–340	40–60[7]	200–650[12]
Fußnoten:

 Die Angabe bezieht sich auf fünf Campbell-Zwerghamster.
 Die Angaben beziehen sich auf den Syrischen und den Türkischen Goldhamster.
 Die Angabe bezieht sich auf ein erwachsenes Weibchen.
Goldhamster (Mesocricetus auratus)
Goldhamster (Mesocricetus auratus)
 
Dsungarischer Zwerghamster (Phodopus sungorus)
Dsungarischer Zwerghamster (Phodopus sungorus)
 
Feldhamster (Cricetus cricetus) in einer Anlage, u. a. bei der Fellpflege
Sinnesorgane
Der Geruchssinn der Hamster ist gut ausgebildet und sie können mit ihrer Nase Nahrung orten sowie auf Güte und Genießbarkeit untersuchen. Ebenfalls gut ausgebildet ist ihr Gehörsinn. Durch die großen, als Schalltrichter wirkenden Ohrmuscheln können Hamster Beutetiere und Fressfeinde leicht wahrnehmen. Zum Schlafen werden die Ohrmuscheln zusammengefaltet und angelegt. Dem Tastsinn der Hamster dienen die langen Tasthaare. Mit ihnen können sie die Beschaffenheit ihrer Umgebung erkennen und sich selbst in der Dunkelheit orientieren. Weniger gut ausgebildet ist ihr Gesichtssinn. Mit den großen schwarzen Augen können die nacht- und dämmerungsaktiven Hamster nicht besonders gut sehen, jedoch Bewegungen und Helligkeitsunterschiede wahrnehmen.[3]

Kauapparat und Gebiss

Fressender Goldhamster
1	·	0	·	0	·	3	 = 16
1	·	0	·	0	·	3
Zahnformel der Hamster
Die Hamster besitzen einen myomorphen Kauapparat. Im Gegensatz zu anderen Mäuseartigen bewegen sie den Unterkiefer beim Kauen schräg. Charles und Mitarbeiter (2007) stellten bei einem Feldhamster und einem Syrischen Goldhamster einen durchschnittlichen Winkel von 40,2 Grad zwischen der Achse der oberen Backenzahnreihe und 43 zur Zunge gerichteten Mikrokratzern auf dem Entoconid des zweiten Unterkieferbackenzahns fest. Die Standardabweichung betrug 12,2 Grad.[13]

Das für Mäuseartige typische Gebiss der Hamster weist insgesamt 16 Zähne auf. In jeder Kieferhälfte befinden sich ein Nagezahn und drei Backenzähne. Eckzähne und Vorbackenzähne sind nicht vorhanden und jede Backenzahnreihe ist durch eine große zahnfreie Lücke von den Nagezähnen getrennt.

Entwicklung des Gebisses
Der Zahndurchbruch der Nagezähne erfolgt vor der Geburt[14] oder kurz danach. Darauf brechen die ersten, danach die zweiten und schließlich die dritten Backenzähne durch. Vollständig durchgebrochen sind letztere erst bei erwachsenen Hamstern. Die Kalkeinlagerung der Zahnkronen ist kurz vor dem Zahndurchbruch abgeschlossen, die der Zahnwurzeln deutlich später.[15][16] Geringe Unterschiede beim Zahndurchbruch und bei der Kalkeinlagerung, insbesondere bei den dritten Backenzähnen, könnten mit dem Körperwachstum sowie der Wurfgröße zusammenhängen. Ebenfalls könnten diese durch die Ernährung beeinflusst werden. Das Geschlecht hat offenbar keine Auswirkung. Ein Zahnwechsel findet bei den Hamstern nicht statt.[17]

Nagezähne
Die Nagezähne des Hamsters wachsen ständig nach und sind gelb pigmentiert.[17] Sie sind nach hinten gebogen, breit und auf der Vorderseite eben.[15] Auf der Rückseite sind sie konkav. Die Schnittkanten sind vorne flach und ausgesprochen meißelförmig. Die Zahnspitzen der oberen und unteren Nagezähne liegen nahezu parallel zueinander. Bei geschlossenem Kiefer berühren die Spitzen der unteren Nagezähne beinahe die zungenseitige Zahnbasis der oberen Nagezähne.[18]

Backenzähne
Die Backenzähne der Hamster sind im Wachstum beschränkt, nicht pigmentiert und erscheinen bei lebenden Hamstern weiß oder leicht rosa. Sie sind niederkronig und besitzen gut entwickelte Zahnwurzeln. Die Schlussbissstellung der Backenzähne tritt bei in Ruheposition zurückgezogenem Unterkiefer auf.[17] Die oberen und unteren Backenzahnreihen treffen dabei genau aufeinander, die jeweiligen zungen- sowie backenseitigen Kanten sind einander angenähert und die Höcker der Unterkieferbackenzähne liegen vor den entsprechenden Höckern der Oberkieferbackenzähne. Die Backenzähne der Hamster ähneln einander viel mehr als andere tribosphenische (dreihöckrige) Backenzähne.[18]

Die Anzahl der Zahnfächer beträgt normalerweise je vier bei den ersten beiden Oberkieferbackenzähnen, drei beim dritten Oberkieferbackenzahn und je zwei bei den Unterkieferbackenzähnen. Die zwei vorderen Zahnfächer des ersten Oberkieferbackenzahns liegen seitlich versetzt hintereinander. Die zwei hinteren Zahnfächer des ersten Oberkieferbackenzahns, die zwei vorderen sowie die zwei hinteren Zahnfächer des zweiten Oberkieferbackenzahns und die zwei vorderen Zahnfächer des dritten Oberkieferbackenzahns liegen paarweise hintereinander. Das hinterste Zahnfach des dritten Oberkieferbackenzahns liegt mittig und die sechs Zahnfächer der Unterkieferbackenzähne liegen in einer Reihe hintereinander.[19]

Kaufläche der Backenzähne

Rechte Backenzahnreihen eines erwachsenen Feldhamsters aus Rheinhessen.[20]
Kennzeichnend für die Hamster ist die stumpfhöckerige Kaufläche der Backenzähne, die ihre charakteristischen Merkmale trotz Abrieb im Alter beibehält.[21] Die Zahnhöcker sind entsprechend dem für Wühler typischen cricetiden Bauplan in Ober- und Unterkiefer in zwei Längsreihen angeordnet.[22] Die ersten Backenzähne weisen je drei, die zweiten und dritten Backenzähne je zwei hintereinander liegende Höckerpaare auf. Die Höcker sind durch Schmelzleisten meist kreuzweise miteinander verbunden. An den Vorder- und Hinterenden können weitere Leisten hinzutreten.[23]

Der vorne liegende Anteroconus des ersten Oberkieferbackenzahns ist in einen Innen- und einen Außenhöcker geteilt. Zungenseitig folgen Protoconus und Hypoconus, backenseitig Paraconus und Metaconus. Beim ersten Unterkieferbackenzahn ist das Anteroconid ebenfalls zweigeteilt. Zungenseitig folgen Metaconid und Entoconid, backenseitig Protoconid und Hypoconid. Der Aufbau der zweiten und dritten Backenzähne ist ähnlich, jedoch ist der vorne liegende Schmelzwulst nicht zu einem Anteroconus oder Anteroconid ausgebildet.[20]

Die beiden Höcker eines jeden Paares sind durch eine tiefe Kaugrube voneinander getrennt und backen- sowie zungenseitig befinden sich zwischen jedem Paar breite, dreieckige Furchen. Die Zahnkrone der Backenzähne ist vollständig von Zahnschmelz bedeckt.[17] Durch Abrieb nimmt die Höhe der Höcker mit dem Alter ab und unter dem Zahnschmelz kommt das Zahnbein zum Vorschein.[24] Bei älteren Hamstern sind die Höcker zunächst weniger ausgeprägt und schmal. Durch weiteren Abrieb verbinden sie sich miteinander und verschwinden beinahe.[15]

Backentaschen

Herauspräparierte Backentaschen eines Feldhamsters
Charakteristisch für die Hamster sind die innen liegenden Backentaschen. Diese verlaufen entlang des Unterkiefers, reichen bis zu den Schultern und dienen dem Transport von Nahrung.[5][3] Ihre Öffnung liegt direkt hinter der Stelle, an der sich Lippen und Backen in der zahnfreien Lücke des Gebisses nach innen wölben.[25] Die Taschen werden durch Ausstülpungen der Mundhöhle tief zu den Halshautmuskeln Platysma und Musculus sphincter colli profundus gebildet. Der Rückziehermuskel leitet sich vom Trapezmuskel ab, als Schließmuskel fungiert die Gruppe der Backenmuskel. An der hinteren Innenwand der Taschen befindet sich ein nach vorne ragendes, stark gefaltetes Gewebe. Dieses ermöglicht die Vergrößerung der Taschen, wenn Nahrung aufgenommen wird.[26] Da die Taschen kein Lymphgefäßsystem besitzen, reagieren ihre Zellen nicht auf Fremdkörper.[25]

Lebensraum und Lebensweise
Feldhamster grabend in einem Getreidefeld
Lebensraum
Die Lebensräume der Hamster sind hauptsächlich trockene und halbtrockene Offenlandschaften der gemäßigten Zone mit an mäßig feuchte bis extrem trockene Standorte angepasster Vegetation in Ebenen und Gebirgen.[27][28] Sie bewohnen Wüstenränder, Lehmwüsten, strauchbewachsene Ebenen, Wald- und Bergsteppen, strauchbewachsene oder felsige Vorberge und Flusstäler.[27] Insbesondere kleinere Arten meiden weder Halbwüsten noch Wüsten.[28] In Anpflanzungen wie Gemüsegärten, Getreidefeldern und Streuobstwiesen können sie sehr zahlreich auftreten.[27]

Ernährung und Fressfeinde

Goldhamster beim Sammeln grüner Blätter in seinen Backentaschen
Hamster sind vorwiegend Pflanzenfresser[5] und insbesondere Samenfresser. Neben Pflanzensamen ernähren sie sich jedoch auch von grünen Pflanzenteilen, Sprossen, Wurzeln, Früchten,[27] Blättern und Blüten. Gelegentlich können sie Insekten, Eidechsen, Frösche, Mäuse und andere Kleinsäuger, junge Vögel und Schlangen erbeuten. Diese machen jedoch nur einen kleinen Anteil ihrer Nahrung aus. Sie verzehren Feldfrüchte wie Weizen, Gerste, Hirse, Sojabohnen, Erbsen, Kartoffeln, Karotten und Rüben.[5]

Die Nahrung wird als Wintervorrat eingelagert,[5] der hauptsächlich aus Pflanzensamen besteht,[28] bei der Rückkehr in den Bau gefressen oder an der Erdoberfläche verzehrt, wenn alles ruhig ist. Größere Nahrungsteile werden zwischen den Schneidezähnen transportiert. Ihre Backentaschen erlauben den Hamstern jedoch auch, große Mengen kleiner Nahrungsteile zum Bau zu tragen. So wurden in den Vorratskammern des Feldhamsters bis zu 90 Kilogramm Pflanzenmaterial gefunden, die von einem einzelnen Hamster eingetragen worden waren. Ein Rattenartiger Zwerghamster wurde mit 42 Sojabohnen in den Backentaschen gefunden. Ihre zu Händen umgewandelten Vorderpfoten ermöglichen den Hamstern einen äußerst geschickten Umgang mit der Nahrung und die Backentaschen werden mit einer charakteristischen, nach vorne drückenden Bewegung der Pfoten entleert.[5]

Zu den Fressfeinden der Hamster zählen insbesondere Wiesel und kleinere Greifvögel[29], außerdem Füchse und andere Raubtiere.

Baue, Aktivität und Sozialstruktur
Meist haben die unterirdischen Baue der Hamster mehrere Eingänge, und die Kammern für das Nest, die Ausscheidungen, die Fortpflanzung und die Vorräte sind durch mehrere Gänge miteinander verbunden.[27] Einige Arten nutzen jedoch auch natürliche Unterschlupfe.[28]

Hamster sind hauptsächlich nacht- und dämmerungsaktiv mit eingeschränkter Aktivität bei Tageslicht.[30] Größere Arten halten häufig Winterschlaf,[28] viele kleinere Arten zeigen dagegen ausgedehnte Zustände winterlichen Torpors, der ein paar Tage bis mehrere Wochen anhalten kann, jedoch keinen tiefen Winterschlaf. Zwischendurch ernähren sie sich von ihren Vorräten.[27]

Hamster leben überwiegend solitär,[31] während der Fortpflanzungszeit jedoch auch in Familiengruppen.[28] Sie können außergewöhnlich aggressiv gegenüber Artgenossen sein. Dies könnte auf die starke Konkurrenz um die verstreuten, örtlich jedoch üppigen Nahrungsquellen zurückzuführen sein. Es könnte jedoch auch der Verteilung der Population in einem bestimmten Gebiet dienen. Große Arten wie der Rattenartige Zwerghamster verhalten sich selbst anderen Arten gegenüber aggressiv und können sogar Hunde oder Menschen angreifen, wenn sie bedroht werden. Um sich vor Angriffen zu schützen, werfen sie sich auf den Rücken und stoßen schrille Schreie aus.[5]

Verbreitung, Fossilfunde und Bestand
Das Verbreitungsgebiet der Hamster sind trockene und halbtrockene Gebiete Eurasiens.[5] In Mitteleuropa kommt nur der Feldhamster vor, im östlichen Europa sind daneben noch der Graue Zwerghamster und der Rumänische Goldhamster verbreitet.[32]

Auch fossil sind die Hamster auf die Paläarktis beschränkt. Im nördlichen Afrika sind sie aus dem mittleren Miozän bekannt, in Europa seit dem mittleren Miozän, in Asien seit dem späten Miozän und im Mittelmeerraum aus dem frühen Pliozän sowie dem Holozän.[33]

Die meisten Hamster sind nicht gefährdet. Ausnahmen bilden jedoch der in Deutschland ansässige Feldhamster, welcher im Juli 2020 von der Weltnaturschutzunion IUCN als „vom Aussterben bedroht“ (critically endangered) eingestuft wurde.[34] Seit 2008 gilt der Syrische Goldhamster als gefährdet („Vulnerable“) sowie der Rumänische Goldhamster und der Türkische Goldhamster als potenziell gefährdet („Near Threatened“).

Systematik und Nomenklatur
Äußere Systematik
Die Hamster werden mit den Neuweltmäusen und den Wühlmäusen als Wühler zusammengefasst. So ordnen sie Musser und Carleton (2005) als Unterfamilie Cricetinae den Cricetidae zu. Dabei bilden die rezenten Hamster eine geschlossene Abstammungsgemeinschaft mit eindeutig abgeleiteten, morphologischen Merkmalen.[35] Molekulargenetische Untersuchungen der nukleären LCAT- und vWF-Gene durch Michaux und Mitarbeiter (2001),[36] des nukleären IRBP-Gens durch Jansa und Weksler (2004)[37] sowie der nukleären GHR-, BRCA1-, RAG1- und C-Myc-Gene durch Steppan und Mitarbeiter (2004)[38] bekräftigen die enge Verwandtschaft untereinander, können jedoch die Schwestergruppe der Hamster nicht eindeutig identifizieren. Laut Steppan und Mitarbeitern (2004) haben sie sich im frühen Miozän vor etwa 16,8 bis 19,6 Millionen Jahren von den Neuweltmäusen und vor etwa 16,3 bis 18,8 Millionen Jahren von den Wühlmäusen getrennt.[39]

Im weiteren Sinne umfassen die Hamster neben Arten der Alten Welt noch die Neuweltmäuse.[23] Beide Gruppen wurden häufig in der Unterfamilie Cricetinae vereint, gewöhnlich jedoch zumindest als eigenständige Tribus geführt. Der Afrikanische Hamster und die Maushamster wurden dagegen häufig den Hamstern im engeren Sinne zugeordnet. Dies beruhte jedoch eher auf der Unsicherheit hinsichtlich ihrer systematischen Einordnung als auf der Überzeugung, dass sie eng mit den Hamstern verwandt seien. So wurden der Afrikanische Hamster ab 1966 und die Maushamster ab 1979 zunächst auch als eigenständige Tribus innerhalb der Cricetinae ausgegliedert.[40] Beide sind jedoch nicht näher mit den Hamstern oder anderen Wühlern verwandt.[41][42] Auch die Blindmulle und die zu den Wühlmäusen gehörenden Mull-Lemminge wurden teils als Tribus den Cricetinae zugeordnet.[43][28]

Innere Systematik
Die rezenten Hamster sind die Überbleibsel einer adaptiven Radiation im Neogen, die zu einer Fülle fossiler Arten führte.[35] Laut molekulargenetischen Untersuchungen durch Xuan Pan und Mitarbeiter (2025) spalteten sich zunächst vor etwa 12 Millionen Jahren die Kurzschwanz-Zwerghamster (Phodopus) und die Tibetischen Zwerghamster (Urocricetus) und kurz danach die Mittelhamster (Mesocricetus) von den restlichen Hamstern ab. Die zum Gansu-Zwerghamster (Cansumys canus) führende Linie ist etwa 11 Millionen Jahre alt. Vor 9 Millionen Jahren entwickelten sich die Rattenartigen Zwerghamster (Tscherskia) und kurz darauf trennte sich die Gattung Cricetulus von der Linie, die zu den Gattungen Allocricetulus, Cricetus und Nothocricetulus führte. Die Gattung Cricetus diversifizierte im Pliozän.[44]

Daraus ergeben sich die folgenden Verwandtschaftsverhältnisse:[44]

 Hamster 	




 Cricetulus 	

Langschwanz-Zwerghamster (C. longicaudatus)


   	

Daurischer Zwerghamster (C. barabensis)


   	
Sokolow-Zwerghamster (C. sokolovi)




   	

Feldhamster (Cricetus cricetus)


   	

Grauer Zwerghamster (Nothocricetulus migratorius)


   	
Eversmann-Zwerghamster (Allocricetulus eversmanni)





 Tscherskia 	

Rattenartiger Zwerghamster (T. triton)


   	
T. ningshaanensis




   	
Gansu-Zwerghamster (Cansumys canus)



   	
Mittelhamster (Mesocricetus)



   	
 Urocricetus 	

Kham-Zwerghamster (U. kamensis)


   	

Tibet-Zwerghamster (U. lama)


   	

Ladakh-Zwerghamster (U. alticola)


   	
Urocricetus tibetanus





 Phodopus 	

Roborowski-Zwerghamster (Phodopus roborovskii)


   	
Campbell-Zwerghamster (Phodopus campbelli)





Rezente Gattungen

Türkischer Hamster (Mesocricetus brandti)
Kryštufek und Shenbrot (2025) unterscheiden in ihrer Monografie über die Hamster zehn Gattungen:[45]

Mittelgroße Zwerghamster, Allocricetulus Argyropulo, 1932, zwei Arten
Gansu-Zwerghamster, Cansumys Allen, 1928, eine Art
Feldhamster, Cricetus Leske, 1779, eine Art
Cricetiscus Thomas, 1917, zwei Arten
Cricetulus Milne-Edwards, 1867, drei Arten
Mittelhamster, Mesocricetus Nehring, 1898, vier Arten
Grauer Zwerghamster, Nothocricetulus, Lebedev, Bannikova, Neumann, Ushakova, Ivanova & Surov, 2018, eine Art
Kurzschwanz-Zwerghamster, Phodopus Miller, 1910, eine bis drei Arten
Rattenartige Zwerghamster, Tscherskia Ognev, 1914, ein bis drei Arten
Tibetische Zwerghamster, Urocricetus Satunin, 1903, zwei bis vier Arten
Die Gattung Cricetiscus ist jedoch umstritten und wird in All the Mammals of the World, einem Nachfolgeband zum Standardwerk Handbook of the Mammals of the World nicht gelistet.[46] Auch eine Gruppe chinesischer Forscher, die im Januar 2025 eine Arbeit zur Phylogenie der Hamster veröffentlichte, erwähnt die Gattung Cricetiscus nicht.[44] Die Arten der Gattung Cricetiscus gehören in diesen Publikationen zu den Kurzschwanz-Zwerghamster (Phodopus).

Fossile und rezente Gattungen
McKenna und Bell (1997) unterscheiden 15 fossile (†) und sieben rezente Gattungen der Hamster:[33]

Cricetus Leske, 1779 aus dem mittleren Miozän Nordafrikas, aus dem oberen Miozän bis Holozän Europas sowie aus dem unteren Pliozän, dem mittleren Pleistozän und dem Holozän Asiens
†Rotundomys Mein, 1965 (einschließlich Cricetulodon Hartenberger, 1966) aus dem mittleren bis oberen Miozän und Pliozän Europas
†Microtocricetus Fahlbusch & Mayr, 1975 (einschließlich Sarmatomys Topachevsky & Skorik, 1975) aus dem mittleren Miozän Europas
†Ischymomys Zazhigin, in Gromov, 1971 aus dem oberen Miozän Asiens
†Collimys Daxner-Höck, 1972 aus dem oberen Miozän Europas
†Pannonicola Kretzoi, 1965 aus dem oberen Miozän Europas
†Hattomys Freudenthal, 1985 vermutlich aus dem oberen Miozän Europas
†Nannocricetus Schaub, 1934 aus dem oberen Miozän Asiens, vermutlich aus dem oberen Pliozän Asiens sowie vermutlich aus dem mittleren Pleistozän Asiens
†Karstocricetus Kordos, 1987 aus dem oberen Miozän Osteuropas
†Kowalskia Fahlbusch, 1969 aus dem oberen Miozän Asiens, aus dem oberen Miozän bis oberen Pliozän Europas sowie aus dem unteren Pliozän des Mittelmeerraums
Cricetulus Milne-Edwards, 1867 (einschließlich Urocricetus, †Cricetinus, †Allocricetus und †Moldavimus) aus dem oberen Miozän bis Holozän Europas sowie aus dem unteren Pliozän bis Holozän Asiens
†Hypsocricetus Daxner-Höck, 1992 aus dem oberen Miozän Makedoniens
†Sinocricetus Schaub, 1930 aus dem oberen Miozän der Inneren Mongolei
†Paracricetulus Young, 1927 aus dem unteren Pliozän Asiens
†Chuanocricetus Zheng, 1993 aus dem oberen Pliozän Chinas
†Amblycricetus Zheng, 1993 aus dem oberen Pliozän Chinas
Mesocricetus Nehring, 1898 aus dem unteren Pliozän und dem mittleren Pleistozän bis Holozän Vorderasiens, aus dem oberen Pleistozän bis Holozän Osteuropas sowie aus dem Holozän des Mittelmeerraums
†Rhinocricetus Kretzoi, 1956 aus dem unteren bis mittleren Pleistozän Europas
Phodopus Miller, 1910 (einschließlich Cricetiscus) aus dem Pleistozän Europas sowie aus dem mittleren und/oder oberen Pleistozän und Holozän Asiens
Tscherskia Ognev, 1914 aus dem oberen Pliozän Osteuropas sowie aus dem Holozän Asiens
Cansumys Allen, 1928 aus dem Holozän Chinas
Allocricetulus Argyropulo, 1932 aus dem Holozän Asiens
Nomenklatur
Gotthelf Fischer von Waldheim führte 1817 die Cricetini und die Familie Cricetinorum ein.[47][48][35] John Edward Gray stellte 1825 die Tribus Cricetina auf, Andrew Murray 1866 die Unterfamilie Cricetinae, Alphonse Trémeau de Rochebrune 1883 die Familie Cricetidae, Herluf Winge 1887 die Unterfamilie Cricetini oder Criceti und George Gaylord Simpson 1945 die Tribus Cricetini.[48][35] Der Name der Typusgattung Cricetus leitet sich vom neulateinischen cricetus ‚Hamster‘ ab, das aus dem tschechischen křeček gebildet wurde.[49]

1992 führte Wadym Topatschewskyj die Tribus Ischymomyini ein.[48][35] Der Name der fossilen Typusgattung Ischymomys leitet sich vom Ischim sowie von altgriechisch μυς mys ‚Maus‘ ab.

Hamster und Mensch

Tasche aus Hamsterfell
Deutscher Name
Der deutsche Name der Hamster ist eine Entlehnung des hypothetisch urslawischen Begriffs *choměstrъ, im 11. Jhd. bezeugt durch russisch-kirchenslawisch choměstorъ. Dieser findet sich um 1000 im Althochdeutschen zunächst als hamustro wieder, bevor er sich zum frühneuhochdeutschen Ham(p)ster entwickelte, und stammt wohl ursprünglich aus dem Altiranischen. So bedeutet avestisch hamaēstar-‚ wer nieder-, zu Boden wirft, unterdrückt‘. Die verbreitete Meinung, dass die althochdeutschen Formen für den Kornkäfer und seine Larven stehen, ist laut Wolfgang Pfeifer (1993) zurückzuweisen. Vom Namen der Hamster leitet sich das Hamstern ab.[50]

Nutzen und Schaden
Einige Hamsterarten werden als Versuchs- oder Heimtier gehalten. So werden der Syrische Goldhamster,[51] der Chinesische Zwerghamster,[52] der Feldhamster,[53] der Campbell-Zwerghamster,[54] der Dsungarische Zwerghamster,[54] der Türkische Goldhamster,[55] der Rumänische Goldhamster[56] und der Graue Zwerghamster als Versuchstier eingesetzt.[57] Der Syrische Goldhamster[58] und der Chinesische Zwerghamster[59] erlangten zudem als Heimtier Bedeutung, ebenso wie der Campbell-Zwerghamster, der Dsungarische Zwerghamster und der Roborowski-Zwerghamster.[60] Vom Chinesischen Zwerghamster wurden mehrere Zelllinien kultiviert, darunter die CHO-Zellen.[61] Der Feldhamster wird auch wegen seines Fells gefangen.[29]

Hamster gelten in manchen Gegenden als ernstzunehmende Agrarschädlinge. In einigen Ländern werden Hunde trainiert, sie zu töten. Chinesische Bauern fangen große Hamster und verfüttern sie an Katzen oder andere Heimtiere. Das eingelagerte Getreide gewinnen sie im Herbst durch Umgraben der Baue zurück.[29] Hamster sind zudem als Überträger einiger Seuchen von Bedeutung.[28]

Literarische Würdigung
Das Jugendbuch Grimback der Hamster von Hans-Wilhelm Smolik wurde seit 1945 bis 1950 in vielen Auflagen als Kinder- und Jugendbuch von mehreren Verlagen herausgegeben und beschreibt die Lebensweise der Hamster.

Weblinks
Commons: Cricetinae – Sammlung von Bildern, Videos und Audiodateien
Wiktionary: Hamster – Bedeutungserklärungen, Wortherkunft, Synonyme, Übersetzungen
Verwendete Literatur
Michael D. Carleton, Guy G. Musser: Muroid rodents. In: Sydney Anderson, J. Knox Jones Jr. (Hrsg.): Orders and Families of Recent Mammals of the World. Wiley-Interscience, New York u. a. 1984, ISBN 0-471-08493-X, S. 289–379.
Cyril Charles, Jean-Jacques Jaeger, Jacques Michaux, Laurent Viriot: Dental microwear in relation to changes in the direction of mastication during the evolution of Myodonta (Rodentia, Mammalia). In: Naturwissenschaften. Band 94, Nr. 1, 2007, S. 71–75, doi:10.1007/s00114-006-0161-7.
Julie Feaver, Zhang Zhi-Bin: Hamsters. In: David W. Macdonald (Hrsg.): The Encyclopedia of Mammals. Oxford University Press, Oxford/New York 2010, ISBN 978-0-19-956799-7, S. 204–205.
Wladimir Jewgenjewitsch Flint: Die Zwerghamster der paläarktischen Fauna. In: Die Neue Brehm-Bücherei. 2. Auflage. Band 366. Westarp-Wissenschaften, Hohenwarsleben 2006, ISBN 3-89432-766-9 (Erstausgabe: 1966, Nachdruck).
Gerard C. Gorniak: Feeding in Golden hamsters, Mesocricetus auratus. In: Journal of Morphology. Band 154, Nr. 3, 1977, S. 427–458, doi:10.1002/jmor.1051540305.
Michael M. Gottesman: Preface. In: Michael M. Gottesman (Hrsg.): Molecular Cell Genetics. John Wiley & Sons, New York u. a. 1985, ISBN 0-471-87925-8, S. xi–xii.
Igor Michailowitsch Gromow, Margarita Alexandrowna Jerbajewa: Млекопитающие фауны России и сопредельных территорий. Зайцеобразные и грызуны. Russische Akademie der Wissenschaften (Zoologisches Institut), Sankt Petersburg 1995.
Sandra Honigs: Zwerghamster. Biologie, Haltung, Zucht. 3. Auflage. Natur- und Tier-Verlag, Münster 2010, ISBN 978-3-86659-159-2.
Sharon A. Jansa, Marcelo Weksler: Phylogeny of muroid rodents: relationships within and among major lineages as determined by IRBP gene sequences. In: Molecular Phylogenetics and Evolution. Band 31, Nr. 1, 2004, S. 256–276, doi:10.1016/j.ympev.2003.07.002.
Chris Logsdail, Peter Logsdail, Kate Hovers: Hamsterlopaedia. A Complete Guide to Hamster Care. Ringpress Books, Dorking 2005, ISBN 1-86054-246-8 (Erstausgabe: 2002, Nachdruck).
Michael Mettler: Alles über Zwerg- und Goldhamster. Falken-Verlag, Niedernhausen (Taunus) 1995, ISBN 3-8068-1012-5.
Malcolm C. McKenna, Susan K. Bell: Classification of Mammals Above the Species Level. Columbia University Press, New York 1997, ISBN 0-231-11012-X.
Johan Michaux, Aurelio Reyes, François Catzeflis: Evolutionary history of the most speciose mammals: Molecular phylogeny of muroid rodents. In: Molecular Biology and Evolution. Band 18, Nr. 11, 2001, S. 2017–2031 (mbe.oxfordjournals.org).
Guy G. Musser, Michael D. Carleton: Superfamily Muroidea. In: Don E. Wilson, DeeAnn M. Reeder (Hrsg.): Mammal Species of the World: A Taxonomic and Geographic Reference. 3. Auflage. Johns Hopkins University Press, Baltimore 2005, ISBN 0-8018-8221-4, S. 894–1531.
Karsten Neumann, Johan Michaux, Wladimir S. Lebedew, Nuri Yiğit, Ercüment Çolak, Natalja W. Iwanowa, Andrei B. Poltoraus, Alexei Surow, Georgi Markow, Steffen Maak, Sabine Neumann, Rolf Gattermann: Molecular phylogeny of the Cricetinae subfamily based on the mitochondrial cytochrome b and 12S rRNA genes and the nuclear vWF gene. In: Molecular Phylogenetics and Evolution. Band 39, Nr. 1, 2006, S. 135–148, doi:10.1016/j.ympev.2006.01.010.
Jochen Niethammer: Familie Cricetidae Rochebrune, 1881 – Hamster. In: Jochen Niethammer, Franz Krapp (Hrsg.): Handbuch der Säugetiere Europas. Band 2/I: Nagetiere II. Akademische Verlagsgesellschaft, Wiesbaden 1982, ISBN 3-89104-026-1, S. 1–6 (a).
Jochen Niethammer: Cricetus cricetus (Linnaeus, 1758) – Hamster (Feldhamster). In: Jochen Niethammer, Franz Krapp (Hrsg.): Handbuch der Säugetiere Europas. Band 2/I: Nagetiere II. Akademische Verlagsgesellschaft, Wiesbaden 1982, ISBN 3-89104-026-1, S. 7–28.
Jochen Niethammer: Wühler. In: Bernhard Grzimek (Hrsg.): Grzimeks Enzyklopädie Säugetiere. Band 5. Kindler-Verlag, München 1988, S. 206–265 (elfbändige Lizenzausgabe).
Ronald M. Nowak: Walker’s Mammals of the World. 6. Auflage. Johns Hopkins University Press, Baltimore/London 1999, ISBN 0-8018-5789-9.
Frank J. Orland: A study of the Syrian hamster, its molars, and their lesions. In: Journal of Dental Research. Band 25, Nr. 6, 1946, S. 445–453 (jdr.iadrjournals.org).
Rudolf Piechocki: Familie Wühler. In: Irenäus Eibl-Eibesfeldt, Martin Eisentraut, Hans-Albrecht Freye, Bernhard Grzimek, Heini Hediger, Dietrich Heinemann, Helmut Hemmer, Adriaan Kortlandt, Hans Krieg, Erna Mohr, Rudolf Piechocki, Urs Rahm, Everard J. Slijper, Erich Thenius (Hrsg.): Grzimeks Tierleben: Enzyklopädie des Tierreichs. Elfter Band: Säugetiere 2. Kindler-Verlag, Zürich 1969, S. 301–344.
Swetlana Anatoljewna Romanenko, Vitaly T. Volobouev, Polina Lwowna Perelman, Wladimir Swjatoslawowitsch Lebedew, Natalija A. Serdjukowa, Wladimir Alexandrowitsch Trifonow, Larissa Semenowna Biltuijewa, Nie Wen-Hui, Patricia C. M. O’Brien, Nina Schamiljewna Bulatowa, Malcolm Andrew Ferguson-Smith, Yang Feng-Tang, Alexander Sergejewitsch Grafodatski: Karyotype evolution and phylogenetic relationships of hamsters (Cricetidae, Muroidea, Rodentia) inferred from chromosomal painting and banding comparison. In: Chromosome Research. Band 15, Nr. 3, 2007, S. 283–297, doi:10.1007/s10577-007-1124-3.
Patricia D. Ross: Phodopus campbelli. In: Mammalian Species. Nr. 503, 1995, S. 1–7 (science.smith.edu [PDF; 908 kB]).
James M. Ryan: Comparative morphology and evolution of cheek pouches in rodents. In: Journal of Morphology. Band 190, Nr. 1, 1986, S. 27–42, doi:10.1002/jmor.1051900104.
Günter Schmidt: Hamster, Meerschweinchen, Mäuse und andere Nagetiere. 2. Auflage. Eugen Ulmer, Stuttgart 1985, ISBN 3-8001-7147-3.
George Gaylord Simpson: The principles of classification and a classification of mammals. In: Bulletin of the American Museum of Natural History. Band 85, 1945, S. 1–350 (hdl.handle.net).
Hans-Wilhelm Smolik: Grimback Der Hamster, Illustrationen von Karl Elchleb, Mitteldeutsche Druckerei und Verlagsanstalt GmbH, Halle (Saale) 1949, Veröffentlicht unter Lizenz Nr. 286 der Sowjetischen Militär–Administration in Deutschland, 5598/49 – 4029/47.
Scott J. Steppan, Ronald M. Adkins, Joel Anderson: Phylogeny and divergence-date estimates of rapid radiations in muroid rodents based on multiple nuclear genes. In: Systematic Biology. Band 54, Nr. 4, 2004, S. 533–553 (sysbio.oxfordjournals.org).
G. L. Van Hoosier junior, Charles W. McPherson (Hrsg.): Laboratory Hamsters. Academic Press, Orlando u. a. 1987, ISBN 0-12-714165-0.
Connie A. Cantrell, Dennis Padovan: Other Hamsters. Biology, Care, and Use in Research. S. 369–387.
Albert Chang, Arthur Siani, Mark Connell: The Striped or Chinese Hamster. Biology and Care. S. 305–319.
J. Derrell Clark: The Golden or Syrian Hamster. Historical Perspectives and Taxonomy. S. 3–7.
Ulrich Mohr, Heinrich Ernst: The European Hamster. Biology, Care, and Use in Research. S. 351–366.
Ulrich Weinhold, Anja Kayser: Der Feldhamster. Cricetus cricetus. In: Die Neue Brehm-Bücherei. 1. Auflage. Band 625. Westarp-Wissenschaften, Hohenwarsleben 2006, ISBN 3-89432-873-8.
Nuri Yigit: Age-dependent cranial variations in Mesocricetus brandti (Mammalia: Rodentia) distributed in Turkey. In: Turkish Journal of Zoology. Band 27, Nr. 1, 2003, S. 65–71 (mistug.tubitak.gov.tr (Memento vom 11. Februar 2009 im Internet Archive)).
Einzelnachweise
 Niethammer, [1988] (S. 206)
 Niethammer: 1982[a] (S. 3)
 Mettler, 1995 (S. 11–12)
 Piechocki, 1969 (S. 305–306)
 Feaver und Zhang, 2010 (S. 204)
 W. B. Quay, P. Quentin Tomich: A Specialized Midventral Sebaceous Glandular Area in Rattus exulans. In: Journal of Mammalogy. Band 44, 1963, S. 537–542, doi:10.2307/1377136. Zitiert in: Niethammer: 1982[a] (S. 3)
 Nowak, 1999 (S. 1419–1425)
 Ross, 1995
 Charles P. Lyman, Regina C. O’Brien: Laboratory Study of the Turkish Hamster Mesocricetus brandti. In: Breviora. Nr. 442, 1977, ISSN 0006-9698, S. 1–27. Zitiert in: Nowak 1999 (S. 1423)
 Glover Morrill Allen: The Mammals of China and Mongolia. Part 2. In: Walter Granger (Hrsg.): Natural History of Central Asia. Band 11. American Museum of Natural History, New York 1940, S. 621–1350 (Central Asiatic Expeditions). Zitiert in: Nowak 1999 (S. 1423)
 Glover Morrill Allen: The Mammals of China and Mongolia. Part 2. In: Walter Granger (Hrsg.): Natural History of Central Asia. Band 11. American Museum of Natural History, New York 1940, S. 621–1350 (Central Asiatic Expeditions). Zitiert in: Nowak 1999 (S. 1421–1423)
 Weinhold und Kayser, 2006 (S. 19)
 Charles und Mitarbeiter, 2007
 Flint, 2006 [1966] (S. 84–85)
 Yigit, 2003 (S. 66–68)
 Orland, 1946 (Tab. 1)
 Orland, 1946 (S. 446–447)
 Gorniak, 1977:433–434
 Niethammer: 1982[a] (Abb. 2, S. 3)
 Niethammer: 1982[a] (Abb. 4, Abb. 1, Tab. 1). Nomenklatur nach: Emmet Thurman Hooper: A Systematic Review of the Harvest Mice (Genus Reithrodontomys) of Latin America. In: Miscellaneous Publications, Museum of Zoology, University of Michigan. Nr. 77. University of Michigan Press, 1952, ISSN 0076-8405.
 Flint, 2006 [1966] (S. 4–5)
 Jansa und Weksler, 2004 (S. 272; Abb. 3, S. 273)
 Niethammer: 1982[a] (S. 1)
 Niethammer, 1982b (Tab. 5, Abb. 9)
 Logsdail und Mitarbeiter, 2005 [2002] (S. 69)
 Ryan, 1986
 Carleton und Musser (S. 312)
 Gromow und Jerbajewa, 1995 („Подсем. Хомячьи — Cricetinae“)
 Feaver und Zhang, 2010 (S. 205)
 Carleton und Musser (S. 311)
 Neumann und Mitarbeiter, 2006 (S. 135)
 Musser und Carleton, 2005 (Cricetinae, S. 1039–1046)
 McKenna und Bell, 1997 (S. 149–151)
 A. Banaszek, P. Bogomolov, N. Feoktistova, M. La Haye, S. Monecke, T. E. Reiners, M. Rusin, A. Surov, U. Weinhold, J. Ziomek: Cricetus cricetus. The IUCN Red List of Threatened Species 2020. IUCN, 9. Juli 2020, abgerufen am 9. Juli 2020 (englisch).
 Musser und Carleton, 2005 (Cricetinae, S. 1039–1040)
 Michaux und Mitarbeiter, 2001 (Abb. 4, S. 2024)
 Jansa und Weksler, 2004 (S. 271)
 Steppan und Mitarbeiter, 2004 (Abb. 1, S. 539; Abb. 2, S. 541)
 Steppan und Mitarbeiter, 2004 (Tab. 4, S. 543)
 Carleton und Musser (S. 313)
 Musser und Carleton, 2005 (Mystromyinae, S. 945–946)
 Musser und Carleton, 2005 (Calomyscidae, S. 926–927)
 Simpson, 1945 (S. 86)
 Xuan Pan, Xuming Wang, Yingxun Liu, Yuchun Li, Rui Liao, Zhongzheng Chen, Buqing Peng, Xichao Zhu, Jiatang Li, Shaoying Liu: Phylogenomic analyses of hamsters (Cricetinae) inferred from GBS data and mitochondrial genomes. Molecular Phylogenetics and Evolution, Band 202, Januar 2025, doi: 10.1016/j.ympev.2024.108241
 Boris Kryštufek & Georgy I. Shenbrot (2025): True Hamsters (Cricetinae) of the Palaearctic Region. University of Maribor, University Press, Maribor. ISBN 978-961-286-940-3.
 Amy Chernasky u. a.: All the Mammals of the World. Lynx Edicions, Juni 2023, ISBN 978-84-16728-66-4. S. 220.
 McKenna und Bell, 1997 (S. 136)
 McKenna und Bell, 1997 (S. 149)
 Nicola Zingarelli: Vocabolario della lingua italiana. Zanichelli, 2008, ISBN 978-88-08-14994-7.
 Wolfgang Pfeifer: Etymologisches Wörterbuch des Deutschen. 1993. Zitiert in: Digitales Wörterbuch der deutschen Sprache (Hamster)
 Clark, in Van Hoosier und McPherson, 1987 (S. 5–6)
 Chang und Mitarbeiter, in Van Hoosier und McPherson, 1987 (S. 305)
 Mohr und Ernst, in Van Hoosier und McPherson, 1987 (S. 351)
 Cantrell und Padovan, in Van Hoosier und McPherson, 1987 (S. 370)
 Cantrell und Padovan, in Van Hoosier und McPherson, 1987 (S. 382)
 Cantrell und Padovan, in Van Hoosier und McPherson, 1987 (S. 384)
 Cantrell und Padovan, in Van Hoosier und McPherson, 1987 (S. 385)
 Schmidt, 1985 (S. 122)
 Schmidt, 1985 (S. 134)
 Honigs, 2010 (S. 9)
 Gottesman, 1985 (S. xi–xii)
Normdaten (Sachbegriff): GND: 4023196-3 (GND Explorer, lobid, OGND)
Kategorie: Hamster
Diese Seite wurde zuletzt am 12. Februar 2026 um 04:33 Uhr bearbeitet.
Abrufstatistik · Autoren

Der Text ist unter der Lizenz „Creative-Commons Namensnennung – Weitergabe unter gleichen Bedingungen“ verfügbar; Informationen zu den Urhebern und zum Lizenzstatus eingebundener Mediendateien (etwa Bilder oder Videos) können im Regelfall durch Anklicken dieser abgerufen werden. Möglicherweise unterliegen die Inhalte jeweils zusätzlichen Bedingungen. Durch die Nutzung dieser Website erklären Sie sich mit den Nutzungsbedingungen und der Datenschutzrichtlinie einverstanden.

Wikipedia® ist eine eingetragene Marke der Wikimedia Foundation Inc.
DatenschutzÜber WikipediaHaftungsausschlussImpressum / SicherheitVerhaltenskodexEntwicklerStatistikenStellungnahme zu CookiesMobile Ansicht
Wikimedia Foundation
Powered by MediaWiki

    """
    """

WikipediaThe Free Encyclopedia
Search Wikipedia
Search
Donate
Create account
Log in
Contents hide
(Top)
Overview
History

Precursors
Creation
Copyright, trademark, and naming
Naming
Commercial and popular uptake
Development
Usage

Market share and uptake
Design

User interface
Video input infrastructure
Development

Community
Programming on Linux
Graphics and graphics design
Hardware support
Security
See also
Notes
References
External links
Linux

Article
Talk
Read
Edit
View history

Tools
Appearance hide
Birthday mode (Baby Globe)

Disabled

Enabled
Learn more about Birthday mode
Text

Small

Standard

Large
Width

Standard

Wide
Color (beta)

Automatic

Light

Dark
Checked
Page protected with pending changes
From Wikipedia, the free encyclopedia
This article is about the family of operating systems. For the kernel, see Linux kernel. For other uses, see Linux (disambiguation).
Linux
Tux the penguin
Tux the penguin, the mascot of Linux[1]
Developer	Community contributors,
Linus Torvalds
Written in	C, assembly language, Rust, other
OS family	Unix-like
Working state	Current
Source model	Open-source
Initial release	17 September 1991; 34 years ago[2]
Marketing target	Cloud computing, embedded devices, mainframe computers, mobile devices, personal computers, servers, supercomputers
Available in	Multilingual
Supported platforms	Alpha, ARC, ARM, C-Sky, Hexagon, LoongArch, m68k, Microblaze, MIPS, Nios II, OpenRISC, PA-RISC, PowerPC and Power ISA, RISC-V, ESA/390 and z/Architecture, SuperH, SPARC, x86, Xtensa
Kernel type	Monolithic
Userland	util-linux by standard,[a] various alternatives, such as Busybox,[b] GNU,[c] Plan 9 from User Space[d] and Toybox[e]
Influenced by	Minix, Unix
Default
user interface	
Most distributions include a desktop environment (GUI).
License	GPLv2 (Linux kernel)[14][f]
Articles in the series
Linux kernel
Linux distribution
Linux (/ˈlɪnʊks/ LIN-uuks)[16] is a family of open source Unix-like operating systems based on the Linux kernel,[17] a kernel first released on 17 September 1991, by Linus Torvalds.[18][19] Linux is typically packaged as a Linux distribution (a.k.a distro), which includes the kernel and supporting system software and libraries – most of which are provided by third parties – to create a complete operating system. Linux was originally designed as a clone of Unix and is released under the copyleft GPL license.[20]

There are many thousands of Linux distributions, many based directly or indirectly on other distributions;[21][22] popular Linux distros[23][24][25] include Debian, Fedora Linux, Linux Mint, Arch Linux, and Ubuntu, while commercial distributions include Red Hat Enterprise Linux, SUSE Linux Enterprise, and ChromeOS. Linux distributions are frequently used in server platforms.[26][27] Many Linux distributions use the word "Linux" in their name, but the Free Software Foundation uses and recommends the name "GNU/Linux", to emphasize the use and importance of GNU software in many distributions. There is a controversy surrounding this.[28][29] Other than the Linux kernel, key components that make up a distribution may include a display server (windowing system), a package manager, a bootloader, and a Unix shell.

Linux is one of the most prominent examples of free and open-source software collaboration. The Linux kernel is considered by many to be the largest open source project. While originally developed for x86-based personal computers, it has since been ported to more platforms than any other operating system,[30] and is used on a wide variety of devices including PCs, workstations, mainframes, and embedded systems. Linux is the predominant operating system for servers and is also used on all of the world's 500 fastest supercomputers.[g] When combined with Android, which uses a Linux-based kernel and is designed for smartphones, they have the largest installed base of all general-purpose operating systems.

Overview
The Linux kernel was created by Linus Torvalds, following the lack of a working kernel for GNU, a Unix-compatible operating system made entirely of free software that had been in development since 1983 by the GNU Project, led by Richard Stallman. A working Unix system called Minix was later released but its license was not entirely free at the time[31] and it was made for education purposes. The first entirely free Unix for personal computers, 386BSD, did not appear until 1992, by which time Torvalds had already built and publicly released the first version of the Linux kernel on the Internet.[32] Like GNU and 386BSD, Linux did not have any Unix code, being a fresh re-implementation, and therefore avoided legal issues from AT&T.[33] Linux distributions became popular in the 1990s and made Unix technologies accessible to home users on personal computers whereas previously it had been confined to sophisticated workstations.[34]

Desktop Linux distributions include a windowing system such as X11 or Wayland and a desktop environment such as KDE Plasma, GNOME, or Xfce. Distributions intended for servers may not have a graphical user interface at all or include a solution stack such as LAMP.

The source code of Linux may be used, modified, and distributed commercially or non-commercially by anyone under the terms of its respective licenses, such as the GNU General Public License (GPL). The license means creating novel distributions is permitted by anyone[35] and is easier than it would be for an operating system such as macOS or Microsoft Windows.[36][37][38] The Linux kernel, for example, is licensed under the GPLv2, with an exception for system calls that allows code that calls the kernel via system calls not to be licensed under the GPL.[39][40][35]

Because of the dominance of Linux-based Android on smartphones, Linux, including Android, has the largest installed base of all general-purpose operating systems as of May 2022.[41][42][43] Linux is, as of March 2024, used by around 4 percent of desktop computers.[44] The Chromebook, which runs the Linux kernel-based ChromeOS,[45][46] dominates the US K–12 education market and represents nearly 20 percent of sub-$300 notebook sales in the US.[47] Linux is the leading operating system on servers (over 96.4% of the top one million web servers' operating systems are Linux),[48] leads other big iron systems such as mainframe computers,[clarification needed][49] and is used on all of the world's 500 fastest supercomputers[h] (as of November 2017, having gradually displaced all competitors).[50][51]

Linux also runs on embedded systems, i.e., devices whose operating system is typically built into the firmware and is highly tailored to the system. This includes routers, automation controls, smart home devices, video game consoles, televisions (Samsung and LG smart TVs),[52][53][54] automobiles (Tesla, Audi, Mercedes-Benz, Hyundai, and Toyota),[55] and spacecraft (Falcon 9 rocket, Dragon crew capsule, and the Ingenuity Mars helicopter).[56][57]

History
Main articles: History of Linux, Free as in free beer, and Free software movement
Precursors
Linus Torvalds
Linus Torvalds, principal author of the Linux kernel
The Unix operating system was conceived of and implemented in 1969, at AT&T's Bell Labs in the United States, by Ken Thompson, Dennis Ritchie, Douglas McIlroy, and Joe Ossanna.[58] First released in 1971, Unix was written entirely in assembly language, as was common practice at the time. In 1973, in a key pioneering approach, it was rewritten in the C programming language by Dennis Ritchie (except for some hardware and I/O routines). The availability of a high-level language implementation of Unix made its porting to different computer platforms easier.[59]

As a 1956 antitrust case forbade AT&T from entering the computer business,[60] AT&T provided the operating system's source code to anyone who asked. As a result, Unix use grew quickly and it became widely adopted by academic institutions and businesses. In 1984, AT&T divested itself of its regional operating companies, and was released from its obligation not to enter the computer business; freed of that obligation, Bell Labs began selling Unix as a proprietary product, where users were not legally allowed to modify it.[61][62]

Onyx Systems began selling early microcomputer-based Unix workstations in 1980. Later, Sun Microsystems, founded as a spin-off of a student project at Stanford University, also began selling Unix-based desktop workstations in 1982. While Sun workstations did not use commodity PC hardware, for which Linux was later originally developed, it represented the first successful commercial attempt at distributing a primarily single-user microcomputer that ran a Unix operating system.[63][64]

With Unix increasingly "locked in" as a proprietary product, the GNU Project, started in 1983 by Richard Stallman, had the goal of creating a "complete Unix-compatible software system" composed entirely of free software. Work began in 1984.[65] Later, in 1985, Stallman started the Free Software Foundation and wrote the GNU General Public License (GNU GPL) in 1989. By the early 1990s, many of the programs required in an operating system (such as libraries, compilers, text editors, a command-line shell, and a windowing system) were completed, although low-level elements such as device drivers, daemons, and the kernel, called GNU Hurd, were stalled and incomplete.[66]

Minix was created by Andrew S. Tanenbaum, a computer science professor, and released in 1987 as a minimal Unix-like operating system targeted at students and others who wanted to learn operating system principles. Although the complete source code of Minix was freely available, the licensing terms prevented it from being free software until the licensing changed in April 2000.[67]

Creation
While attending the University of Helsinki in the fall of 1990, Torvalds enrolled in a Unix course.[68] The course used a MicroVAX minicomputer running Ultrix, and one of the required texts was Operating Systems: Design and Implementation by Andrew S. Tanenbaum. This textbook included a copy of Tanenbaum's Minix operating system. It was with this course that Torvalds first became exposed to Unix. In 1991, he became curious about operating systems.[69] Frustrated by the licensing of Minix, which at the time limited it to educational use only,[67] he began to work on his operating system kernel, which eventually became the Linux kernel.

On 3 July 1991, to implement Unix system calls, Linus Torvalds attempted unsuccessfully to obtain a digital copy of the POSIX standards documentation with a request to the comp.os.minix newsgroup.[70] After not finding the POSIX documentation, Torvalds initially resorted to determining system calls from SunOS documentation owned by the university for use in operating its Sun Microsystems server. He also learned some system calls from Tanenbaum's Minix text.

Torvalds began the development of the Linux kernel on Minix and applications written for Minix were also used on Linux. Later, Linux matured and further Linux kernel development took place on Linux systems.[71] GNU applications also replaced all Minix components, because it was advantageous to use the freely available code from the GNU Project with the fledgling operating system; code licensed under the GNU GPL can be reused in other computer programs as long as they also are released under the same or a compatible license. Torvalds initiated a switch from his original license, which prohibited commercial redistribution, to the GNU GPL.[72] Developers worked to integrate GNU components with the Linux kernel, creating a fully functional and free operating system.[73]

Although not released until 1992, due to legal complications, the development of 386BSD, from which NetBSD, OpenBSD and FreeBSD descended, predated that of Linux. Linus Torvalds has stated that if the GNU kernel or 386BSD had been available in 1991, he probably would not have created Linux.[74][31]

Copyright, trademark, and naming
See also: GNU/Linux naming controversy and SCO–Linux disputes

Tux is sometimes stylized with incorporation of the GNU logo
The Linux kernel is licensed under the GNU General Public License (GPL), version 2. The GPL requires that anyone who distributes software based on source code under this license must make the originating source code (and any modifications) available to the recipient under the same terms.[75] Other key components of a typical Linux distribution are also mainly licensed under the GPL, but they may use other licenses; many libraries use the GNU Lesser General Public License (LGPL), a more permissive variant of the GPL, and the X.Org implementation of the X Window System uses the MIT License.

Torvalds states that the Linux kernel will not move from version 2 of the GPL to version 3.[76][77] He specifically dislikes some provisions in the new license which prohibit the use of the software in digital rights management.[78] It would also be impractical to obtain permission from all the copyright holders, who number in the thousands.[79]

A 2001 study of Red Hat Linux 7.1 found that this distribution contained 30 million lines of source code.[80] Using the Constructive Cost Model, the study estimated that this distribution required about eight thousand person-years of development time. According to the study, if all this software had been developed by conventional proprietary means, it would have cost about US$1.86 billion[81] to develop in 2024 in the United States.[80] Most of the source code (71%) was written in the C programming language, but many other languages were used, including C++, Lisp, assembly language, Perl, Python, Fortran, and various shell scripting languages. Slightly over half of all lines of code were licensed under the GPL. The Linux kernel itself was 2.4 million lines of code, or 8% of the total.[80]

In a later study, the same analysis was performed for Debian version 4.0 (etch, which was released in 2007).[82] This distribution contained close to 283 million lines of source code, and the study estimated that it would have required about seventy three thousand man-years and cost US$10.4 billion[81] (in 2024 dollars) to develop by conventional means.


5.25-inch floppy disks holding a very early version of Linux

In the United States, the name Linux is a trademark registered to Linus Torvalds.[15] Initially, nobody registered it. However, on 15 August 1994, William R. Della Croce Jr. filed for the trademark Linux, and then demanded royalties from Linux distributors. In 1996, Torvalds and some affected organizations sued him to have the trademark assigned to Torvalds, and, in 1997, the case was settled.[83] The licensing of the trademark has since been handled by the Linux Mark Institute (LMI). Torvalds has stated that he trademarked the name only to prevent someone else from using it. LMI originally charged a nominal sublicensing fee for use of the Linux name as part of trademarks,[84] but later changed this in favor of offering a free, perpetual worldwide sublicense.[85]

The Free Software Foundation (FSF) prefers GNU/Linux as the name when referring to the operating system as a whole, because it considers Linux distributions to be variants of the GNU operating system initiated in 1983 by Richard Stallman, president of the FSF.[28][29] The foundation explicitly takes no issue over the name Android for the Android OS, which is also an operating system based on the Linux kernel, as GNU is not a part of it.

A minority of public figures and software projects other than Stallman and the FSF, notably distributions consisting of only free software, such as Debian (which had been sponsored by the FSF up to 1996),[86] also use GNU/Linux when referring to the operating system as a whole.[87][88][89] Most media and common usage, however, refers to this family of operating systems simply as Linux, as do many large Linux distributions (for example, SUSE Linux and Red Hat Enterprise Linux).

As of May 2011, about 8% to 13% of the lines of code of the Linux distribution Ubuntu (version "Natty") is made of GNU components (the range depending on whether GNOME is considered part of GNU); meanwhile, 6% is taken by the Linux kernel, increased to 9% when including its direct dependencies.[90]

Naming
Linus Torvalds had wanted to call his invention "Freax", a portmanteau of "free", "freak", and "x" (as an allusion to Unix). During the start of his work on the system, some of the project's makefiles included the name "Freax" for about half a year. Torvalds considered the name "Linux" but dismissed it as too egotistical.[91]

To facilitate development, the files were uploaded to the FTP server of FUNET in September 1991. Ari Lemmke, Torvalds' coworker at the Helsinki University of Technology (HUT) who was one of the volunteer administrators for the FTP server at the time, did not think that "Freax" was a good name, so he named the project "Linux" on the server without consulting Torvalds.[91] Later, however, Torvalds consented to "Linux".

According to a newsgroup post by Torvalds,[16] the word "Linux" should be pronounced (/ˈlɪnʊks/ ⓘ LIN-uuks) with a short 'i' as in 'print' and 'u' as in 'put'. To further demonstrate how the word "Linux" should be pronounced, he included an audio guide with the kernel source code.[92] However, in this recording, he pronounces Linux as /ˈlinʊks/ (LEEN-uuks) with a short but close front unrounded vowel, instead of a near-close near-front unrounded vowel as in his newsgroup post.

Commercial and popular uptake
Main article: Linux adoption
The adoption of Linux in production environments, rather than being used only by hobbyists, started to take off first in the mid-1990s in the supercomputing community, where organizations such as NASA started replacing their increasingly expensive machines with clusters of inexpensive commodity computers running Linux. Commercial use began when Dell and IBM, followed by Hewlett-Packard, started offering Linux support to escape Microsoft's monopoly in the desktop operating system market.[93]

Today, Linux systems are used throughout computing, from embedded systems to virtually all supercomputers,[51][94] and have secured a place in server installations such as the popular LAMP application stack. The use of Linux distributions in home and enterprise desktops has been growing.[95][96][97][98][99][100][101]

Linux distributions have also become popular in the netbook market, with many devices shipping with customized Linux distributions installed, and Google releasing their own ChromeOS designed for netbooks.

Linux's greatest success in the consumer market is perhaps the mobile device market, with Android being the dominant operating system on smartphones and very popular on tablets and, more recently, on wearables, and vehicles. Linux gaming is also on the rise with Valve showing its support for Linux and rolling out SteamOS, its own gaming-oriented Linux distribution, which was later implemented in their Steam Deck platform. Linux distributions have also gained popularity with various local and national governments, such as the federal government of Brazil.[102]

Development
Main articles: Linux distribution and Free software
Linus Torvalds is the lead maintainer for the Linux kernel and guides its development, while Greg Kroah-Hartman is the lead maintainer for the stable branch.[103] Zoë Kooyman is the executive director of the Free Software Foundation,[104] which in turn supports the GNU components.[105] Finally, individuals and corporations develop third-party non-GNU components. These third-party components comprise a vast body of work and may include both kernel modules and user applications and libraries.

Linux vendors and communities combine and distribute the kernel, GNU components, and non-GNU components, with additional package management software in the form of Linux distributions.

Usage
Main article: Linux range of use
Market share and uptake
Main article: Linux adoption
See also: Usage share of operating systems




From top-left clockwise: Nexus 5X running Android, Chromebooks, server platform, In-flight entertainment system
Many quantitative studies of free/open-source software focus on topics including market share and reliability, with numerous studies specifically examining Linux.[106] The Linux market is growing, and the Linux operating system market size is expected to see a growth of 19.2% by 2027, reaching $15.64 billion, compared to $3.89 billion in 2019.[107] Analysts project a Compound Annual Growth Rate (CAGR) of 13.7% between 2024 and 2032, culminating in a market size of US$34.90 billion by the latter year.[citation needed] Analysts and proponents attribute the relative success of Linux to its security, reliability, low cost, and freedom from vendor lock-in.[108][109]

Desktops and laptops
According to web server statistics (that is, based on the numbers recorded from visits to websites by client devices), in October 2024, the estimated market share of Linux on desktop computers was around 4.3%. In comparison, Microsoft Windows had a market share of around 73.4%, while macOS covered around 15.5%.[44]
Web servers
W3Cook publishes stats that use the top 1,000,000 Alexa domains,[110] which as of May 2015 estimate that 96.55% of web servers run Linux, 1.73% run Windows, and 1.72% run FreeBSD.[111]
W3Techs publishes stats that use the top 10,000,000 Alexa domains and the top 1,000,000 Tranco domains, updated monthly[112] and as of November 2020 estimate that Linux is used by 39% of the web servers, versus 21.9% being used by Microsoft Windows.[113] 40.1% used other types of Unix.[114]
IDC's Q1 2007 report indicated that Linux held 12.7% of the overall server market at that time;[115] this estimate was based on the number of Linux servers sold by various companies, and did not include server hardware purchased separately that had Linux installed on it later.
As of 2024, estimates suggest Linux accounts for at least 80% of the public cloud workload, partly thanks to its widespread use in platforms like Amazon Web Services (AWS), Microsoft Azure, and Google Cloud Platform.[116][117][118]

ZDNet reports that 96.3% of the top one million web servers are running Linux.[119][120] W3Techs state that Linux powers at least 39.2% of websites whose operating system is known, with other estimates saying 55%.[121][122]

Mobile devices
See also: LiMo Foundation
Android, which is based on the Linux kernel, has become the dominant operating system for smartphones. In April 2023, 68.61% of mobile devices accessing websites using StatCounter were from Android.[123] Android is also a popular operating system for tablets, being responsible for more than 60% of tablet sales as of 2013.[124] According to web server statistics, as of October 2021 Android has a market share of about 71%, with iOS holding 28%, and the remaining 1% attributed to various niche platforms.[125]
Film production
For years, Linux has been the platform of choice in the film industry. The first major film produced on Linux servers was 1997's Titanic.[126][127] Since then major studios including DreamWorks Animation, Pixar, Weta Digital, and Industrial Light & Magic have migrated to Linux.[128][129][130] According to the Linux Movies Group, more than 95% of the servers and desktops at large animation and visual effects companies use Linux.[131]
Use in government
Linux distributions have also gained popularity with various local and national governments. News of the Russian military creating its own Linux distribution has also surfaced, and has come to fruition as the G.H.ost Project.[132] The Indian state of Kerala has gone to the extent of mandating that all state high schools run Linux on their computers.[133][134] China uses Linux exclusively as the operating system for its Loongson processor family to achieve technology independence.[135] In Spain, some regions have developed their own Linux distributions, which are widely used in education and official institutions, like gnuLinEx in Extremadura and Guadalinex in Andalusia. France and Germany have also taken steps toward the adoption of Linux.[136] North Korea's Red Star OS, developed as of 2002, is based on a version of Fedora Linux.[137]
Design
See also: Linux kernel § Architecture and features
Many developers of open-source software agree that the Linux kernel was not designed but rather evolved through natural selection. Torvalds considers that although the design of Unix served as a scaffolding, "Linux grew with a lot of mutations – and because the mutations were less than random, they were faster and more directed than alpha-particles in DNA."[138] Eric S. Raymond considers Linux's revolutionary aspects to be social, not technical: before Linux, complex software was designed carefully by small groups, but "Linux evolved in a completely different way. From nearly the beginning, it was rather casually hacked on by huge numbers of volunteers coordinating only through the Internet. Quality was maintained not by rigid standards or autocracy but by the naively simple strategy of releasing every week and getting feedback from hundreds of users within days, creating a sort of rapid Darwinian selection on the mutations introduced by developers."[139] Bryan Cantrill, an engineer of a competing OS, agrees that "Linux wasn't designed, it evolved", but considers this to be a limitation, proposing that some features, especially those related to security,[140] cannot be evolved into, "this is not a biological system at the end of the day, it's a software system."[141]

A Linux-based system is a modular Unix-like operating system, deriving much of its basic design from principles established in Unix during the 1970s and 1980s. Such a system uses a monolithic kernel, the Linux kernel, which handles process control, networking, access to the peripherals, and file systems. Device drivers are either integrated directly with the kernel or added as modules that are loaded while the system is running.[142]

The GNU userland is a key part of most systems based on the Linux kernel, with Android being a notable exception. The GNU C library, an implementation of the C standard library, works as a wrapper for the system calls of the Linux kernel necessary to the kernel-userspace interface, the toolchain is a broad collection of programming tools vital to Linux development (including the compilers used to build the Linux kernel itself), and the coreutils implement many basic Unix tools. The GNU Project also develops Bash, a popular CLI shell. The graphical user interface (or GUI) used by most Linux systems is built on top of an implementation of the X Window System.[143] More recently, some of the Linux community has sought to move to using Wayland as the display server protocol, replacing X11.[144][145]

Many other open-source software projects contribute to Linux systems.

Various layers within Linux, also showing separation between the userland and kernel space
User mode	User applications	bash, LibreOffice, GIMP, Blender, 0 A.D., Mozilla Firefox, ...
System components	init daemon:
OpenRC, runit, systemd, ...	System daemons:
polkitd, smbd, sshd, udevd, ...	Windowing system:
X11, Wayland, SurfaceFlinger (Android)	Graphics:
Mesa, AMD Catalyst, ...	Other libraries:
GTK, Qt, EFL, SDL, SFML, FLTK, GNUstep, ...
C standard library	fopen, execv, malloc, memcpy, localtime, pthread_create, ... (up to 2000 subroutines)
glibc aims to be fast, musl aims to be lightweight, uClibc targets embedded systems, bionic was written for Android, etc. All aim to be POSIX/SUS-compatible.
Kernel mode	Linux kernel	stat, splice, dup, read, open, ioctl, write, mmap, close, exit, etc. (about 380 system calls)
The Linux kernel System Call Interface (SCI), aims to be POSIX/SUS-compatible[146]
Process scheduling subsystem	IPC subsystem	Memory management subsystem	Virtual files subsystem	Networking subsystem
Other components: ALSA, DRI, evdev, klibc, LVM, device mapper, Linux Network Scheduler, Netfilter
Linux Security Modules: SELinux, TOMOYO, AppArmor, Smack
Hardware (CPU, main memory, data storage devices, etc.)
Installed components of a Linux system include the following:[143][147]

A bootloader, for example GNU GRUB, LILO, SYSLINUX or systemd-boot. This is a program that loads the Linux kernel into the computer's main memory, by being executed by the computer when it is turned on and after the firmware initialization is performed.
An init program, such as the traditional sysvinit and the newer systemd, OpenRC and Upstart. This is the first process launched by the Linux kernel, and is at the root of the process tree. It starts processes such as system services and login prompts (whether graphical or in terminal mode).
Software libraries, which contain code that can be used by running processes. On Linux systems using ELF-format executable files, the dynamic linker that manages the use of dynamic libraries is known as ld-linux.so. If the system is set up for the user to compile software themselves, header files will also be included to describe the programming interface of installed libraries. Besides the most commonly used software library on Linux systems, the GNU C Library (glibc), there are numerous other libraries, such as SDL and Mesa.
The C standard library is the library necessary to run programs written in C on a computer system, with the GNU C Library being the standard. It provides an implementation of the POSIX API, as well as extensions to that API. For embedded systems, alternatives such as musl, EGLIBC (a glibc fork once used by Debian) and uClibc (which was designed for uClinux) have been developed, although the last two are no longer maintained. Android uses its own C library, Bionic. However, musl can additionally be used as a replacement for glibc on desktop and laptop systems, as seen on certain Linux distributions like Void Linux.
Basic Unix commands, with GNU coreutils being the standard implementation. Alternatives exist for embedded systems, such as the copyleft BusyBox, and the BSD-licensed Toybox.
Widget toolkits are the libraries used to build graphical user interfaces (GUIs) for software applications. Numerous widget toolkits are available, including GTK and Clutter developed by the GNOME Project, Qt developed by the Qt Project and led by The Qt Company, and Enlightenment Foundation Libraries (EFL) developed primarily by the Enlightenment team.
A package management system, such as dpkg and RPM. Alternatively packages can be compiled from binary or source tarballs.
User interface programs such as command shells or windowing environments.
User interface






From top-left clockwise: GNOME Shell, Debian running the Xfce desktop environment, i3 Tiling window manager, Elementary OS, Linux Mint running Cinnamon, Fedora Linux running KDE Plasma
The user interface, also known as the shell, is either a command-line interface (CLI), a graphical user interface (GUI), or controls attached to the associated hardware, which is common for embedded systems. For desktop systems, the default user interface is usually graphical, although the CLI is commonly available through terminal emulator windows or on a separate virtual console.

CLI shells are text-based user interfaces, which use text for both input and output. The dominant shell used in Linux is the Bourne-Again Shell (bash), originally developed for the GNU Project; other shells such as Zsh are also used.[148][149] Most low-level Linux components, including various parts of the userland, use the CLI exclusively. The CLI is particularly suited for automation of repetitive or delayed tasks and provides very simple inter-process communication.


On desktop systems, the most popular user interfaces are the GUI shells, packaged together with extensive desktop environments, such as KDE Plasma, GNOME, MATE, Cinnamon, LXDE, Pantheon, and Xfce, though a variety of additional user interfaces exist. Most popular user interfaces are based on the X Window System, often simply called "X" or "X11". It provides network transparency and permits a graphical application running on one system to be displayed on another where a user may interact with the application; however, certain extensions of the X Window System are not capable of working over the network.[150] Several X display servers exist, with the reference implementation, X.Org Server, being the most popular.

Several types of window managers exist for X11, including tiling, dynamic, stacking, and compositing. Window managers provide means to control the placement and appearance of individual application windows, and interact with the X Window System. Simpler X window managers such as dwm, ratpoison, or i3wm provide a minimalist functionality, while more elaborate window managers such as FVWM, Enlightenment, or Window Maker provide more features such as a built-in taskbar and themes, but are still lightweight when compared to desktop environments. Desktop environments include window managers as part of their standard installations, such as Mutter (GNOME), KWin (KDE), or Xfwm (xfce), although users may choose to use a different window manager if preferred.

Wayland is a display server protocol intended as a replacement for the X11 protocol; as of 2022, it has received relatively wide adoption.[151] Unlike X11, Wayland does not need an external window manager and compositing manager. Therefore, a Wayland compositor takes the role of the display server, window manager, and compositing manager. Weston is the reference implementation of Wayland, while GNOME's Mutter and KDE's KWin are being ported to Wayland as standalone display servers. Enlightenment has already been successfully ported since version 19.[152] Additionally, many window managers have been made for Wayland, such as Sway or Hyprland, as well as other graphical utilities such as Waybar or Rofi.

Video input infrastructure
Main article: Video4Linux
Linux currently has two modern kernel-userspace APIs for handling video input devices: V4L2 API for video streams and radio, and DVB API for digital TV reception.[153]

The diversity of hardware standards and data formats requires continuous architectural refinement to maintain compatibility across different device classes. Development focuses on providing robust userspace libraries to abstract device complexity, ensuring that applications can interface with varying formats without specialized hardware-specific drivers.[154][155]

Development
Main article: Linux kernel version history

Simplified history of Unix-like operating systems. Linux shares similar architecture and concepts (as part of the POSIX standard) but does not share non-free source code with the original Unix or Minix.
The primary difference between Linux and many other popular contemporary operating systems is that the Linux kernel and other components are free and open-source software. Linux is not the only such operating system, although it is by far the most widely used.[156] Some free and open-source software licenses are based on the principle of copyleft, a kind of reciprocity: any work derived from a copyleft piece of software must also be copyleft itself. The most common free software license, the GNU General Public License (GPL), is a form of copyleft and is used for the Linux kernel and many of the components from the GNU Project.[157]

Linux-based distributions are intended by developers for interoperability with other operating systems and established computing standards. Linux systems adhere to POSIX,[158] Single UNIX Specification (SUS),[159] Linux Standard Base (LSB), ISO, and ANSI standards where possible, although to date only one Linux distribution has been POSIX.1 certified, Linux-FT.[160][161] The Open Group has tested and certified at least two Linux distributions as qualifying for the Unix trademark, EulerOS and Inspur K-UX.[162]

Free software projects, although developed through collaboration, are often produced independently of each other. The fact that the software licenses explicitly permit redistribution, however, provides a basis for larger-scale projects that collect the software produced by stand-alone projects and make it available all at once in the form of a Linux distribution.

Many Linux distributions manage a remote collection of system software and application software packages available for download and installation through a network connection. This allows users to adapt the operating system to their specific needs. Distributions are maintained by individuals, loose-knit teams, volunteer organizations, and commercial entities. A distribution is responsible for the default configuration of the installed Linux kernel, general system security, and more generally integration of the different software packages into a coherent whole. Distributions typically use a package manager such as apt, yum, zypper, pacman or portage to install, remove, and update all of a system's software from one central location.[163]

Community
See also: Free software movement and Linux user group

Photo of GNUCash accounting and bookkeeping program
A distribution is largely driven by its developer and user communities. Some vendors develop and fund their distributions on a volunteer basis, Debian being a well-known example. Others maintain a community version of their commercial distributions, as Red Hat does with Fedora, and SUSE does with openSUSE.[164][165]

In many cities and regions, local associations known as Linux User Groups (LUGs) seek to promote their preferred distribution and by extension free software. They hold meetings and provide free demonstrations, training, technical support, and operating system installation to new users. Many Internet communities also provide support to Linux users and developers. Most distributions and free software / open-source projects have IRC chatrooms or newsgroups. Online forums are another means of support, with notable examples being Unix & Linux Stack Exchange,[166][167] LinuxQuestions.org and the various distribution-specific support and community forums, such as ones for Ubuntu, Fedora, Arch Linux, Gentoo, etc. Linux distributions host mailing lists; commonly there will be a specific topic such as usage or development for a given list.

There are several technology websites with a Linux focus. Print magazines on Linux often bundle cover disks that carry software or even complete Linux distributions.[168][169]

Although Linux distributions are generally available without charge, several large corporations sell, support, and contribute to the development of the components of the system and free software. An analysis of the Linux kernel in 2017 showed that well over 85% of the code was developed by programmers who are being paid for their work, leaving about 8.2% to unpaid developers and 4.1% unclassified.[170] Some of the major corporations that provide contributions include Intel, Samsung, Google, AMD, Oracle, and Facebook.[170] Several corporations, notably Red Hat, Canonical, and SUSE have built a significant business around Linux distributions.

The free software licenses, on which the various software packages of a distribution built on the Linux kernel are based, explicitly accommodate and encourage commercialization; the relationship between a Linux distribution as a whole and individual vendors may be seen as symbiotic. One common business model of commercial suppliers is charging for support, especially for business users. A number of companies also offer a specialized business version of their distribution, which adds proprietary support packages and tools to administer higher numbers of installations or to simplify administrative tasks.[171]

Another business model is to give away the software to sell hardware. This used to be the norm in the computer industry, with operating systems such as CP/M, Apple DOS, and versions of the classic Mac OS before 7.6 freely copyable (but not modifiable). As computer hardware standardized throughout the 1980s, it became more difficult for hardware manufacturers to profit from this tactic, as the OS would run on any manufacturer's computer that shared the same architecture.[172][173]

Programming on Linux
See also: GNU General Public License
Most programming languages support Linux either directly or through third-party community based ports.[174] The original development tools used for building both Linux applications and operating system programs are found within the GNU toolchain, which includes the GNU Compiler Collection (GCC) and the GNU Build System. Among others, GCC provides compilers for Ada, C, C++, Go and Fortran. Many programming languages have a cross-platform reference implementation that supports Linux, for example PHP, Perl, Ruby, Python, Java, Go, Rust and Haskell. First released in 2003, the LLVM project provides an alternative cross-platform open-source compiler for many languages. Proprietary compilers for Linux include the Intel C++ Compiler, Sun Studio, and IBM XL C/C++ Compiler. BASIC is available in procedural form from QB64, PureBasic, Yabasic, GLBasic, Basic4GL, XBasic, wxBasic, SdlBasic, and Basic-256, and in object oriented through Gambas, FreeBASIC, B4X, Basic for Qt, Phoenix Object Basic, NS Basic, ProvideX, Chipmunk Basic, RapidQ and Xojo. Pascal is implemented through GNU Pascal, Free Pascal, Virtual Pascal, and graphically via Lazarus, PascalABC.NET, or Delphi using FireMonkey (formerly through Borland Kylix).[175][176]

A common feature of Unix-like systems, Linux includes traditional specific-purpose programming languages targeted at scripting, text processing and system configuration and management in general. Linux distributions support shell scripts, AWK, sed and make. Many programs also have an embedded programming language to support configuring or programming themselves. For example, regular expressions are supported in programs like grep and locate, the traditional Unix message transfer agent Sendmail contains its own Turing complete scripting system, and the advanced text editor GNU Emacs is built around a general purpose Lisp interpreter.[177][178][179]

Most distributions also include support for PHP, Perl, Ruby, Python and other dynamic languages. While not as common, Linux also supports C# and other CLI languages (via Mono), Vala, and Scheme. Guile Scheme acts as an extension language targeting the GNU system utilities, seeking to make the conventionally small, static, compiled C programs of Unix design rapidly and dynamically extensible via an elegant, functional high-level scripting system; many GNU programs can be compiled with optional Guile bindings to this end. Many Java virtual machines and development kits run on Linux, including the original Sun Microsystems JVM (HotSpot), IBM's J2SE RE, and many open-source projects like Kaffe and Jikes RVM; Kotlin, Scala, Groovy and other JVM languages are also available.

GNOME and KDE are popular desktop environments and provide a framework for developing applications. These projects are based on the GTK and Qt widget toolkits, respectively, which can also be used independently of the larger framework. Both support a wide variety of languages. There are a number of Integrated development environments available including Anjuta, Code::Blocks, CodeLite, Eclipse, Geany, ActiveState Komodo, KDevelop, Lazarus, MonoDevelop, NetBeans, and Qt Creator, while the long-established editors Vim, nano and Emacs remain popular.[180]

Graphics and graphics design
A topic of perennial discussion is the area of graphic design on Linux. Typical common graphics and image tools are programs such as: GNU Image Manipulation Program (GIMP), Inkscape, Krita, DaVinci Resolve, and Scribus.

Hardware support
See also: List of Linux-supported computer architectures

Linux is found on many types of hardware.
The Linux kernel is a widely ported operating system kernel, available for devices ranging from mobile phones to supercomputers; it runs on a highly diverse range of computer architectures, including ARM-based Android smartphones and the IBM Z mainframes. Specialized distributions and kernel forks exist for less mainstream architectures; for example, the ELKS kernel fork can run on Intel 8086 or Intel 80286 16-bit microprocessors,[181] while the μClinux kernel fork may run on systems without a memory management unit.[182] The kernel also runs on architectures that were only ever intended to use a proprietary manufacturer-created operating system, such as Macintosh computers[183][184] (with PowerPC, Intel, and Apple silicon processors), PDAs, video game consoles, portable music players, and mobile phones.

Linux has a reputation for supporting old hardware very well by maintaining standardized drivers for a long time.[185] There are several industry associations and hardware conferences devoted to maintaining and improving support for diverse hardware under Linux, such as FreedomHEC. Over time, support for different hardware has improved in Linux, resulting in any off-the-shelf purchase having a "good chance" of being compatible.[186]

In 2014, a new initiative was launched to automatically collect a database of all tested hardware configurations.[187]

Security
Main article: Open-source software security
[icon]	
This section is empty. You can help by adding to it. (March 2026)
See also
Comparison of Linux distributions
Comparison of open-source and closed-source software
Comparison of operating systems
Comparison of X Window System desktop environments
Backward compatibility
Criticism of Linux
Linux kernel version history
Linux Documentation Project
Linux From Scratch
Linux Software Map
LinuxQuestions.org
Linux User Group (LUG)
List of Linux books
List of free and open-source software packages
List of live CDs
Live USB
List of software bugs
List of computer security certifications
List of computing and IT abbreviations
List of Linux distributions
List of games released on Linux
List of open-source mobile phones
List of operating systems
Loadable kernel module
Usage share of operating systems
Timeline of operating systems
Notes
 util-linux is the standard set of utilities for use as part of the Linux operating system.[3][non-primary source needed]
 BusyBox is a userland written with size-optimization and limited resources in mind, used in many embedded Linux distributions. BusyBox replaces most GNU Core Utilities.[4] One notable Desktop distribution using BusyBox is Alpine Linux.[5]
 GNU is a userland used in various Linux distributions.[6][7][8] The GNU userland contains system daemons, user applications, the GUI, and various libraries. GNU Core Utilities are an essential part of most distributions. Most Linux distributions use the X Window system.[9] Other components of the userland, such as the widget toolkit, vary with the specific distribution, desktop environment, and user configuration.[10]
 Plan 9 from User Space (aka plan9port) is a port of many Plan 9 libraries and programs from their native Plan 9 environment to Unix-like operating systems, including Linux and FreeBSD.[11][12]
 Toybox is a userland that combines over 200 Unix command line utilities together into a single BSD-licensed executable. After a talk at the 2013 Embedded Linux Conference, Google merged toybox into AOSP and began shipping toybox in Android Marshmallow in 2015.[13]
 The name "Linux" itself is a trademark owned by Linus Torvalds[15] and administered by the Linux Mark Institute.
 As measured by the TOP500 list, which uses HPL to measure computational power
 As measured by the TOP500 list, which uses HPL to measure computational power
References
 Linux Online (2008). "Linux Logos and Mascots". Archived from the original on August 15, 2010. Retrieved August 11, 2009.
 "Linus Torvalds reveals the 'true' anniversary of Linux code". ZDNet. Retrieved August 29, 2025.
 "The util-linux code repository". GitHub. Retrieved October 31, 2024.
 "The Busybox about page". busybox.net. Archived from the original on November 27, 2021. Retrieved November 30, 2021.
 "The Alpine Linux about page". alpinelinux.org. Archived from the original on May 8, 2011. Retrieved November 30, 2021.
 "GNU Userland". April 10, 2012. Archived from the original on March 8, 2016.
 "Unix Fundamentals — System Administration for Cyborgs". Archived from the original on October 5, 2016.
 "Operating Systems — Introduction to Information and Communication Technology". Archived from the original on February 21, 2016.
 "The X Window System". Archived from the original on January 20, 2016.
 "PCLinuxOS Magazine – HTML". Archived from the original on May 15, 2013.
 "Plan 9 from User Space". Retrieved October 31, 2024.
 "The Plan 9 from User Space code repository". GitHub. Retrieved October 31, 2024.
 Landley, Robert. "What is ToyBox?". Toybox project website. Archived from the original on November 5, 2023. Retrieved October 31, 2024.
 "The Linux Kernel Archives: Frequently asked questions". kernel.org. September 2, 2014. Archived from the original on September 5, 2015. Retrieved September 4, 2015.
 "U.S. Reg No: 1916230". United States Patent and Trademark Office. Archived from the original on June 24, 2013. Retrieved April 1, 2006.
 "Re: How to pronounce Linux?". Newsgroup: comp.os.linux. April 23, 1992. Usenet: 1992Apr23.123216.22024@klaava.Helsinki.FI. Retrieved January 9, 2007.
 Eckert, Jason W. (2012). Linux+ Guide to Linux Certification (Third ed.). Boston, Massachusetts: Cengage Learning. p. 33. ISBN 978-1111541538. Archived from the original on May 9, 2013. Retrieved April 14, 2013. The shared commonality of the kernel is what defines a system's membership in the Linux family; the differing OSS applications that can interact with the common kernel are what differentiate Linux distributions.
 "Twenty Years of Linux according to Linus Torvalds". ZDNet. April 13, 2011. Archived from the original on September 19, 2016. Retrieved September 19, 2016.
 Linus Benedict Torvalds (October 5, 1991). "Free minix-like kernel sources for 386-AT". Newsgroup: comp.os.minix. Archived from the original on March 2, 2013. Retrieved September 30, 2011.
 "Mac, Windows And Now, Linux". The New York Times. October 8, 1998. Retrieved December 4, 2024.
 "Major Distributions An overview of major Linux distributions and FreeBSD". Distrowatch. Archived from the original on April 2, 2013. Retrieved November 15, 2024.
 Andrus, Brian (July 8, 2024). "Top 12 Most Popular Linux Distros". DreamHost Blog. Retrieved November 15, 2024.
 DistroWatch. "DistroWatch.com: Put the fun back into computing. Use Linux, BSD". distrowatch.com. Archived from the original on April 2, 2013. Retrieved December 30, 2016.
 himanshu, Swapnil. "Best Linux distros of 2016: Something for everyone". CIO. Archived from the original on December 31, 2016. Retrieved February 1, 2022.
 "10 Top Most Popular Linux Distributions of 2016". www.tecmint.com. Archived from the original on December 30, 2016. Retrieved December 30, 2016.
 Ha, Dan (February 28, 2023). "9 reasons Linux is a popular choice for servers". LogicMonitor. Retrieved December 11, 2024.
 "Linux OS on IBM Z Mainframe". www.ibm.com. Retrieved December 11, 2024.
 "GNU/Linux FAQ". Gnu.org. Archived from the original on September 7, 2013. Retrieved September 1, 2013.
 "Linux and the GNU System". Gnu.org. Archived from the original on March 19, 2017. Retrieved September 1, 2013.
 Barry Levine (August 26, 2013). "Linux' 22th [sic] Birthday Is Commemorated – Subtly – by Creator". Simpler Media Group, Inc. Archived from the original on May 18, 2015. Retrieved May 10, 2015. Originally developed for Intel x86-based PCs, Torvalds' "hobby" has now been released for more hardware platforms than any other OS in history.
 Linksvayer, Mike (1993). "The Choice of a GNU Generation – An Interview With Linus Torvalds". Meta magazine. Archived from the original on February 25, 2009. Retrieved January 20, 2009.
 Bentson, Randolph. "The Humble Beginnings of Linux". dl.acm.org. Retrieved November 21, 2024.
 "History of Unix, BSD, GNU, and Linux – CrystalLabs — Davor Ocelic's Blog". crystallabs.io. Archived from the original on November 22, 2024. Retrieved November 22, 2024.
 "LINUX: UNIX POWER FOR PEANUTS". Washington Post. May 22, 1995.
 "What is Linux?". Opensource.com. Archived from the original on May 13, 2020. Retrieved May 12, 2020.
 "Various Licenses and Comments about Them – GNU Project – Free Software Foundation". www.gnu.org. Archived from the original on July 20, 2017. Retrieved November 15, 2024.
 "GNU General Public License". GNU.org. Archived from the original on February 5, 2021. Retrieved November 15, 2024.
 Casad, Joe. "Copyleft » Linux Magazine". Linux Magazine. Archived from the original on October 14, 2024. Retrieved November 15, 2024.
 "Linux kernel licensing rules". Linux kernel documentation. Archived from the original on September 6, 2022. Retrieved June 17, 2022.
 Linux-syscall-note on GitHub
 "Operating System Market Share Worldwide". StatCounter Global Stats. Archived from the original on February 15, 2020. Retrieved October 18, 2020.
 McPherson, Amanda (December 13, 2012). "What a Year for Linux: Please Join us in Celebration". Linux Foundation. Archived from the original on April 17, 2014. Retrieved April 16, 2014.
 Linux Devices (November 28, 2006). "Trolltech rolls "complete" Linux smartphone stack". Retrieved January 12, 2017.
 "Desktop Operating System Market Share Worldwide". StatCounter Global Stats. Archived from the original on March 21, 2024. Retrieved March 23, 2024.
 "ChromeOS Kernel" (PDF). kernel-recipes.org. Archived from the original (PDF) on March 24, 2024. Retrieved December 11, 2024.
 "How the Google Chrome OS Works". HowStuffWorks. June 30, 2010. Retrieved December 11, 2024.
 Steven J. Vaughan-Nichols. "Chromebook shipments leap by 67 percent". ZDNet. Archived from the original on September 29, 2015. Retrieved September 29, 2015.
 "OS Market Share and Usage Trends". W3Cook.com. Archived from the original on August 6, 2015.
 Thibodeau, Patrick (2009). "IBM's newest mainframe is all Linux". Computerworld (published December 9, 2009). Archived from the original on November 11, 2016. Retrieved February 22, 2009.
 Vaughan-Nichols, Steven J. (2017). "Linux totally dominates supercomputers". ZDNet (published November 14, 2017). Archived from the original on November 14, 2017. Retrieved October 25, 2018.
 Lyons, Daniel (March 15, 2005). "Linux rules supercomputers". Forbes. Archived from the original on February 24, 2007. Retrieved February 22, 2007.
 Eric Brown (March 29, 2019). "Linux continues advance in smart TV market". linuxgizmos.com. Archived from the original on June 29, 2020. Retrieved May 15, 2020.
 "Sony Open Source Code Distribution Service". Sony Electronics. Archived from the original on October 4, 2011. Retrieved October 8, 2011.
 "Sharp Liquid Crystal Television Instruction Manual" (PDF). Sharp Electronics. p. 24. Archived from the original (PDF) on January 11, 2012. Retrieved October 8, 2011.
 Steven J. Vaughan-Nichols (January 4, 2019). "It's a Linux-powered car world". ZDNet. Archived from the original on August 3, 2020. Retrieved May 15, 2020.
 "From Earth to orbit with Linux and SpaceX". ZDNet. Archived from the original on August 3, 2020. Retrieved June 6, 2020.
 "Linux on Mars!". IT PRO. August 18, 2021. Archived from the original on May 19, 2022. Retrieved June 30, 2022.
 Ritchie, D.M. (October 1984), "The UNIX System: The Evolution of the UNIX Time-sharing System", AT&T Bell Laboratories Technical Journal, 63 (8): 1577, Bibcode:1984BSTJ...63.1577R, doi:10.1002/j.1538-7305.1984.tb00054.x, S2CID 571269, However, UNIX was born in 1969 ...
 Meeker, Heather (September 21, 2017). "Open source licensing: What every technologist should know". Opensource.com. Archived from the original on September 24, 2017. Retrieved September 24, 2017.
 "AT&T Breakup II: Highlights in the History of a Telecommunications Giant". Los Angeles Times. September 21, 1995.
 Michael Vetter (August 10, 2021). Acquisitions and Open Source Software Development. Springer Nature. p. 13. ISBN 978-3-658-35084-0. Archived from the original on August 5, 2022. Retrieved August 5, 2022.
 Christopher Tozzi (August 11, 2017). For Fun and Profit: A History of the Free and Open Source Software Revolution. MIT Press. p. 52. ISBN 978-0-262-03647-4. Archived from the original on August 5, 2022. Retrieved August 5, 2022.
 Eric, S. Raymond (October 1999). The Cathedral and the Bazaar. Sebastopol, California: O'Reilly & Associates, Inc. p. 12. ISBN 0-596-00108-8. Archived from the original on July 18, 2022. Retrieved July 21, 2022. In 1982, a group of Unix hackers from Stanford and Berkeley founded Sun Microsystems on the belief that Unix running on relatively inexpensive 68000-based hardware would prove a winning combination for a wide variety of applications. They were right, and their vision set the pattern for an entire industry. While still priced out of reach of most individuals, workstations were cheap for corporations and universities; networks of them (one to a user) rapidly replaced the older VAXes and other time-sharing systems
 Lazzareschi, Carla (January 31, 1988). "Sun Microsystems Is Blazing a Red-Hot Trail in Computers: $300-Million AT&T; Deal Moves Firm to Set Sights on IBM". Los Angeles Times. Archived from the original on July 21, 2022. Retrieved July 21, 2022.
 "About the GNU Project – Initial Announcement". Gnu.org. June 23, 2008. Archived from the original on March 5, 2009. Retrieved March 9, 2009.
 Christopher Tozzi (August 23, 2016). "Open Source History: Why Did Linux Succeed?". Archived from the original on August 17, 2017. Retrieved August 17, 2017.
 "MINIX is now available under the BSD license". minix1.woodhull.com. April 9, 2000. Archived from the original on March 4, 2016.
 Moody, Glyn (August 1, 1997). "The Greatest OS That (N)ever Was". Wired. Archived from the original on July 25, 2022. Retrieved July 20, 2022.
 Torvalds, Linus. "What would you like to see most in minix?". Newsgroup: comp.os.minix. Usenet: 1991Aug25.205708.9541@klaava.Helsinki.FI. Archived from the original on May 9, 2013. Retrieved September 9, 2006.
 Torvalds, Linus; Diamond, David (2001). Just for Fun: The Story of an Accidental Revolutionary. New York City: HarperCollins. pp. 78–80. ISBN 0-06-662073-2.
 Linus Torvalds (October 14, 1992). "Chicken and egg: How was the first linux gcc binary created??". Newsgroup: comp.os.minix. Usenet: 1992Oct12.100843.26287@klaava.Helsinki.FI. Archived from the original on May 9, 2013. Retrieved August 17, 2013.
 Torvalds, Linus (January 5, 1992). "Release notes for Linux v0.12". Linux Kernel Archives. Archived from the original on August 19, 2007. Retrieved July 23, 2007. The Linux copyright will change: I've had a couple of requests to make it compatible with the GNU copyleft, removing the "you may not distribute it for money" condition. I agree. I propose that the copyright be changed so that it confirms to GNU ─ pending approval of the persons who have helped write code. I assume this is going to be no problem for anybody: If you have grievances ("I wrote that code assuming the copyright would stay the same") mail me. Otherwise, The GNU copyleft takes effect since the first of February. If you do not know the gist of the GNU copyright ─ read it.
 "Overview of the GNU System". Gnu.org. Archived from the original on February 28, 2009. Retrieved March 9, 2009.
 "Linus vs. Tanenbaum debate". Archived from the original on October 3, 2012. Retrieved February 19, 2014.
 "GNU General Public License, version 2". GNU Project. June 2, 1991. Archived from the original on December 7, 2013. Retrieved December 5, 2013.
 Torvalds, Linus (January 26, 2006). "Re: GPL V3 and Linux ─ Dead Copyright Holders". Linux Kernel Mailing List. Archived from the original on July 9, 2014.
 Torvalds, Linus (September 25, 2006). "Re: GPLv3 Position Statement". Linux Kernel Mailing List. Archived from the original on April 22, 2014.
 Brett Smith (July 29, 2013). "Neutralizing Laws That Prohibit Free Software — But Not Forbidding DRM". A Quick Guide to GPLv3. GNU Project. Archived from the original on December 1, 2013. Retrieved December 5, 2013.
 "Keeping an Eye on the Penguin". Linux-watch.com. February 7, 2006. Retrieved November 9, 2010.
 Wheeler, David A (July 29, 2002). "More Than a Gigabuck: Estimating GNU/Linux's Size". Archived from the original on April 21, 2006. Retrieved May 11, 2006.
 Johnston, Louis; Williamson, Samuel H. (2023). "What Was the U.S. GDP Then?". MeasuringWorth. Retrieved November 30, 2023. United States Gross Domestic Product deflator figures follow the MeasuringWorth series.
 Amor, Juan José; et al. (June 17, 2007). "Measuring Etch: the size of Debian 4.0". Archived from the original on July 28, 2014. Retrieved September 16, 2007.
 "Linux Timeline". Linux Journal. May 31, 2006. Archived from the original on February 3, 2013.
 Neil McAllister (September 5, 2005). "Linus gets tough on Linux trademark". InfoWorld. Archived from the original on April 12, 2008. Retrieved February 24, 2008.
 "Linux Mark Institute". Archived from the original on February 13, 2008. Retrieved February 24, 2008. LMI has restructured its sublicensing program. Our new sublicense agreement is: Free – approved sublicense holders pay no fees; Perpetual – sublicense terminates only in breach of the agreement or when your organization ceases to use its mark; Worldwide – one sublicense covers your use of the mark anywhere in the world
 Richard Stallman (April 28, 1996). "The FSF is no longer sponsoring Debian". tech-insider.org. Archived from the original on February 21, 2014. Retrieved February 8, 2014.
 "TiVo ─ GNU/Linux Source Code". Archived from the original on May 19, 2007. Retrieved December 12, 2006.
 "About Debian". debian.org. December 8, 2013. Archived from the original on January 23, 2014. Retrieved January 30, 2014.
 Andrew D. Balsa; et al. (October 17, 2009). "The linux-kernel mailing list FAQ". vger.kernel.org. Archived from the original on October 1, 2012. Retrieved June 13, 2013. ...we have tried to use the word "Linux" or the expression "Linux kernel" to designate the kernel, and GNU/Linux to designate the entire body of GNU/GPL'ed OS software,... ...many people forget that the linux kernel mailing list is a forum for discussion of kernel-related matters, not GNU/Linux in general...
 Côrte-Real, Pedro (May 31, 2011). "How much GNU is there in GNU/Linux?". Split Perspective. Archived from the original on February 7, 2014. Retrieved January 28, 2014. (self-published data)
 Torvalds, Linus and Diamond, David, Just for Fun: The Story of an Accidental Revolutionary, 2001, ISBN 0-06-662072-4
 Torvalds, Linus (March 1994). "Index of /pub/linux/kernel/SillySounds". Archived from the original on October 8, 2009. Retrieved August 3, 2009.
 Garfinkel, Simson; Spafford, Gene; Schwartz, Alan (2003). Practical UNIX and Internet Security. O'Reilly. p. 21.
 Santhanam, Anand; Vishal Kulkarni (March 1, 2002). "Linux system development on an embedded device". DeveloperWorks. IBM. Archived from the original on March 29, 2007. Retrieved July 26, 2007.
 Galli, Peter (August 8, 2007). "Vista Aiding Linux Desktop, Strategist Says". eWEEK. Ziff Davis Enterprise Inc. Archived from the original on July 9, 2009. Retrieved November 19, 2007.
 Paul, Ryan (September 3, 2007). "Linux market share set to surpass Win 98, OS X still ahead of Vista". Ars Technica. Ars Technica, LLC. Archived from the original on November 16, 2007. Retrieved November 19, 2007.
 Beer, Stan (January 23, 2007). "Vista to play second fiddle to XP until 2009: Gartner". iTWire. Archived from the original on December 3, 2008. Retrieved November 19, 2007.
 "Operating System Marketshare for Year 2007". Market Share. Net Applications. November 19, 2007. Archived from the original on June 24, 2013. Retrieved November 19, 2007.
 "Vista slowly continues its growth; Linux more aggressive than Mac OS during the summer". XiTiMonitor. AT Internet/XiTi.com. September 24, 2007. Archived from the original on December 14, 2007. Retrieved November 19, 2007.
 "Global Web Stats". W3Counter. Awio Web Services LLC. November 10, 2007. Retrieved November 19, 2007.
 "June 2004 Zeitgeist". Google Press Center. Google Inc. August 12, 2004. Archived from the original on July 11, 2011. Retrieved November 19, 2007.
 McMillan, Robert (October 10, 2003). "IBM, Brazilian government launch Linux effort". www.infoworld.com. IDG News Service. Archived from the original on March 15, 2015. Retrieved February 16, 2015.
 "About Us – The Linux Foundation". Archived from the original on October 28, 2018. Retrieved October 1, 2018.
 "Staff and Board — Free Software Foundation — Working together for free software". Free Software Foundation. Archived from the original on November 21, 2023. Retrieved November 22, 2023.
 "Free software is a matter of liberty, not price — Free Software Foundation — working together for free software". Fsf.org. Archived from the original on July 14, 2012. Retrieved July 12, 2012.
 Wheeler, David A. "Why Open Source Software/Free Software (OSS/FS)? Look at the Numbers!". Archived from the original on April 5, 2006. Retrieved April 1, 2006.
 "Linux Operating System Market Size, Share and Forecast [2020–2027]". www.fortunebusinessinsights.com. Archived from the original on November 12, 2021. Retrieved November 12, 2021.
 "The rise and rise of Linux". Computer Associates International. October 10, 2005. Archived from the original on February 17, 2007.
 Jeffrey S. Smith. "Why customers are flocking to Linux". IBM. Archived from the original on June 3, 2008.
 "W3Cook FAQ". W3Cook.com. Archived from the original on June 27, 2015. Retrieved June 30, 2015.
 "OS Market Share and Usage Trends". W3Cook.com. Archived from the original on August 6, 2015. Retrieved June 30, 2015.
 "Technologies Overview – methodology information". W3Techs. Retrieved June 30, 2015.
 "Linux vs. Windows usage statistics, November 2021". W3Techs. Retrieved November 14, 2021.
 "Usage Statistics and Market Share of Unix for Websites, November 2021". W3Techs. Retrieved November 14, 2021.
 "─ IDC Q1 2007 report". Linux-watch.com. May 29, 2007. Retrieved March 9, 2009.
 "Server Operating System Market Size | Mordor Intelligence". www.mordorintelligence.com. Archived from the original on December 19, 2024. Retrieved December 17, 2024.
 "Worldwide Server Market Summary and Outlook, 4Q23". IDC: The premier global market intelligence company. Retrieved December 17, 2024.
 Elad, Barry (February 3, 2024). "Linux Statistics 2024 By Market Share, Usage Data, Number Of Users and Facts". Enterprise Apps Today. Retrieved December 17, 2024.
 "Linux Statistics 2024". TrueList. Retrieved December 17, 2024.
 Elad, Barry (February 3, 2024). "Linux Statistics 2024 By Market Share, Usage Data, Number Of Users and Facts". Enterprise Apps Today. Retrieved December 17, 2024.
 "Linux Statistics 2024". TrueList. Retrieved December 17, 2024.
 "Usage Statistics and Market Share of Linux for Websites, December 2024". w3techs.com. Archived from the original on October 1, 2021. Retrieved December 17, 2024.
 "Mobile Operating System Market Share Worldwide". StatCounter Global Stats. Archived from the original on October 11, 2020. Retrieved May 30, 2023.
 Egham (March 3, 2014). "Gartner Says Worldwide Tablet Sales Grew 68 Percent in 2013, With Android Capturing 62 Percent of the Market". Archived from the original on April 17, 2014. Retrieved June 13, 2014.
 "Mobile/Tablet Operating System Market Share". Netmarketshare.com. Archived from the original on June 28, 2021. Retrieved October 14, 2021.
 Strauss, Daryll. "Linux Helps Bring Titanic to Life". Archived from the original on January 12, 2012. Retrieved July 28, 2011.
 Rowe, Robin. "Linux and Star Trek". Archived from the original on July 12, 2011. Retrieved July 28, 2011.
 "Industry of Change: Linux Storms Hollywood". Archived from the original on April 11, 2009. Retrieved March 11, 2009.
 "Tux with Shades, Linux in Hollywood". Archived from the original on January 11, 2023. Retrieved March 11, 2009.
 "Weta Digital – Jobs". Archived from the original on December 30, 2010. Retrieved November 17, 2010.
 "LinuxMovies.org – Advancing Linux Motion Picture Technology". Archived from the original on March 1, 2012. Retrieved March 16, 2012.
 "LV: Minister: "Open standards improve efficiency and transparency"". Archived from the original on August 9, 2011. Retrieved February 21, 2009.
 "Linux Spreads its Wings in India". Archived from the original on July 28, 2011. Retrieved February 21, 2009.
 "Kerala shuts windows, schools to use only Linux". March 4, 2008. Archived from the original on May 15, 2011. Retrieved June 22, 2009.
 "China's Microprocessor Dilemma". Microprocessor Report. Archived from the original on September 18, 2009. Retrieved April 15, 2009.
 Krane, Jim (November 30, 2001). "Some countries are choosing Linux systems over Microsoft". Seattle Post-Intelligencer. Archived from the original on March 15, 2012. Retrieved February 21, 2009.
 "North Korea's 'paranoid' computer operating system revealed". The Guardian. December 27, 2015. Archived from the original on December 31, 2015. Retrieved December 31, 2015.
 Email correspondence on the Linux Kernel development mailing list Linus Torvalds (November 30, 2001). "Re: Coding style, a non-issue". kernel.org. Archived from the original on August 12, 2021. Retrieved August 10, 2020.
 Raymond, Eric S. (2001). O'Reilly, Tim (ed.). The Cathedral and the Bazaar: Musings on Linux and Open Source by an Accidental Revolutionary (Second ed.). O'Reilly & Associates. p. 16. ISBN 0-596-00108-8.
 "You have to design it you cannot asymptotically reach Security." Cantrill 2017[full citation needed]
 The Cantrill Strikes Back | BSD Now 117. Jupiter Broadcasting. November 26, 2015. Archived from the original on December 14, 2020. Retrieved September 7, 2021 – via YouTube.
 "Why is Linux called a monolithic kernel?". stackoverflow.com. 2009. Archived from the original on October 17, 2013. Retrieved October 16, 2013.
 "Anatomy of a Linux System" (PDF). O'Reilly. July 23–26, 2001. Archived (PDF) from the original on September 4, 2019. Retrieved October 10, 2018.
 "Wayland vs. Xorg: Will Wayland Replace Xorg?". CBT Nuggets. Retrieved December 26, 2024.
 "What's the deal with X11 and Wayland? – TUXEDO Computers". www.tuxedocomputers.com. Retrieved December 26, 2024.
 "Admin Guide README". Kernel.org git repositories.
 M. Tim Jones (May 31, 2006). "Inside the Linux boot process". IBM Developer Works. Archived from the original on October 17, 2013. Retrieved October 16, 2013.
 "What are the Different Types of Shells in Linux? | DigitalOcean". www.digitalocean.com. Retrieved November 17, 2024.
 "Understanding Linux Shells". Hivelocity Hosting. Retrieved November 17, 2024.
 Jake Edge (June 8, 2013). "The Wayland Situation: Facts About X vs. Wayland (Phoronix)". LWN.net. Archived from the original on October 22, 2013. Retrieved October 11, 2013.
 Miller, Matthew (May 6, 2022). "Announcing Fedora 36". Archived from the original on August 2, 2022. Retrieved October 28, 2022.
 Leiva-Gomez, Miguel (May 18, 2023). "What Is Wayland and What Does It Mean for Linux Users?". www.maketecheasier.com. Archived from the original on January 27, 2021. Retrieved June 18, 2024.
 "Linux TV: Television with Linux". linuxtv.org. Archived from the original on November 6, 2013. Retrieved October 16, 2013.
 Jonathan Corbet (October 11, 2006). "The Video4Linux2 API: an introduction". LWN.net. Archived from the original on October 7, 2013. Retrieved October 16, 2013.
 "Part I. Video for Linux Two API Specification". Chapter 7. Changes. linuxtv.org. Archived from the original on October 17, 2013. Retrieved October 16, 2013.
 Operating System Market Share (November 2009). "Operating System Market Share". Archived from the original on January 25, 2010. Retrieved December 11, 2009.
 "What is Copyleft? – GNU Project – Free Software Foundation". www.gnu.org. Archived from the original on October 6, 2015. Retrieved May 12, 2020.
 "POSIX.1 (FIPS 151-2) Certification". Archived from the original on February 26, 2012.
 "How source code compatible is Debian with other Unix systems?". Debian FAQ. the Debian project. Archived from the original on October 16, 2011.
 Eissfeldt, Heiko (August 1, 1996). "Certifying Linux". Linux Journal. Archived from the original on April 4, 2016.
 "The Debian GNU/Linux FAQ – Compatibility issues". Archived from the original on October 10, 2011. Retrieved September 17, 2011.
 Proven, Liam (January 17, 2023). "Unix is dead. Long live Unix!". The Register. Archived from the original on May 5, 2025. Retrieved May 13, 2025.
 comments, 26 Jul 2018 Steve OvensFeed 151up 9. "The evolution of package managers". Opensource.com. Archived from the original on July 26, 2018. Retrieved May 12, 2020.
 "Get Fedora". getfedora.org. Archived from the original on July 11, 2020. Retrieved February 24, 2020.
 design, Cynthia Sanchez: front-end and UI, Zvezdana Marjanovic: graphic. "The makers' choice for sysadmins, developers and desktop users". openSUSE. Archived from the original on August 5, 2005. Retrieved February 24, 2020.
 Inshanally, Philip (September 26, 2018). CompTIA Linux+ Certification Guide: A comprehensive guide to achieving LX0-103 and LX0-104 certifications with mock exams. Packt Publishing Ltd. p. 180. ISBN 978-1-78934-253-6.
 Barrett, Daniel J. (August 27, 2024). Linux kurz & gut: Die wichtigen Befehle (in German). O'Reilly. p. 61. ISBN 978-3-96010-868-9.
 Linux Format. "Linux Format DVD contents". Archived from the original on August 8, 2008. Retrieved January 17, 2008.
 linux-magazine.com. "Current Issue". Archived from the original on January 10, 2008. Retrieved January 17, 2008.
 "State of Linux Kernel Development 2017". Linux Foundation. Archived from the original on November 14, 2021. Retrieved November 14, 2021.
 "From Freedom to Profit: Red Hat's Latest Move – An In-Depth Review of its Impact on Free Software and Open Source Values". Linux Careers. Retrieved November 16, 2024.
 Thompson, Ben (November 11, 2020). "Apple's Shifting Differentiation". Stratechery by Ben Thompson. Retrieved December 17, 2024.
 Equity, International Brand (May 28, 2024). "Apple Business Model Analysis". International Brand Equity (IBE). Retrieved December 17, 2024.
 "gfortran – the GNU Fortran compiler, part of GCC". GNU GCC. Archived from the original on April 18, 2020. Retrieved May 3, 2020.
 "GCC, the GNU Compiler Collection". www.gnu.org. Archived from the original on August 27, 2024. Retrieved December 17, 2024.
 "GCC vs. Clang/LLVM: An In-Depth Comparison of C/C++ Compilers".
 Das, Shakti (October 1, 2023). "Understanding Regular Expressions in Shell Scripting". Learn Scripting. Retrieved December 17, 2024.
 "Regular Expressions in Grep (Regex)". linuxize.com. March 11, 2020. Archived from the original on January 17, 2025. Retrieved December 17, 2024.
 "Sculpting text with regex, grep, sed and awk". matt.might.net. Archived from the original on December 17, 2024. Retrieved December 17, 2024.
 Brockmeier, Joe (October 3, 2005). "A survey of Linux Web development tools". Archived from the original on October 19, 2006. Retrieved December 16, 2006.
 Intel, Altus (September 25, 2024). "Elks 0.8 Released: Linux for 16-bit Intel CPUs". Altus Intel. Archived from the original on November 27, 2024. Retrieved November 16, 2024.
 "UClinux". community.intel.com. June 26, 2019. Retrieved November 16, 2024.
 Das, Ankush (January 21, 2021). "Finally! Linux Runs Gracefully On Apple M1 Chip". It's FOSS News. Archived from the original on November 13, 2021. Retrieved November 13, 2021.
 Jimenez, Jorge (October 8, 2021). "Developers finally get Linux running on an Apple M1-powered Mac". PC Gamer. Archived from the original on January 11, 2023. Retrieved November 13, 2021.
 Proven, Liam (November 10, 2022). "OpenPrinting keeps old printers working, even on Windows". The Register. Archived from the original on January 7, 2023. Retrieved January 7, 2023.
 Bruce Byfield (August 14, 2007). "Is my hardware Linux-compatible? Find out here". Linux.com. Archived from the original on September 5, 2015. Retrieved September 4, 2015.
 "Linux Hardware". Linux Hardware Project. Archived from the original on January 26, 2021. Retrieved June 26, 2020.
External links
	Free and open-source software portal
icon	Linux portal
Linux
at Wikipedia's sister projects
Wiktionary logoDefinitions from Wiktionary
Wikimedia Commons logoMedia from Commons
Wikinews logoNews from Wikinews
Quotations from Wikiquote
Wikisource logoTexts from Wikisource
Wikibooks logoTextbooks from Wikibooks
Wikiversity logoResources from Wikiversity
Graphical map of Linux Internals (archived)
Linux kernel website and archives
The History of Linux in GIT Repository Format 1992–2010 (archived)
vte
Linux
vte
Contributors to the Linux operating system
vte
Linux distributions
vte
Unix and Unix-like operating systems and compatibility layers
vte
Free and open-source software
vte
Operating systems
Authority control databases Edit this at Wikidata
Categories: Linux1991 softwareComputing platformsCross-platform softwareFinnish inventionsFree software programmed in CLinus TorvaldsOperating systemsUnix variantsOpen source projects
This page was last edited on 4 April 2026, at 09:52 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policyAbout WikipediaDisclaimersContact WikipediaLegal & safety contactsCode of ConductDevelopersStatisticsCookie statementMobile view
Wikimedia Foundation
Powered by MediaWiki

    """
    """

WikipediaThe Free Encyclopedia
Search Wikipedia
Search
Donate
Create account
Log in
Contents hide
(Top)
Product line
History

Version control system

Timeline of releases
Usage share and device sales
Security

Alternative implementations
See also
References
External links
Microsoft Windows

Article
Talk
Read
View source
View history

Tools
Appearance hide
Birthday mode (Baby Globe)

Disabled

Enabled
Learn more about Birthday mode
Text

Small

Standard

Large
Width

Standard

Wide
Color (beta)

Automatic

Light

Dark
Page semi-protected
From Wikipedia, the free encyclopedia
"Windows" redirects here. For the architectural element, see Window. For other uses, see Windows (disambiguation).
Windows

Developer	Microsoft
Source model	
Closed-source
Source-available (through Shared Source Initiative)
Initial release	November 20, 1985; 40 years ago
Latest release	Windows 11 26H1 (10.0.28000.1764) (March 26, 2026; 10 days ago[1]) [±]
25H2 (10.0.26200.8117) (March 31, 2026; 5 days ago[2]) [±]
Latest preview	
Release Preview Channel: 25H2 (10.0.26200.8116) (March 26, 2026; 10 days ago[3][4]) [±]
Beta Channel: 25H2 (10.0.26220.8079) (March 20, 2026; 16 days ago[5]) [±]
Dev Channel: 25H2 (10.0.26300.8085) (March 20, 2026; 16 days ago[6]) [±]
Canary Channel: 26H1 (10.0.29553.1000) (March 20, 2026; 16 days ago[7]) [±]
Marketing target	Personal computing
Available in	110 languages
Update method	
Windows Update
Microsoft Store
Windows Server Update Services (WSUS)
Package manager	Windows Installer (.msi, .msp),[8] App Installer (.msix,.[9] msixbundle[10][11]), Microsoft Store (.appx, .appxbundle),[12] Windows Package Manager
Supported platforms	IA-32, x86-64, ARM, ARM64
Previously: 16-bit x86, DEC Alpha, MIPS, PowerPC, Itanium
Kernel type	
Windows NT family: Hybrid
Windows Embedded Compact/Windows CE: Hybrid or Monolithic
Windows 9x and earlier: Monolithic (MS-DOS and VMM32)
Default
user interface	Windows shell
License	Proprietary commercial software
Official website	windows.com Edit this at Wikidata
Windows is a proprietary graphical operating system developed and marketed by Microsoft. Windows is grouped into families that cater to particular sectors of the computing industry – Windows for personal computers, Windows Server for servers, and Windows IoT for embedded systems. Windows itself is further grouped into editions that cater to different users – Home for home users, Professional for advanced users, Education for schools, and Enterprise for corporations. Windows is sold both as a consumer retail product and to computer manufacturers, who bundle and distribute it with their systems.

The first version of Windows, Windows 1.0, was released on November 20, 1985 as a graphical operating system shell for MS-DOS in response to growing interest in graphical user interfaces (GUIs).[13] The name Windows is a reference to the windowing system in GUIs.[14] The 1990 release of Windows 3.0 catapulted its market success and led to the launch of various other product families, including the (now-defunct) Windows Mobile, Windows Phone, and Windows CE/Embedded Compact.

Windows is the most popular desktop operating system in the world, with a 80% market share as of February 2026,[15] and the second-most popular operating system overall, behind Android.[16] As of February 2026, Windows 11 is the most used desktop version of Windows, with a market share of 73%.[17]

Product line
All members of the Windows product family are, as of 2026, based on Windows NT. The first version of Windows in that product line, Windows NT 3.1, was intended for server computing and corporate workstations. It now consists of four sub-families that tend to be released almost simultaneously and share the same kernel.

Windows (unqualified): For a consumer or corporate workstation or tablet. The latest version is Windows 11.[18] Its main competitors are macOS by Apple and Linux for personal computers and iPadOS and Android for tablets (cf. Usage share of operating systems § Market share by category).
Of note: "Windows" refers to both the overall product line and this sub-family of it.
Windows Server: For a server computer. The latest version is Windows Server 2025. Unlike its client sibling, it has adopted a strong naming scheme. The main competitor of this family is Linux. (cf. Usage share of operating systems § Market share by category)
Windows IoT (previously Windows Embedded): For IoT and embedded computers. The latest version is Windows 11 IoT Enterprise.[19] Like Windows Server, the main competitor of this family is Linux. (cf. Usage share of operating systems § Market share by category)
Windows PE: A lightweight version of Windows designed to operate as a live operating system, used for installing Windows on bare-metal computers (especially on many computers at once), recovery, or troubleshooting purposes. The latest version is Windows PE 10.[citation needed]
These top-level Windows families are no longer actively developed:

MS-DOS-based versions of Windows, including Windows 1.0, Windows 2.0, Windows 3.x, and Windows 9x: The original top-level family of Windows prior to Windows NT, aimed at consumers. These versions had a monolithic kernel that uses MS-DOS as a foundation, with Windows 95 and above having its own kernel. The last version was Windows Me; the family was discontinued after the release of Windows XP, with all consumer-oriented versions of Windows afterwards being based on the Windows NT kernel.
Windows Mobile: Windows Mobile was a mobile phone and PDA operating system and the predecessor to Windows Phone. The first version was Pocket PC 2000; the third version, Windows Mobile 2003, was the first version to adopt the Windows Mobile trademark. The last published version was Windows Mobile 6.5.
Windows Phone: Sold only to smartphone manufacturers. The first version was Windows Phone 7, followed by Windows Phone 8 and Windows Phone 8.1. It was succeeded by Windows 10 Mobile, which is also defunct.
Windows Embedded Compact: Most commonly known by its former name, Windows CE, it is a hybrid kernel operating system optimized for low power and memory systems, with OEMs able to modify the UI to suit their needs. The final version was Windows Embedded Compact 2013, and it is succeeded by Windows IoT.[citation needed]
History
Main article: Microsoft Windows version history
See also: List of Microsoft Windows versions
The term Windows collectively describes any or all of several generations of Microsoft operating system products. These products are generally categorized as follows:

Early versions
Main articles: Windows 1.0, Windows 2.0, and Windows 2.1
The history of Windows dates back to 1981 when Microsoft started work on a program called "Interface Manager". The name "Windows" comes from the fact that the system was one of the first to use graphical boxes to represent programs; in the industry, at the time, these were called "windows" and the underlying software was called "windowing software."[14] It was announced in November 1983 (after the Apple Lisa, but before the Macintosh) under the name "Windows", but Windows 1.0 was not released until November 1985.[20] Windows 1.0 was to compete with Apple's operating system, but achieved little popularity. Windows 1.0 is not a complete operating system; rather, it extends MS-DOS. The shell of Windows 1.0 is a program known as the MS-DOS Executive. Components included Calculator, Calendar, Cardfile, Clipboard Viewer, Clock, Control Panel, Notepad, Paint, Reversi, Terminal and Write. Windows 1.0 does not allow overlapping windows. Instead, all windows are tiled. Only modal dialog boxes may appear over other windows. Microsoft sold as included Windows Development libraries with the C development environment, which included numerous windows samples.[21]

Windows 2.0 was released in December 1987, and was more popular than its predecessor. It features several improvements to the user interface and memory management.[22] Windows 2.03 changed the OS from tiled windows to overlapping windows. The result of this change led to Apple Computer filing a suit against Microsoft alleging infringement on Apple's copyrights (eventually settled in court in Microsoft's favor in 1993).[23][24] Windows 2.0 also introduced more sophisticated keyboard shortcuts and could make use of expanded memory.

Windows 2.1 was released in two different versions: Windows/286 and Windows/386. Windows/386 uses the virtual 8086 mode of the Intel 80386 to multitask several DOS programs and the paged memory model to emulate expanded memory using available extended memory. Windows/286, in spite of its name, runs on both Intel 8086 and Intel 80286 processors. It runs in real mode but can make use of the high memory area.[25]

In addition to full Windows packages, there were runtime-only versions that shipped with early Windows software from third parties and made it possible to run their Windows software on MS-DOS and without the full Windows feature set.

The early versions of Windows are often thought of as graphical shells, mostly because they ran on top of MS-DOS and used it for file system services.[26] However, even the earliest Windows versions already assumed many typical operating system functions; notably, having their own executable file format and providing their own device drivers (timer, graphics, printer, mouse, keyboard and sound). Unlike MS-DOS, Windows allowed users to execute multiple graphical applications at the same time, through cooperative multitasking. Windows implemented an elaborate, segment-based, software virtual memory scheme, which allowed it to run applications larger than available memory: code segments and resources were swapped in and thrown away when memory became scarce; data segments moved in memory when a given application had relinquished processor control.

Windows 3.x
Main articles: Windows 3.0 and Windows 3.1

Windows 3.0, released in 1990
Windows 3.0, released in 1990, improved the design, mostly because of virtual memory and loadable virtual device drivers (VxDs) that allow Windows to share arbitrary devices between multi-tasked DOS applications.[citation needed] Windows 3.0 applications can run in protected mode, which gives them access to several megabytes of memory without the obligation to participate in the software virtual memory scheme. They run inside the same address space, where the segmented memory provides a degree of protection. Windows 3.0 also featured improvements to the user interface. Microsoft rewrote critical operations from C into assembly. Windows 3.0 was the first version of Windows to achieve broad commercial success, selling 2 million copies in the first six months.[27][28]


Versions before Windows 95 had to be installed from floppy disks by end users (or in professional environments with a network installation); here Windows for Workgroups with nine 3.5-inch-disks to be inserted sequentially.
Windows 3.1, made generally available on March 1, 1992, featured a facelift. In October 1992, Windows for Workgroups, a special version with integrated peer-to-peer networking features, was released. It was sold along with Windows 3.1. Support for Windows 3.1 ended on December 31, 2001.[29]

Windows 3.2, released in 1994, is an updated version of the Chinese version of Windows 3.1.[30] The update was limited to this language version, as it fixed only issues related to the complex writing system of the Chinese language.[31] Windows 3.2 was generally sold by computer manufacturers with a ten-disk version of MS-DOS that also had Simplified Chinese characters in basic output and some translated utilities.[citation needed]

Windows 9x
Main articles: Windows 9x, Windows 95, Windows 98, and Windows Me
The next major consumer-oriented release of Windows, Windows 95, was released on August 24, 1995. While still remaining MS-DOS-based, Windows 95 introduced support for native 32-bit applications, plug and play hardware, preemptive multitasking, long file names of up to 255 characters, and provided increased stability over its predecessors. Windows 95 also introduced a redesigned, object oriented user interface, replacing the previous Program Manager with the Start menu, taskbar, and Windows Explorer shell. Windows 95 was a major commercial success for Microsoft; Ina Fried of CNET remarked that "by the time Windows 95 was finally ushered off the market in 2001, it had become a fixture on computer desktops around the world."[32] Microsoft published four OEM Service Releases (OSR) of Windows 95, each of which was roughly equivalent to a service pack. The first OSR of Windows 95 was also the first version of Windows to be bundled with Microsoft's web browser, Internet Explorer.[33] Mainstream support for Windows 95 ended on December 31, 2000, and extended support for Windows 95 ended on December 31, 2001.[34]

Windows 95 was followed up with the release of Windows 98 on June 25, 1998, which introduced the Windows Driver Model, support for USB composite devices, support for ACPI, hibernation, and support for multi-monitor configurations. Windows 98 also included integration with Internet Explorer 4 through Active Desktop and other aspects of the Windows Desktop Update (a series of enhancements to the Explorer shell which was also made available for Windows 95). In June 1999, Microsoft released Windows 98 Second Edition, an updated version of Windows 98. Windows 98 SE added Internet Explorer 5.0 and Windows Media Player 6.2 amongst other upgrades. Mainstream support for Windows 98 ended on June 30, 2002, and extended support for Windows 98 ended on July 11, 2006.[35]

On September 14, 2000, Microsoft released Windows Me (Millennium Edition), the last DOS-based version of Windows. Windows Me incorporated visual interface enhancements from its Windows NT-based counterpart Windows 2000, had faster boot times than previous versions (which however, required the removal of the ability to access a real mode DOS environment, removing compatibility with some older programs),[36] expanded multimedia functionality (including Windows Media Player 7, Windows Movie Maker, and the Windows Image Acquisition framework for retrieving images from scanners and digital cameras), additional system utilities such as System File Protection and System Restore, and updated home networking tools.[37] However, Windows Me was faced with criticism for its speed and instability, along with hardware compatibility issues and its removal of real mode DOS support. PC World considered Windows Me to be one of the worst operating systems Microsoft had ever released, and the fourth worst tech product of all time.[38]

Windows NT
Main article: Windows NT
Version history
Early versions (Windows NT 3.1/3.5/3.51/4.0/2000)
Main articles: Windows NT 3.1, Windows NT 3.5, Windows NT 3.51, Windows NT 4.0, and Windows 2000

Windows logo (1995–2001)
In November 1988, a new development team within Microsoft (which included former Digital Equipment Corporation developers Dave Cutler and Mark Lucovsky) began work on a revamped version of IBM and Microsoft's OS/2 operating system known as "NT OS/2". NT OS/2 was intended to be a secure, multi-user operating system with POSIX compatibility and a modular, portable kernel with preemptive multitasking and support for multiple processor architectures. However, following the successful release of Windows 3.0, the NT development team decided to rework the project to use an extended 32-bit port of the Windows API known as Win32 instead of those of OS/2. Win32 maintained a similar structure to the Windows APIs (allowing existing Windows applications to easily be ported to the platform), but also supported the capabilities of the existing NT kernel. Following its approval by Microsoft's staff, development continued on what was now Windows NT, the first 32-bit version of Windows. However, IBM objected to the changes, and ultimately continued OS/2 development on its own.[39][40]

Windows NT was the first Windows operating system based on a hybrid kernel. The hybrid kernel was designed as a modified microkernel, influenced by the Mach microkernel developed by Richard Rashid at Carnegie Mellon University, but without meeting all of the criteria of a pure microkernel.

The first release of the resulting operating system, Windows NT 3.1 (named to associate it with Windows 3.1) was released in July 1993, with versions for desktop workstations and servers. Windows NT 3.5 was released in September 1994, focusing on performance improvements and support for Novell's NetWare, and was followed up by Windows NT 3.51 in May 1995, which included additional improvements and support for the PowerPC architecture. Windows NT 4.0 was released in June 1996, introducing the redesigned interface of Windows 95 to the NT series. On February 17, 2000, Microsoft released Windows 2000, a successor to NT 4.0. The Windows NT name was dropped at this point in order to put a greater focus on the Windows brand.[40]

Windows XP
Main article: Windows XP

A variation of the 2001–2007 Windows logo from 2003 using the Segoe typeface instead of the Franklin Gothic typeface. This variation was mainly used for branding purposes.
The next major version of Windows NT, Windows XP, was released to manufacturing (RTM) on August 24, 2001, and to the general public on October 25, 2001. The introduction of Windows XP aimed to unify the consumer-oriented Windows 9x series with the architecture introduced by Windows NT, a change which Microsoft promised would provide better performance over its DOS-based predecessors. Windows XP would also introduce a redesigned user interface (including an updated Start menu and a "task-oriented" Windows Explorer), streamlined multimedia and networking features, Internet Explorer 6, integration with Microsoft's .NET Passport services, a "compatibility mode" to help provide backwards compatibility with software designed for previous versions of Windows, and Remote Assistance functionality.[41][42]

At retail, Windows XP was marketed in two main editions: the "Home" edition was targeted towards consumers, while the "Professional" edition was targeted towards business environments and power users, and included additional security and networking features. Home and Professional were later accompanied by the "Media Center" edition (designed for home theater PCs, with an emphasis on support for DVD playback, TV tuner cards, DVR functionality, and remote controls), and the "Tablet PC" edition (designed for mobile devices meeting its specifications for a tablet computer, with support for stylus pen input and additional pen-enabled applications).[43][44][45] Mainstream support for Windows XP ended on April 14, 2009. Extended support ended on April 8, 2014.[46]

After Windows 2000, Microsoft also changed its release schedules for server operating systems; the server counterpart of Windows XP, Windows Server 2003, was released in April 2003.[40] It was followed in March 2006, by Windows Server 2003 R2.[47]

Windows Vista
Main article: Windows Vista

Windows logo (2007-2012)
After a lengthy development process, Windows Vista was released only for volume licensing on November 30, 2006, and finally, on January 30, 2007, it was officially released to everyone, including consumers. It contained a number of new features, from a redesigned shell and user interface to significant technical changes, with a particular focus on security features. It was available in a number of different editions, and has been subject to some criticism, such as drop of performance, longer boot time, criticism of new UAC, and stricter license agreement. Vista's server counterpart, Windows Server 2008 was released in early 2008.

Windows 7
Main article: Windows 7

Windows logo (2009-2012)
On July 22, 2009, Windows 7 and Windows Server 2008 R2 were released to manufacturing (RTM) and were officially released, including for the public, months later on October 22, 2009. Unlike its predecessor, Windows Vista, which introduced a large number of new features, Windows 7 was intended to be a more focused, incremental upgrade to the Windows line, with the goal of being compatible with applications and hardware with which Windows Vista was already compatible.[48] Windows 7 has multi-touch support, a redesigned Windows shell with an updated taskbar with revealable jump lists that contain shortcuts to files frequently used with specific applications and shortcuts to tasks within the application,[49] a home networking system called HomeGroup,[50] and performance improvements.

Windows 8 and 8.1
Main articles: Windows 8 and Windows 8.1

Windows logo (2012–2015)
Windows 8, the successor to Windows 7, was released generally on October 26, 2012. A number of significant changes were made on Windows 8, including the introduction of a user interface based around Microsoft's Metro design language with optimizations for touch-based devices such as tablets and all-in-one PCs. These changes include the Start screen, which uses large tiles that are more convenient for touch interactions and allow for the display of continually updated information, and a new class of apps which are designed primarily for use on touch-based devices. The new Windows version required a minimum resolution of 1024×768 pixels,[51] effectively making it unfit for netbooks with 800×600-pixel screens.

Other changes include increased integration with cloud services and other online platforms (such as social networks and Microsoft's own OneDrive (formerly SkyDrive) and Xbox Live services), the Windows Store service for software distribution, and a new variant known as Windows RT for use on devices that utilize the ARM architecture, and a new keyboard shortcut for screenshots.[52][53][54][55][56][57][58] An update to Windows 8, called Windows 8.1,[59] was released on October 17, 2013, and includes features such as new live tile sizes, deeper OneDrive integration, and many other revisions. Windows 8 and Windows 8.1 have been subject to some criticism, such as the removal of the Start menu.

Windows 10
Main article: Windows 10

Windows logo (2015–2021)
On September 30, 2014, Microsoft announced Windows 10 as the successor to Windows 8.1. It was released on July 29, 2015, and addresses shortcomings in the user interface first introduced with Windows 8. Changes on PC include the return of the Start Menu, a virtual desktop system, and the ability to run Windows Store apps within windows on the desktop rather than in full-screen mode. Windows 10 is said to be available to update from qualified Windows 7 with SP1, Windows 8.1 and Windows Phone 8.1 devices from the Get Windows 10 Application (for Windows 7, Windows 8.1) or Windows Update (Windows 7).[60]

In February 2017, Microsoft announced the migration of its Windows source code repository from Perforce to Git. This migration involved 3.5 million separate files in a 300-gigabyte repository.[61] By May 2017, 90 percent of its engineering team was using Git, in about 8500 commits and 1760 Windows builds per day.[61]

In June 2021, shortly before Microsoft's announcement of Windows 11, Microsoft updated their lifecycle policy pages for Windows 10, revealing that support for their last release of Windows 10 will end on October 14, 2025.[62][63] On April 27, 2023, Microsoft announced that version 22H2 would be the last of Windows 10.[64][65]


Windows logo (2021–present)
Windows 11
Main article: Windows 11
On June 24, 2021, Windows 11 was announced as the successor to Windows 10 during a livestream. The new operating system was designed to be more user-friendly and understandable. It was released on October 5, 2021.[66][67] As of May 2022, Windows 11 is a free upgrade to Windows 10 users who meet the system requirements.[68]

Windows 365
See also: Azure Virtual Desktop
Not to be confused with Microsoft 365 or Windows/386.
In July 2021, Microsoft announced it will start selling subscriptions to virtualized Windows desktops as part of a new Windows 365 service in the following month. The new service will allow for cross-platform usage, aiming to make the operating system available for both Apple and Android users. It is a separate service and offers several variations including Windows 365 Frontline, Windows 365 Boot, and the Windows 365 app.[69] The subscription service will be accessible through any operating system with a web browser. The new service is an attempt at capitalizing on the growing trend, fostered during the COVID-19 pandemic, for businesses to adopt a hybrid remote work environment, in which "employees split their time between the office and home". As the service will be accessible through web browsers, Microsoft will be able to bypass the need to publish the service through Google Play or the Apple App Store.[70][71][72][73][74]

Microsoft announced Windows 365 availability to business and enterprise customers on August 2, 2021.[75]

Multilingual support
See also: Multilingual User Interface
Multilingual support has been built into Windows since Windows 3.0. The language for both the keyboard and the interface can be changed through the Region and Language Control Panel. Components for all supported input languages, such as Input Method Editors, are automatically installed during Windows installation (in Windows XP and earlier, files for East Asian languages, such as Chinese, and files for right-to-left scripts, such as Arabic, may need to be installed separately, also from the said Control Panel). Third-party IMEs may also be installed if a user feels that the provided one is insufficient for their needs. Since Windows 2000, English editions of Windows NT have East Asian IMEs (such as Microsoft Pinyin IME and Microsoft Japanese IME) bundled, but files for East Asian languages may be manually installed on Control Panel.

Interface languages for the operating system are free for download, but some languages are limited to certain editions of Windows. Language Interface Packs (LIPs) are redistributable and may be downloaded from Microsoft's Download Center and installed for any edition of Windows (XP or later) – they translate most, but not all, of the Windows interface, and require a certain base language (the language which Windows originally shipped with). This is used for most languages in emerging markets. Full Language Packs, which translate the complete operating system, are only available for specific editions of Windows (Ultimate and Enterprise editions of Windows Vista and 7, and all editions of Windows 8, 8.1 and RT except Single Language). They do not require a specific base language and are commonly used for more popular languages such as French or Chinese. These languages cannot be downloaded through the Download Center, but are available as optional updates through the Windows Update service (except Windows 8).

The interface language of installed applications is not affected by changes in the Windows interface language. The availability of languages depends on the application developers themselves.

Windows 8 and Windows Server 2012 introduce a new Language Control Panel where both the interface and input languages can be simultaneously changed, and language packs, regardless of type, can be downloaded from a central location. The PC Settings app in Windows 8.1 and Windows Server 2012 R2 also includes a counterpart settings page for this. Changing the interface language also changes the language of preinstalled Windows Store apps (such as Mail, Maps and News) and certain other Microsoft-developed apps (such as Remote Desktop). The above limitations for language packs are however still in effect, except that full language packs can be installed for any edition except Single Language, which caters to emerging markets.

Platform support
Windows NT included support for several platforms before the x86-based personal computer became dominant in the professional world. Windows NT 4.0 and its predecessors supported PowerPC, DEC Alpha and MIPS R4000 (although some of the platforms implement 64-bit computing, the OS treated them as 32-bit). Windows 2000 dropped support for all platforms, except the third generation x86 (known as IA-32) or newer in 32-bit mode. The client line of the Windows NT family still ran on IA-32 up to Windows 10[68] (the server line of the Windows NT family still ran on IA-32 up to Windows Server 2008).

With the introduction of the Intel Itanium architecture (IA-64), Microsoft released new versions of Windows to support it. Itanium versions of Windows XP and Windows Server 2003 were released at the same time as their mainstream x86 counterparts. Windows XP 64-Bit Edition (Version 2003), released in 2003, is the last Windows client operating system to support Itanium. Windows Server line continues to support this platform until Windows Server 2012; Windows Server 2008 R2 is the last Windows operating system to support Itanium architecture.

On April 25, 2005, Microsoft released Windows XP Professional x64 Edition and Windows Server 2003 x64 editions to support x86-64 (or simply x64), the 64-bit version of x86 architecture. Windows Vista was the first client version of Windows NT to be released simultaneously in IA-32 and x64 editions. As of 2024, x64 is still supported.

An edition of Windows 8 known as Windows RT was specifically created for computers with ARM architecture, and while ARM is still used for Windows smartphones with Windows 10, tablets with Windows RT will not be updated. Starting from Windows 10 Fall Creators Update (version 1709) and later includes support for ARM-based PCs.[76]

Windows CE
Main articles: Windows CE and Windows Phone
Windows CE (officially known as Windows Embedded Compact), is an edition of Windows that runs on minimalistic computers, like satellite navigation systems and some mobile phones. Windows Embedded Compact is based on its own dedicated kernel, dubbed Windows CE kernel. Microsoft licenses Windows CE to OEMs and device makers. The OEMs and device makers can modify and create their own user interfaces and experiences, while Windows CE provides the technical foundation to do so.

Windows CE was used in the Dreamcast along with Sega's own proprietary OS for the console. Windows CE was the core from which Windows Mobile was derived. Its successor, Windows Phone 7, was based on components from both Windows CE 6.0 R3 and Windows CE 7.0. Windows Phone 8 however, is based on the same NT-kernel as Windows 8.

Windows Embedded Compact is not to be confused with Windows XP Embedded or Windows NT 4.0 Embedded, modular editions of Windows based on Windows NT kernel.

Xbox OS
Main article: Xbox system software
Xbox OS is an unofficial name given to the version of Windows that runs on Xbox consoles.[77] From Xbox One onwards it is an implementation with an emphasis on virtualization (using Hyper-V) as it is three operating systems running at once, consisting of the core operating system, a second implemented for games and a more Windows-like environment for applications.[78] Microsoft updates Xbox One's OS every month, and these updates can be downloaded from the Xbox Live service to the Xbox and subsequently installed, or by using offline recovery images downloaded via a PC.[79] It was originally based on NT 6.2 (Windows 8) kernel, and the latest version runs on an NT 10.0 base. This system is sometimes referred to as "Windows 10 on Xbox One".[80][81] Xbox One and Xbox Series operating systems also allow limited (due to licensing restrictions and testing resources) backward compatibility with previous generation hardware,[82] and the Xbox 360's system is backwards compatible with the original Xbox.[83]

Version control system
Up to and including every version before Windows 2000, Microsoft used an in-house version control system named Source Library Manager (SLM). Shortly after Windows 2000 was released, Microsoft switched to a fork of Perforce named Source Depot.[84] This system was used up until 2017 once the system could not keep up with the size of Windows.[citation needed] Microsoft had begun to integrate Git into Team Foundation Server in 2013,[85] but Windows (and Office) continued to rely on Source Depot.[86] The Windows code was divided among 65 different repositories with a kind of virtualization layer to produce unified view of all of the code.[citation needed]

In 2017 Microsoft announced that it would start using Git, an open source version control system created by Linus Torvalds, and in May 2017 they reported that the migration into a new Git repository was complete.[61][87][88]

VFSForGit
Each Git repository contains a complete history of all the files, which tends to be very large for Windows.[89] Microsoft has been working on a new project called the Virtual File System for Git (VFSForGit) to address these challenges.[88]

In 2021 the VFS for Git was superseded by Scalar.[90]

Timeline of releases
Table of Windows versions
Product name	Latest version	Release date	Codename	Windows support end date[91]	Latest version of
IE	DirectX	Edge
Windows 1.0	1.04	November 20, 1985	Interface Manager	December 31, 2001	—N/a	—N/a	—N/a
Windows 2.0	2.03	December 9, 1987	—N/a
Windows 2.1	2.11	May 27, 1988	—N/a
Windows 3.0	3.0	May 22, 1990	—N/a
Windows 3.1	3.1	April 6, 1992	—N/a	5
Windows For Workgroups 3.1	3.1	October 27, 1992	Sparta, Winball
Windows NT 3.1	NT 3.1.528	July 27, 1993	Razzle	December 31, 2000	2
Windows For Workgroups 3.11	3.11	August 11, 1993	Snowball	December 31, 2001	5
Windows 3.2	3.2	November 22, 1993	—N/a
Windows NT 3.5	NT 3.5.807	September 21, 1994	Daytona	3
Windows NT 3.51	NT 3.51.1057	May 30, 1995	—N/a	5
Windows 95	4.0.950	August 24, 1995	Chicago, 4.0	5.5	8.0a
Windows NT 4.0	NT 4.0.1381	July 31, 1996	Shell Update Release	June 30, 2004	6	3.0a
Windows 98	4.10.1998	June 25, 1998	Memphis, 97, 4.1	July 11, 2006	9.0c
Windows 98 SE	4.10.2222	June 10, 1999	—N/a
Windows 2000	NT 5.0.2195	February 17, 2000	—N/a	July 13, 2010
Windows Me	4.90.3000	September 14, 2000	Millennium, 4.9	July 11, 2006
Windows XP	NT 5.1.2600	October 25, 2001	Whistler	April 8, 2014	8
Windows XP 64-bit Edition	NT 5.2.3790	March 28, 2003	—N/a
Windows Server 2003	April 24, 2003	Whistler Server	July 14, 2015
Windows XP Professional x64 Edition	April 25, 2005	—N/a	April 8, 2014
Windows Fundamentals for Legacy PCs	NT 5.1.2600	July 8, 2006	Eiger, Mönch
Windows Vista	NT 6.0.6003	January 30, 2007	Longhorn	April 11, 2017	9	11
Windows Home Server	NT 5.2.4500	November 4, 2007	Quattro	January 8, 2013	8	9.0c
Windows Server 2008	NT 6.0.6003	February 27, 2008	Longhorn Server	January 14, 2020	9	11
Windows 7	NT 6.1.7601	October 22, 2009	Windows 7[92]	11	109
Windows Server 2008 R2	Windows Server 7
Windows Home Server 2011	NT 6.1.8400	April 6, 2011	Vail	April 12, 2016
Windows Server 2012	NT 6.2.9200	September 4, 2012	Server 8	October 10, 2023	11.1
Windows 8	October 26, 2012	—N/a	January 12, 2016	10
Windows 8.1	NT 6.3.9600	October 17, 2013	Blue	January 10, 2023	11	11.2
Windows Server 2012 R2	October 18, 2013	Server Blue	October 10, 2023
Windows 10	NT 10.0.19045	July 29, 2015	Various	October 14, 2025[62][63]	12	146
Windows Server 2016	NT 10.0.14393	October 12, 2016	—N/a	January 12, 2027
Windows Server 2019	NT 10.0.17763	October 2, 2018	—N/a	January 9, 2029
Windows Server 2022	NT 10.0.20348	August 18, 2021	—N/a	October 14, 2031
Windows 11	NT 10.0.28000	October 5, 2021	Various	March 13, 2029[93]	—N/a
Windows Server 2025	NT 10.0.26100	November 1, 2024	—N/a	November 14, 2034
Legend:
Unsupported
Supported
Latest version
Preview version
Timeline of Windows versions vte

The Windows family tree
Usage share and device sales
Main article: Usage share of operating systems
This box: viewtalkedit

Version market share
As a percentage of desktop and laptop systems using Microsoft Windows,[94] according to StatCounter data as of April 2026[95]:

Desktop OS	StatCounter
Other versions	0.02%
Windows XP	0.06%
Windows 7	1.04%
Windows 8	0.03%
Windows 8.1	0.11%
Windows 10	31.21%
Windows 11	67.53%

Use of Windows 10 has exceeded Windows 7 globally since early 2018.[96]

For desktop and laptop computers, according to Net Applications and StatCounter (which track the use of operating systems in devices that are active on the Web), Windows was the most used operating-system family in August 2021, with around 91% usage share according to Net Applications[97] and around 76% usage share according to StatCounter.[98]

Including personal computers of all kinds (e.g., desktops, laptops, mobile devices, and game consoles), Windows OSes accounted for 32.67% of usage share in August 2021, compared to Android (highest, at 46.03%), iOS's 13.76%, iPadOS's 2.81%, and macOS's 2.51%, according to Net Applications[99] and 30.73% of usage share in August 2021, compared to Android (highest, at 42.56%), iOS/iPadOS's 16.53%, and macOS's 6.51%, according to StatCounter.[100]

Those statistics do not include servers (including cloud computing, where Linux has significantly more market share than Windows) as Net Applications and StatCounter use web browsing as a proxy for all use.

Security
Early versions of Windows were designed at a time when malware and networking were less common, and had few built-in security features; they did not provide access privileges to allow a user to prevent other users from accessing their files, and they did not provide memory protection to prevent one process from reading or writing another process's address space or to prevent a process from code or data used by privileged-mode code.

While the Windows 9x series offered the option of having profiles for multiple users with separate profiles and home folders, it had no concept of access privileges, allowing any user to edit others' files. In addition, while it ran separate 32-bit applications in separate address spaces, protecting an application's code and data from being read or written by another application, it did not protect the first megabyte of memory from userland applications for compatibility reasons. This area of memory contains code critical to the functioning of the operating system, and by writing into this area of memory an application can crash or freeze the operating system. This was a source of instability as faulty applications could accidentally write into this region, potentially corrupting important operating system memory, which usually resulted in some form of system error and halt.[101]

Windows NT was far more secure, implementing access privileges and full memory protection, and, while 32-bit programs meeting the DoD's C2 security rating.[102] Prior to Windows Vista, the default user account created during the setup process was an administrator account; the user, and any program the user launched, had full access to the machine. Though Windows XP did offer an option of turning administrator accounts into limited accounts, the majority of home users did not do so, partially due to the number of programs which required administrator rights to function properly. As a result, most home users still ran as administrator all the time. These architectural flaws, combined with Windows's very high popularity, made Windows a frequent target of computer worm and virus writers.[103][104][105]

Furthermore, although Windows NT and its successors are designed for security (including on a network) and multi-user PCs, they were not initially designed with Internet security in mind as much, since, when it was first developed in the early 1990s, Internet use was less prevalent.[106]

In a 2002 strategy memo entitled "Trustworthy computing" sent to every Microsoft employee, Bill Gates declared that security should become Microsoft's highest priority.[107][108]

Windows Vista introduced a privilege elevation system called User Account Control.[109] When logging in as a standard user, a logon session is created and a token containing only the most basic privileges is assigned. In this way, the new logon session is incapable of making changes that would affect the entire system. When logging in as a user in the Administrators group, two separate tokens are assigned. The first token contains all privileges typically awarded to an administrator, and the second is a restricted token similar to what a standard user would receive. User applications, including the Windows shell, are then started with the restricted token, resulting in a reduced privilege environment even under an Administrator account. When an application requests higher privileges or "Run as administrator" is clicked, UAC will prompt for confirmation and, if consent is given (including administrator credentials if the account requesting the elevation is not a member of the administrators group), start the process using the unrestricted token.[110]

Leaked documents from 2013 to 2016 codenamed Vault 7 detail the capabilities of the CIA to perform electronic surveillance and cyber warfare,[111] such as the ability to compromise operating systems such as Windows.[112]

In August 2019, computer experts reported that the BlueKeep security vulnerability, CVE-2019-0708, that potentially affects older unpatched Windows versions via the program's Remote Desktop Protocol, allowing for the possibility of remote code execution, may include related flaws, collectively named DejaBlue, affecting newer Windows versions (i.e., Windows 7 and all recent versions) as well.[113] In addition, experts reported a Microsoft security vulnerability, CVE-2019-1162, based on legacy code involving Microsoft CTF and ctfmon (ctfmon.exe), that affects all Windows versions from Windows XP to the then most recent Windows 10 versions; a patch to correct the flaw is available.[114]

Microsoft releases security patches through its Windows Update service approximately once a month (usually the second Tuesday of the month), although critical updates are made available at shorter intervals when necessary.[115] Versions subsequent to Windows 2000 SP3 and Windows XP implemented automatic download and installation of updates, substantially increasing the number of users installing security updates.[116]

Windows integrates the Windows Defender antivirus, which is seen as one of the best available.[117] Windows also implements Secure Boot, Control Flow Guard, ransomware protection, BitLocker disk encryption, a firewall, and Windows SmartScreen.

In July 2024, Microsoft signalled an intention to limit kernel access and improve overall security, following a highly publicised CrowdStrike update that caused 8.5 million Windows PCs to crash.[118] Part of that initiative is to rewrite parts of Windows in Rust, a memory-safe language.[119] In 2025 Microsoft stopped offering support to Window 10 users, including providing security updates. Microsoft encouraged people to upgrade to Windows 11 or if this wasn't possible, to sign-up for extended security updates.[120]

File permissions
All Windows versions from Windows NT 3 have been based on a file system permission system referred to as AGDLP (Accounts, Global, Domain Local, Permissions) in which file permissions are applied to the file/folder in the form of a 'local group' which then has other 'global groups' as members. These global groups then hold other groups or users depending on different Windows versions used. This system varies from other vendor products such as Linux and NetWare due to the 'static' allocation of permission being applied directly to the file or folder. However using this process of AGLP/AGDLP/AGUDLP allows a small number of static permissions to be applied and allows for easy changes to the account groups without reapplying the file permissions on the files and folders.[citation needed]

Alternative implementations
Owing to the operating system's popularity, a number of applications have been released that aim to provide compatibility with Windows applications, either as a compatibility layer for another operating system, or as a standalone system that can run software written for Windows out of the box. These include:

Wine – a free and open-source implementation of the Windows API, allowing one to run many Windows applications on x86-based platforms, including UNIX, Linux and macOS. Wine developers refer to it as a "compatibility layer"[121] and use Windows-style APIs to emulate a Windows environment.
CrossOver – a Wine package with licensed fonts. Its developers are regular contributors to Wine.
Proton – A fork of Wine by Valve to run Windows games on Linux and other Unix-based operating systems.
ReactOS – an open-source OS intended to run the same software as Windows, originally designed to simulate Windows NT 4.0, later aiming at Windows 7 compatibility. It has been in the development stage since 1996.
Freedows OS – an open-source attempt at creating a Windows clone for x86 platforms, intended to be released under the GNU General Public License. Started in 1996 by Reece K. Sellin, the project was never completed, getting only to the stage of design discussions which featured a number of novel concepts until it was suspended in 2002.[122][123]
See also
Wintel
References
 "March 26, 2026—KB5079489 (OS Build 28000.1764) Preview". Microsoft Support. Microsoft.
 "March 31, 2026—KB5086672 (OS Builds 26200.8117 and 26100.8117) Out-of-band". Microsoft Support. Microsoft.
 "Releasing Windows 11 Builds 26100.8106 and 26200.8106 to the Release Preview Channel". Windows Insider Blog. March 12, 2026.
 "March 26, 2026—KB5079391 (OS Builds 26200.8116 and 26100.8116) Preview". Microsoft Support. Microsoft.
 "Announcing Windows 11 Insider Preview Build 26220.8079 (Beta Channel)". Windows Insider Blog. March 20, 2026.
 "Announcing Windows 11 Insider Preview Build 26300.8085 (Dev Channel)". Windows Insider Blog. March 20, 2026.
 "Announcing Windows 11 Insider Preview Build for Canary Channel 29553.1000". Windows Insider Blog. March 20, 2026.
 Su, Christy; Xu, Simonx (November 25, 2021). "FAQ about the Windows Installer .msp files - Dynamics GP". Microsoft Learn. Archived from the original on July 8, 2023. Retrieved September 13, 2023.
 dianmsft; Jenks, Alma; Coulter, David; Schofield, McLean; Vintzel, John; Satran, Michael; Donthini, Chaitanya; Kinsman, Mike (December 30, 2021). "What is MSIX?". Microsoft Learn. Archived from the original on September 25, 2023. Retrieved September 13, 2023.
 Jahiu, Dhurata; Jenks, Alma; v-chmccl; Power, Cory; Coulter, David; Schofield, McLean; Donthini, Chaitanya; Satran, Michael (April 13, 2022). "How to bundle MSIX packages". Microsoft Learn. Archived from the original on October 4, 2023. Retrieved September 13, 2023.
 Vera (June 26, 2023) [April 14, 2023]. "How to Install MSIXBundle on Windows 10/11? 2 Ways to Try!". MiniTool. Archived from the original on August 21, 2023. Retrieved September 13, 2023.
 "App packages and deployment (Windows Store apps) (Windows)". Microsoft Learn. October 19, 2021 [October 6, 2015]. Archived from the original on March 30, 2014. Retrieved April 5, 2014.
 Bellis, Mary (October 4, 2019). "The Unusual History of Microsoft Windows". Archived from the original on March 14, 2020. Retrieved January 13, 2023.
 Edwards, Benj (February 7, 2022). "Why Is Windows Called Windows?". How-To Geek. Retrieved September 3, 2024.
 "Desktop Operating System Market Share Worldwide". StatCounter Global Stats. Retrieved February 5, 2026.
 Keizer, Gregg (July 14, 2014). "Microsoft gets real, admits its device share is just 14%". Computerworld. IDG. Archived from the original on August 21, 2016. [Microsoft's chief operating officer] Turner's 14% came from a new forecast released last week by Gartner, which estimated Windows' share of the shipped device market last year was 14%, and would decrease slightly to 13.7% in 2014. Android will dominate, Gartner said, with a 48% share this year
 "Desktop Windows Version Market Share Worldwide". StatCounter Global Stats. Retrieved March 19, 2026.
 Microsoft. "Meet Windows 11: Features, Look, Benefits & More | Microsoft". Windows. Retrieved March 2, 2026.
 "RTOS: Embedded Real Time Operating Systems". microsoft.com. Microsoft. Archived from the original on December 15, 2014. Retrieved November 7, 2014.
 "A history of Windows". Microsoft Windows. Archived from the original on June 11, 2016. Retrieved January 7, 2023.
 Microsoft C 5.0: C Language Reference Guide. Microsoft. 1987. pp. 250–267.
 "A legacy of Windows, part 1: Windows 1-2-3 – TechRepublic". TechRepublic. Archived from the original on March 27, 2017. Retrieved March 26, 2017.
 "The Apple vs. Microsoft GUI Lawsuit". 2006. Archived from the original on March 4, 2008. Retrieved March 12, 2008.
 "Apple Computer, Inc. v. MicroSoft Corp., 35 F.3d 1435 (9th Cir. 1994)". Archived from the original on December 14, 2007. Retrieved March 12, 2008.
 Patton, Carole; Mace, Scott (July 4, 1988). "Windows Gets More Memory With Upgrade". InfoWorld. Vol. 10, no. 27. p. 1. ISSN 0199-6649. Archived from the original on January 9, 2024. Retrieved January 9, 2024.
 "Windows Evolution". Soft32.com News. Archived from the original on February 8, 2008.
 "Chronology of Personal Computer Software". Archived from the original on February 11, 2012.
 "Microsoft Company". Archived from the original on May 14, 2008.
 "Windows 3.1 Standard Edition Support Lifecycle". Archived from the original on January 12, 2012. Retrieved January 3, 2011.
 "Microsoft Windows Simplified Chinese 3.2 Upgrade Is Available". Microsoft Support. Microsoft. Archived from the original on November 8, 2006.
 "Microsoft Windows Simplified Chinese 3.2 Upgrade Is Available". Microsoft. October 30, 2003. Archived from the original on May 24, 2011. Retrieved September 4, 2009.
 Fried, Ina (August 25, 2010). "Windows 95 turns 15: Has Microsoft's OS peaked?". CNET/CNN Tech. Archived from the original on August 26, 2010. Retrieved August 22, 2012.
 "Microsoft Internet Explorer Web Browser Available on All Major Platforms, Offers Broadest International Support". News Center. San Jose, California: Microsoft. April 30, 1996. Archived from the original on January 15, 2008. Retrieved February 14, 2011.
 "Windows 95 Support Lifecycle". Microsoft. Archived from the original on November 22, 2012. Retrieved January 3, 2011.
 "Windows 98 Standard Edition Support Lifecycle". Microsoft. Archived from the original on November 22, 2012. Retrieved January 3, 2011.
 "Improving "Cold Boot" Time for System Manufacturers". Microsoft. December 4, 2001. Archived from the original on February 13, 2010. Retrieved August 26, 2010.
 "Windows Millennium Edition: All About Me". PC World. Archived from the original on August 1, 2013. Retrieved May 21, 2013.
 "The 25 Worst Tech Products of All Time". PC World. IDG. May 26, 2006. Archived from the original on January 7, 2023. Retrieved January 7, 2023.
 Custer, Helen (1993). Inside Windows NT. Redmond: Microsoft Press. ISBN 1-55615-481-X.
 Thurrott, Paul (January 24, 2003). "Windows Server 2003: The Road To Gold – Part One: The Early Years". Archived from the original on January 1, 2005. Retrieved May 28, 2012.
 "Windows XP review". CNET. Archived from the original on May 26, 2013. Retrieved May 24, 2013.
 "Windows XP Program Compatibility Wizard". ServerWatch. March 12, 2002. Archived from the original on November 13, 2021. Retrieved November 13, 2021.
 David Coursey (October 25, 2001). "The 10 top things you MUST know about Win XP". ZDNet. Archived from the original on April 3, 2009. Retrieved July 22, 2008.
 David Coursey (August 31, 2001). "Your top Windows XP questions answered! (Part One)". ZDNet. CNET Networks. Archived from the original on December 19, 2007. Retrieved January 3, 2011.
 "A Look at Freestyle and Mira". Paul Thurrott's SuperSite for Windows. Penton. September 3, 2002. Archived from the original on June 28, 2018. Retrieved January 3, 2011.
 "Windows XP Professional Lifecycle Support". Archived from the original on February 27, 2013. Retrieved January 3, 2011.
 "Windows Server 2003 R2 - Microsoft Lifecycle". Microsoft Learn. Microsoft. Retrieved November 27, 2025.
 Nash, Mike (October 28, 2008). "Windows 7 Unveiled Today at PDC 2008". Windows Experience Blog. Microsoft. Archived from the original on November 1, 2008. Retrieved November 11, 2008.
 Kiriaty, Yochay; Goldshtein, Sasha (2009). "Windows 7 Taskbar APIs". docs.microsoft.com. Archived from the original on August 21, 2021. Retrieved August 21, 2021.
 LeBlanc, Brandon (October 28, 2008). "How Libraries & HomeGroup Work Together in Windows 7". Windows Experience Blog. Microsoft. Archived from the original on November 2, 2008. Retrieved November 11, 2008.
 "New Windows 8 hardware specs hint at 7-inch tablets and a Microsoft Reader". ZDNet. Archived from the original on December 4, 2014. Retrieved March 29, 2013.
 Paul, Ian (July 5, 2021). "How to Take Screenshots in Windows 10, 8, and 7". Archived from the original on March 19, 2022. Retrieved August 11, 2021.
 Case, Loyd. "Test Driving Windows 8 RTM". PC World. IDG. Archived from the original on January 7, 2023. Retrieved January 7, 2023.
 Rosoff, Matt. "Here's Everything You Wanted To Know About Microsoft's Upcoming iPad Killers". Business Insider. Archived from the original on January 22, 2013. Retrieved February 10, 2012.
 "Announcing the Windows 8 Editions". Microsoft. April 16, 2012. Archived from the original on April 18, 2012. Retrieved April 17, 2012.
 "Building Windows for the ARM processor architecture". Microsoft. Archived from the original on November 26, 2012. Retrieved November 21, 2012.
 "Microsoft talks Windows Store features, Metro app sandboxing for Windows 8 developers". The Verge. Vox Media. May 17, 2012. Archived from the original on September 10, 2012. Retrieved September 8, 2012.
 Miller, Michael. "Build: More Details On Building Windows 8 Metro Apps". PC Magazine. Archived from the original on February 17, 2012. Retrieved February 10, 2012.
 "Windows 8.1 now available!". blogs.windows.com. Archived from the original on October 19, 2013. Retrieved October 31, 2013.
 "Announcing Windows 10 – Windows Blog". September 30, 2014. Archived from the original on September 10, 2015. Retrieved September 30, 2014.
 Bright, Peter (May 24, 2017). "Windows switch to Git almost complete: 8,500 commits and 1,760 builds each day". Ars Technica. Condé Nast. Archived from the original on May 24, 2017.
 "Window 10 Home and Pro Lifecycle". Microsoft. Archived from the original on June 10, 2021. Retrieved July 2, 2021.
 "Window 10 Enterprise and Education Lifecycle". Microsoft. Archived from the original on July 1, 2021. Retrieved July 2, 2021.
 Leznek, Jason (April 27, 2023). "Windows client roadmap update". Microsoft. Archived from the original on September 3, 2023. Retrieved May 1, 2023.
 Bowden, Zack (April 27, 2023). "Windows 10 is finished — Microsoft confirms 'version 22H2' is the last". Windows Central. Archived from the original on September 3, 2023. Retrieved May 1, 2023.
 Cox, George. "Windows 11 release date is October 5". The Spectrum. Archived from the original on February 18, 2023. Retrieved September 18, 2021.
 Warren, Tom (June 24, 2021). "Microsoft announces Windows 11, with a new design, Start menu, and more". The Verge. Archived from the original on June 24, 2021. Retrieved June 24, 2021.
 "Windows 11 Specs and System Requirements". Microsoft. Archived from the original on May 31, 2022. Retrieved May 31, 2022.
 Warren, Tom (April 6, 2023). "Microsoft's Windows 365 Cloud PCs get more flexible, LG TV integration, and more". The Verge. Archived from the original on September 3, 2023. Retrieved June 2, 2023.
 Foley, Mary Jo (July 14, 2021). "Microsoft brings Windows to the cloud with Windows 365 and Cloud PC". ZDNet. Archived from the original on July 28, 2021. Retrieved July 14, 2021.
 Tilley, Aaron (July 14, 2021). "Microsoft Aims to Put Windows in Hands of Apple, Android Users Through Hybrid Work". The Wall Street Journal. ISSN 0099-9660. Archived from the original on July 28, 2021. Retrieved July 15, 2021.
 Higgins, Tim (June 23, 2021). "Apple's Fight for Control Over Apps Moves to Congress and EU". The Wall Street Journal. ISSN 0099-9660. Archived from the original on July 28, 2021. Retrieved July 15, 2021.
 "Microsoft unveils Windows 365, a Windows 10 PC in the cloud". Engadget. July 14, 2021. Archived from the original on July 28, 2021. Retrieved July 15, 2021.
 "Windows 365 Cloud PC | Microsoft". www.microsoft.com. Archived from the original on July 28, 2021. Retrieved July 15, 2021.
 Hill, Paul (August 2, 2021). "Microsoft announces the general availability of Windows 365". Neowin. Archived from the original on August 2, 2021. Retrieved August 2, 2021.
 Bott, Ed (October 7, 2019). "Windows 10 on Arm: What you need to know before you buy a Surface Pro X". ZDNet. Archived from the original on July 1, 2021. Retrieved June 14, 2021.
 Anand Lal Shimpi. "The Xbox One – Mini Review & Comparison to Xbox 360/PS4". anandtech.com. Archived from the original on October 12, 2014. Retrieved October 21, 2014.
 "Xbox One: Hardware and software specs detailed and analyzed – Three operating systems in one". ExtremeTech. Archived from the original on November 16, 2013. Retrieved December 1, 2013.
 "How to use the Offline System Update Diagnostic Tool on Xbox One". Xbox Official Site. Microsoft. Archived from the original on April 27, 2021. Retrieved November 30, 2013.
 "Xbox One Is "Literally a Windows Device"". GameSpot. Archived from the original on December 27, 2015.
 "New Xbox One Update Will Make Some Functionality 50 Percent Faster". GameSpot. Archived from the original on February 2, 2016.
 Tom Warren (June 16, 2015). "Xbox One dashboard update includes a huge new design and Cortana". The Verge. Vox Media. Archived from the original on July 8, 2017.
 Eric Qualls. "Xbox 360 and Xbox Games Backwards Compatibility". About.com Tech. Archived from the original on September 28, 2015.
 Chen, Raymond (January 22, 2018). "The history of change-packing tools at Microsoft (so far)". The Old New Thing. Microsoft Developer Blogs (DevBlogs). Archived from the original on May 25, 2022. Retrieved September 2, 2023.
 Lewis, Andy (June 26, 2013). "Visual Studio 2013 Preview: Git version control and Team Foundation Build". Azure DevOps Blog. Microsoft Developer Blogs (DevBlogs). Archived from the original on September 3, 2023. Retrieved September 2, 2023.
 Harry, Brian (February 3, 2017). "Scaling Git (and some back story)". Brian Harry's Blog. Microsoft Developer Blogs (DevBlogs). Archived from the original on September 3, 2023. Retrieved September 2, 2023.
 "The largest Git repo on the planet". Brian Harry's Blog. May 24, 2017. Archived from the original on October 6, 2021. Retrieved October 8, 2021.
 Bright, Peter (February 6, 2017). "Microsoft hosts the Windows source in a monstrous 300 GB Git repository". Ars Technica. Archived from the original on December 26, 2017. Retrieved December 26, 2017.
 Chacon, Scott; Straub, Ben (2014). "2.1 Git Basics – Getting a Git Repository: Cloning an Existing Repository". Pro Git. The version found here has been updated with corrections and additions from hundreds of contributors. (2nd ed.). Apress. ISBN 978-1-4842-0077-3. Archived from the original on September 1, 2023. Retrieved September 2, 2023 – via the Git Project.
 Stolee, Derrick (May 28, 2020). "Frequently Asked Questions: Why Are You Abandoning VFS for Git?". GitHub. Microsoft. Archived from the original on May 1, 2023. Retrieved September 2, 2023.
 "Microsoft Support Lifecycle". Microsoft. Archived from the original on October 11, 2008.
 Chen, Raymond (July 22, 2019). "What was the code name for Windows 7?". The Old New Thing.
 "Windows 11 Home and Pro Product Life Cycle". Microsoft.
 "Frequently Asked Questions". StatCounter. Are laptops included in the desktop platform?.
 "Desktop Windows Version Market Share Worldwide (April 2026)". StatCounter.
 "Desktop Windows Version Market Share Worldwide | StatCounter Global Stats". StatCounter Global Stats. Archived from the original on April 20, 2019. Retrieved November 24, 2019.
 "Desktop Operating system market share: August 2021". Net Applications. Archived from the original on September 8, 2021. Retrieved September 8, 2021.
 "Desktop Operating System Market Share Worldwide: August 2021". StatCounter. Retrieved September 8, 2021.
 "Operating system market share: August 2021". Net Applications. Archived from the original on September 8, 2021. Retrieved September 8, 2021.
 "Operating System Market Share Worldwide: August 2021". StatCounter. Archived from the original on February 15, 2020. Retrieved September 8, 2021.
 "Transcript: Chat with Ed Bott and Carl Siechert, Co-Authors of Microsoft Windows XP Inside Out". Microsoft. November 21, 2001. Archived from the original on September 18, 2004. Retrieved April 20, 2019.
 Russinovich, Mark (April 30, 1998). "Windows NT Security, Part 1". ITPro Today. Archived from the original on September 29, 2022. Retrieved September 29, 2022.
 Bruce Schneier (June 15, 2005). "Crypto-Gram Newsletter". Schneier.com. Counterpane Internet Security, Inc. Archived from the original on June 6, 2007. Retrieved April 22, 2007.
 Andy Patrizio (April 27, 2006). "Linux Malware On The Rise". InternetNews. QuinStreet. Archived from the original on February 5, 2012. Retrieved January 3, 2011.
 "Windows intentionally weak on worms, viruses - The Arizona State Press". www.statepress.com. Retrieved June 12, 2024.
 "Telephones and Internet Users by Country, 1990 and 2005". Information Please Database. Archived from the original on May 22, 2009. Retrieved June 9, 2009.
 Gates, Bill. "Bill Gates: Trustworthy Computing". Wired. ISSN 1059-1028. Archived from the original on September 29, 2022. Retrieved September 29, 2022.
 Verloy, Filip. "20 Years After Bill Gates' Trustworthy Computing Memo, Cybersecurity Issues Are An Even Harder Problem". nonamesecurity.com. Archived from the original on September 29, 2022. Retrieved September 29, 2022.
 Northrup, Tony (June 1, 2005). "Windows Vista Security and Data Protection Improvements". TechNet. Microsoft Docs. Archived from the original on October 20, 2021. Retrieved October 20, 2021. In Windows Vista, the User Account Control (UAC) initiative introduces fundamental operating system changes to enhance the experience for the non-administrative user.
 Kenny Kerr (September 29, 2006). "Windows Vista for Developers – Part 4 – User Account Control". Archived from the original on March 29, 2007. Retrieved March 15, 2007.
 Greenberg, Andy (March 7, 2017). "How the CIA Can Hack Your Phone, PC, and TV (Says WikiLeaks)". WIRED. Archived from the original on March 20, 2019. Retrieved December 18, 2018.
 "Vault 7: Wikileaks reveals details of CIA's hacks of Android, iPhone Windows, Linux, MacOS, and even Samsung TVs". Computing. March 7, 2017. Archived from the original on April 12, 2019. Retrieved December 18, 2018.
 Greenberg, Andy (August 13, 2019). "DejaBlue: New BlueKeep-Style Bugs Renew The Risk Of A Windows worm". wired. Archived from the original on April 13, 2021. Retrieved August 15, 2019.
 Seals, Tara (August 14, 2019). "20-Year-Old Bug in Legacy Microsoft Code Plagues All Windows Users". ThreatPost.com. Archived from the original on April 17, 2021. Retrieved August 15, 2019.
 Naraine, Ryan (June 8, 2005). "Microsoft's Security Response Center: How Little Patches Are Made". eWeek. Ziff Davis Enterprise. Retrieved January 3, 2011.
 John Foley (October 20, 2004). "Windows XP SP2 Distribution Surpasses 100 Million". InformationWeek. UBM TechWeb. Archived from the original on May 27, 2010. Retrieved January 3, 2011.
 "Test antivirus software for Windows 10 – June 2022". www.av-test.org. Archived from the original on September 29, 2022. Retrieved September 29, 2022.
 Christoffel, Ryan (July 26, 2024). "Microsoft starts campaign to make Windows security more like Mac post-CrowdStrike". 9to5Mac. Retrieved July 27, 2024.
 Warren, Tom (November 19, 2024). "Microsoft's new Windows Resiliency Initiative aims to avoid another CrowdStrike incident". The Verge. Retrieved November 19, 2024. ...and Microsoft is making changes to Windows, too. It's 'gradually moving functionality from C++ implementation to Rust' in Windows, to help further improve the security of the OS.
 Gibbs, Samuel; Booth, Robert (October 14, 2025). "What does the end of free support for Windows 10 mean for its users?". The Guardian. ISSN 0261-3077. Retrieved March 27, 2026.
 "Wine". Winehq.org. Archived from the original on April 4, 2014. Retrieved April 5, 2014.
 "A Student's Dream of Creating A New Operating System Encounters Problems". The Chronicle of Higher Education. September 18, 1998. Retrieved May 17, 2013.
 "Freedows splits". Slashdot. Dice Holdings. August 31, 1998. Retrieved May 17, 2013.
External links
Microsoft Windows
at Wikipedia's sister projects
Wikimedia Commons logoMedia from Commons
Wikibooks logoTextbooks from Wikibooks
Wikiversity logoResources from Wikiversity
Official website
Official Windows Blog. Archived January 15, 2017, at the Wayback Machine.
Microsoft Developer Network. Archived January 7, 2009, at the Wayback Machine.
Windows Developer Center. Archived December 16, 2016, at the Wayback Machine.
Microsoft Windows History Timeline
Pearson Education, InformIT. Archived June 28, 2021, at the Wayback Machine. History of Microsoft Windows.
Microsoft Business Software Solutions. Archived December 5, 2019, at the Wayback Machine.
Windows 10 release Information. Archived May 7, 2019, at the Wayback Machine.
vte
Microsoft Windows
vte
Operating systems by Microsoft
vte
Microsoft Corporation
vte
Microsoft Windows components
vte
Operating systems
Authority control databases Edit this at Wikidata
Categories: Microsoft Windows1985 softwareComputing platformsMicrosoft franchisesPersonal computersMicrosoft operating systemsOperating system familiesProducts introduced in 19851985 establishments in the United StatesComputer-related introductions in 1985
This page was last edited on 4 April 2026, at 10:23 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policyAbout WikipediaDisclaimersContact WikipediaLegal & safety contactsCode of ConductDevelopersStatisticsCookie statementMobile view
Wikimedia Foundation
Powered by MediaWiki

    """
    """

WikipediaThe Free Encyclopedia
Search Wikipedia
Search
Donate
Create account
Log in
Contents hide
(Top)
History

Architecture

Features

Release history

Security

Reception

See also
References
External links
macOS

Article
Talk
Read
View source
View history

Tools
Appearance hide
Birthday mode (Baby Globe)

Disabled

Enabled
Learn more about Birthday mode
Text

Small

Standard

Large
Width

Standard

Wide
Color (beta)

Automatic

Light

Dark
Page semi-protected
From Wikipedia, the free encyclopedia
"OSX" and "OS X" redirect here. For other uses, see OSX (disambiguation).
For other uses, see Mac OS (disambiguation) and Macos (school).
macOS


macOS Tahoe, the latest release of macOS
Developer	Apple
Written in	
CC++[2]Objective-CSwift[3]assembly language
OS family	
MacDarwinBSDUnix-likeUnix[1]
Source model	Proprietary with open source components
Initial release	March 24, 2001; 25 years ago
Latest release	26.4[4] (March 24, 2026; 10 days ago) [±]
Available in	47 languages[5]
List of languages
Supported platforms	
Apple silicon (ARM64)
Intel (64-bit)
Previously supported:
Kernel type	Hybrid (XNU)
Default
user interface	Aqua (graphical)
License	Proprietary
Preceded by	Classic Mac OS, NeXTSTEP
Official website	www.apple.com/os/macos/ Edit this at Wikidata
Support status
Supported
Part of a series on
macOS
History and architecture
Versions
Applications
Utilities
Related operating systems
vte
macOS (previously OS X and originally Mac OS X) is a proprietary Unix[6][7] operating system, derived from OPENSTEP for Mach and FreeBSD, which has been marketed and developed by Apple since 2001. It is the current operating system for Apple's line of Mac computers. Within the market of desktop and laptop computers, it is currently the second most widely used desktop OS, after Microsoft Windows and ahead of all Linux distributions, including ChromeOS and SteamOS. As of 2026, the most recent release of macOS is macOS 26 Tahoe, the 22nd major version of macOS.[8]

Mac OS X succeeded the classic Mac OS, the primary Macintosh operating system from 1984 to 2001. Its underlying architecture came from NeXT's NeXTSTEP, as a result of Apple's acquisition of NeXT, which also brought Steve Jobs back to Apple. The first desktop version, Mac OS X 10.0, was released on March 24, 2001. Apart from OS X Lion,[9] all versions from Mac OS X Leopard onwards are UNIX 03 certified.[10] Each of Apple's other contemporary operating systems, including iOS, iPadOS, watchOS, tvOS, audioOS and visionOS, are derivatives of macOS. Throughout its history, macOS has supported three major processor architectures: the initial version supported PowerPC-based Macs only, with support for Intel-based Macs beginning with OS X Tiger 10.4.4[11] and support for ARM-based Apple silicon Macs beginning with macOS Big Sur.[12] Support for PowerPC-based Macs was dropped with OS X Snow Leopard,[13] and it was announced at the 2025 Worldwide Developers Conference that macOS Tahoe will be the last to support Intel-based Macs.[14]

A prominent part of macOS's original brand identity was the use of the Roman numeral X, pronounced "ten", as well as code naming each release after species of big cats, and later, places within California.[15] Apple shortened the name to "OS X" in 2011 and then changed it to "macOS" in 2016 to align with the branding of Apple's other operating systems.[16] In 2020, macOS Big Sur was presented as version 11—a marked departure after 16 releases of macOS 10—but the naming convention continued to reference places within California. In 2025, Apple unified the version number across all of its products to align with the year after their WWDC announcement, so the release announced at the 2025 WWDC, macOS Tahoe, is macOS 26.[17]

History
Development
Main article: macOS version history
The heritage of what would become macOS originated at NeXT, a company founded by Steve Jobs following his departure from Apple in 1985. There, the Unix-like NeXTSTEP operating system was developed, before being launched in 1989. The kernel of NeXTSTEP is based upon the Mach kernel, which was originally developed at Carnegie Mellon University, with additional kernel layers and low-level user space code derived from parts of FreeBSD[18] and other BSD operating systems.[19] Its graphical user interface was built on top of an object-oriented GUI toolkit using the Objective-C programming language.

Throughout the 1990s, Apple had tried to create a "next-generation" OS to succeed its classic Mac OS through the Taligent, Copland and Gershwin projects; however, all were eventually abandoned.[20] This led Apple to acquire NeXT in 1997, allowing NeXTSTEP, later called OPENSTEP, to serve as the basis for Apple's next-generation operating system.[21] The acquisition also led to Steve Jobs returning to Apple as interim and later permanent CEO, shepherding the transformation of the programmer-friendly OPENSTEP into a system that would be adopted by Apple's primary market of home users and creative professionals. The project was codenamed "Rhapsody" before being officially named Mac OS X.[22][23]

Mac OS X
The "X" in Mac OS X's name represents the Roman numeral for the number ten, and Apple has stated that it should be pronounced "ten" in this context; it is also commonly pronounced like the letter "X".[24][25] The iPhone X, iPhone XR and iPhone XS all later followed this convention.

Previous Macintosh operating systems (versions of the classic Mac OS) were named using Arabic numerals, as with Mac OS 8 and Mac OS 9.[26][24] Until version 11, macOS Big Sur, all versions of the operating system were given version numbers of the form 10.x, with this format persisting from Mac OS X 10.0 through 10.15; starting with macOS Big Sur, Apple switched to integer version numbers that increased by 1 with every major release.

The first version of Mac OS X, Mac OS X Server 1.0, was a transitional product, featuring an interface resembling the classic Mac OS, though it was not compatible with software designed for the older system; consumer releases of Mac OS X included more backward compatibility. Mac OS applications could be rewritten to run natively via the Carbon API, with many alternatively able to be run directly through the Classic Environment albeit with a reduction in performance.

The consumer version of Mac OS X was launched in March 2001 with Mac OS X 10.0. Reviews were variable, with many praising its sophisticated, glossy Aqua interface, but criticizing it for sluggish performance.[27] With Apple's popularity at a low, the developer of FrameMaker, Adobe Inc., declined to develop new versions of it for Mac OS X.[28] Ars Technica columnist John Siracusa, who reviewed every major OS X release up to 10.10, described the early releases in retrospect as "dog-slow, feature poor" and Aqua as "unbearably slow and a huge resource hog".[27][29][30]

Apple rapidly developed several new releases of Mac OS X.[31] Apple released Mac OS X 10.1 in October 2001, delivering quality of life enhancements.[32] Beginning in January 2002, Apple preinstalled Mac OS X as the default operating system on all Macs.[33] Later that year Apple released Mac OS X Jaguar (version 10.2), the first version to publicly use its code name in marketing and advertisements.[34] When Mac OS X Panther (10.3) released in 2003, Siracusa noted that "It's strange to have gone from years of uncertainty and vaporware to a steady annual supply of major new operating system releases."[35] Mac OS X Tiger (10.4), which released in 2005, reportedly shocked executives at Microsoft by offering a number of features, such as fast file searching and improved graphics processing, that Microsoft had spent several years struggling to add to Windows Vista with acceptable performance.[36]

As the operating system evolved, it moved away from the classic Mac OS, with applications being added and removed.[37] Considering music to be a key market, Apple developed the iPod music player and music software for the Mac, including iTunes and GarageBand.[38] Targeting the consumer and media markets, Apple emphasized its new "digital lifestyle" applications such as the iLife suite, integrated home entertainment through the Front Row media center and the Safari web browser. With the increasing popularity of the internet, Apple offered additional online services, including the .Mac, MobileMe and most recently iCloud products. It later began selling third-party applications through the Mac App Store.

Newer versions of Mac OS X also included modifications to the general interface, moving away from the striped gloss and transparency of the initial versions. Some applications began to use a brushed metal appearance, or non-pinstriped title bar appearance in Mac OS X Tiger.[39] In Mac OS X Leopard (10.5), Apple announced a unification of the interface, with a standardized gray-gradient window style.[40][41]

In 2006, the first Intel Macs were released with a specialized version of Mac OS X Tiger.[42]

A key development for the system was the announcement and release of the iPhone from 2007 onwards. While Apple's previous iPod media players used a minimal operating system, the iPhone used an operating system based on Mac OS X, which would later be called iPhone OS and then iOS. The simultaneous release of two operating systems based on the same frameworks placed tension on Apple, which cited the iPhone as forcing it to delay Mac OS X Leopard.[43] However, after Apple opened the iPhone to third-party developers, its commercial success drew attention to Mac OS X, with many iPhone software developers showing interest in Mac development.[44]

In 2007, Mac OS X Leopard released with universal binary components, allowing installation on both Intel Macs and select PowerPC Macs.[45] It is also the final release with PowerPC Mac support. In 2009, Mac OS X Snow Leopard (10.6) was the first version of Mac OS X to be built exclusively for Intel Macs and the final release with 32-bit Intel Mac support.[46] The name was intended to signal its status as an iteration of Leopard, focusing on technical and performance improvements rather than user-facing features; indeed it was explicitly branded to developers as being a 'no new features' release.[47] Since its release, several OS X or macOS releases (namely OS X Mountain Lion, OS X El Capitan, macOS High Sierra, and macOS Monterey) follow this pattern, with a name derived from its predecessor, similar to the 'tick–tock model' used by Intel.

Starting in 2011 with Mac OS X Lion (10.7) and OS X Mountain Lion (10.8), Apple moved some applications to a highly skeuomorphic style of design inspired by contemporary versions of iOS while simplifying some elements by making controls such as scroll bars fade out when not in use.[29] This direction was, like brushed metal interfaces, unpopular with some users, although it continued a trend of greater animation and variety in the interface previously seen in design aspects such as the Time Machine backup utility, which presented past file versions against a swirling nebula, and the glossy translucent dock of Leopard and Snow Leopard.[48] In addition, with Lion, Apple ceased to release separate server versions of Mac OS X, selling server tools as a separate downloadable application through the Mac App Store. A review described the trend in the server products as becoming "cheaper and simpler... shifting its focus from large businesses to small ones."[49]

OS X

OS X logo used until 2013
In 2012, with the release of OS X Mountain Lion, the name of the system was officially shortened from Mac OS X to OS X, after the previous version shortened the system name in a similar fashion a year prior. That year, Apple removed the head of OS X development, Scott Forstall, and design was changed towards a more minimal direction.[50] Apple's new user interface design, using deep color saturation, text-only buttons and a minimal, 'flat' interface, was debuted with iOS 7 in 2013. With OS X engineers reportedly working on iOS 7, the version released in 2013, OS X Mavericks (10.9), was something of a transitional release, with some of the skeuomorphic design removed, while most of the general interface of Mavericks remained unchanged.[51] The next version, OS X Yosemite (10.10), adopted a design similar to iOS 7 but with greater complexity suitable for an interface controlled with a mouse.[52]

From 2012 onwards, the system has shifted to an annual release schedule similar to that of Mac OS X releases prior to 10.4 Tiger.[53] It also steadily cut the cost of updates from Snow Leopard onwards, before removing upgrade fees altogether in OS X Mavericks.[54] Some journalists and third-party software developers have suggested that this decision, while allowing more rapid feature release, meant less opportunity to focus on stability, with no version of OS X recommendable for users requiring stability and performance above new features.[55] Apple's 2015 update, OS X El Capitan (10.11), was announced to focus specifically on stability and performance improvements.[56]

macOS

Current logo
In 2016, with the release of macOS Sierra (10.12), the name was changed from OS X to macOS with the purpose of aligning it with the branding of Apple's other primary operating systems: iOS, watchOS, and tvOS.[57][58] macOS Sierra added Siri, iCloud Drive, picture-in-picture support, a Night Shift mode that switches the display to warmer colors at night, and two Continuity features: Universal Clipboard, which syncs a user's clipboard across their Apple devices, and Auto Unlock, which can unlock a user's Mac with their Apple Watch. macOS Sierra also adds support for the Apple File System (APFS), Apple's successor to the dated HFS+ file system.[59][60][61] macOS High Sierra (10.13), released in 2017, included performance improvements, Metal 2 and HEVC support, and made APFS the default file system for SSD boot drives.[62]

Its successor, macOS Mojave (10.14), was released in 2018, adding a dark mode option and a dynamic wallpaper setting.[63] It was succeeded by macOS Catalina (10.15) in 2019, which replaces iTunes with separate apps for different types of media, and introduces the Catalyst system for porting iOS apps.[64]

In 2020, Apple announced macOS Big Sur (version 11) at that year's WWDC. This was the first increment in the primary version number of macOS since the release of Mac OS X Public Beta in 2000; updates to macOS Big Sur were given 11.x numbers, matching the version numbering scheme used by Apple's other operating systems. Big Sur brought major changes to the user interface and was the first version to run on Apple Silicon, based on the ARM architecture.[65] The numbering system started with Big Sur continued in 2021 with macOS Monterey (12), 2022 with macOS Ventura (13), 2023 with macOS Sonoma (14), and 2024 with macOS Sequoia (15).

In 2025, starting with macOS Tahoe (version 26), macOS's version number will be based on the year following its release, as will the version numbers of iOS, iPadOS, watchOS, tvOS, and visionOS, so that the version numbers are the same for all Apple OSes.[66] macOS Tahoe also brings with it a new user interface design, called Liquid Glass, which will also be used on Apple's other platforms, unifying their design language.[67] Tahoe will be the final version of macOS to operate on Intel-based Macs.[68]

Something of note about macOS is the OS itself never had any Digital Rights Management to install or use and could be distributed freely, differing from those who use Windows which requires Microsoft Product Activation.

Timeline of releases
vteOverview of macOS versions
Release	Darwin
version	Release date	Latest release	Compatibility
Version	Name	Version	Release date	Processor	Application	Kernel
Mac OS X Server 1.0	Hera[a]	0.1-0.3	March 16, 1999	1.2v3	October 27, 2000	32-bit PowerPC	32-bit PowerPC	32-bit
Mac OS X 10.0	Cheetah[a]	1.3.1	March 24, 2001	10.0.4	June 22, 2001
Mac OS X 10.1	Puma[a]	1.4.1/5	September 25, 2001	10.1.5	June 6, 2002
Mac OS X 10.2	Jaguar	6	August 24, 2002	10.2.8	October 3, 2003	32/64-bit PowerPC[b]
Mac OS X 10.3	Panther	7	October 24, 2003	10.3.9	April 15, 2005
Mac OS X 10.4	Tiger	8	April 29, 2005	10.4.11	November 14, 2007	32/64-bit PowerPC
and Intel	32/64-bit PowerPC
and Intel[c][d]
Mac OS X 10.5	Leopard	9	October 26, 2007	10.5.8	August 13, 2009
Mac OS X 10.6	Snow Leopard	10	August 28, 2009	10.6.8	July 25, 2011	32/64-bit Intel	32/64-bit Intel
32-bit PowerPC[d]	32/64-bit[71]
Mac OS X 10.7	Lion	11	July 20, 2011	10.7.5	October 4, 2012	64-bit Intel	32/64-bit Intel
OS X 10.8	Mountain Lion	12	July 25, 2012[72]	10.8.5	August 13, 2015	64-bit[73]
OS X 10.9	Mavericks	13	October 22, 2013	10.9.5	July 18, 2016
OS X 10.10	Yosemite	14	October 16, 2014	10.10.5	July 19, 2017
OS X 10.11	El Capitan	15	September 30, 2015	10.11.6	July 9, 2018
macOS 10.12	Sierra	16	September 20, 2016	10.12.6	September 26, 2019
macOS 10.13	High Sierra	17	September 25, 2017	10.13.6	November 12, 2020
macOS 10.14	Mojave	18	September 24, 2018	10.14.6	July 21, 2021
macOS 10.15	Catalina	19	October 7, 2019	10.15.8	February 2, 2026	64-bit Intel
macOS 11	Big Sur	20	November 12, 2020	11.7.11	64-bit Intel and ARM[e]
macOS 12	Monterey	21	October 25, 2021	12.7.6	July 29, 2024
macOS 13	Ventura	22	October 24, 2022	13.7.8	August 20, 2025
macOS 14	Sonoma	23	September 26, 2023	14.8.5	March 24, 2026
macOS 15	Sequoia	24	September 16, 2024	15.7.5
macOS 26	Tahoe	25	September 15, 2025	26.4
Legend:
Unsupported
Supported
Latest version
Preview version
 Internal codename.
 The Power Mac G5 had special Jaguar builds.
 Tiger did not support 64-bit GUI applications, only 64-bit CLI applications.[69][70]
 32-bit (but not 64-bit) PowerPC applications were supported on Intel processors with Rosetta.
 64-bit Intel applications are supported on Apple silicon Macs with Rosetta 2. However, Intel-based Macs are unable to run ARM-based applications, such as iOS and iPadOS apps.
Architecture
Main article: Architecture of macOS
At macOS's core is a POSIX-compliant operating system built on top of the XNU kernel,[74] (which incorporated large parts of FreeBSD kernel[18]) and FreeBSD userland[18] for the standard Unix facilities available from the command line interface. Apple has released this family of software as a free and open source operating system named Darwin. On top of Darwin, Apple layered a number of components, including the Aqua interface and the Finder, to complete the GUI-based operating system which is macOS.[75]

With its original introduction as Mac OS X, the system brought a number of new capabilities to provide a more stable and reliable platform than its predecessor, the classic Mac OS. For example, pre-emptive multitasking and memory protection improved the system's ability to run multiple applications simultaneously without them interrupting or corrupting each other. Many aspects of macOS's architecture are derived from OPENSTEP, which was designed to be portable, to ease the transition from one platform to another. For example, NeXTSTEP was ported from the original 68k-based NeXT workstations to x86 and other architectures before NeXT was purchased by Apple,[76] and OPENSTEP was later ported to the PowerPC architecture as part of the Rhapsody project.

Prior to macOS High Sierra, and on drives other than solid state drives (SSDs), the default file system is HFS+, which it inherited from the classic Mac OS. Operating system designer Linus Torvalds had criticized HFS+, saying it is "probably the worst file system ever", whose design is "actively corrupting user data". He criticized the case insensitivity of file names, a design made worse when Apple extended the file system to support Unicode.[77][78]

The Darwin subsystem in macOS manages the file system, which includes the Unix permissions layer. In 2003 and 2005, two Macworld editors expressed criticism of the permission scheme; Ted Landau called misconfigured permissions "the most common frustration" in macOS, while Rob Griffiths suggested that some users may even have to reset permissions every day, a process which can take up to 15 minutes.[79] More recently, another Macworld editor, Dan Frakes, called the procedure of repairing permissions vastly overused.[80] He argues that macOS typically handles permissions properly without user interference, and resetting permissions should only be tried when problems emerge.[81]

The architecture of macOS incorporates a layered design:[82] the layered frameworks aid rapid development of applications by providing existing code for common tasks.[83] Apple provides its own software development tools, most prominently an integrated development environment called Xcode. Xcode provides interfaces to compilers that support several programming languages including C, C++, Objective-C, and Swift. For the Mac transition to Intel processors, it was modified so that developers could build their applications as a universal binary, which provides compatibility with both the Intel-based and PowerPC-based Macintosh lines.[84] First and third-party applications can be controlled programmatically using the AppleScript framework,[85] retained from the classic Mac OS,[86] or using the newer Automator application that offers pre-written tasks that do not require programming knowledge.[87]

Software compatibility
See also: List of Mac software
Apple offered two main APIs to develop software natively for macOS: Cocoa and Carbon. Cocoa was a descendant of APIs inherited from OPENSTEP with no ancestry from the classic Mac OS, while Carbon was an adaptation of classic Mac OS APIs, allowing Mac software to be minimally rewritten to run natively on Mac OS X.[23]

The Cocoa API was created as the result of a 1993 collaboration between NeXT Computer and Sun Microsystems. This heritage is highly visible for Cocoa developers, since the "NS" prefix is ubiquitous in the framework, standing variously for NeXTSTEP or NeXT/Sun. The official OPENSTEP API, published in September 1994, was the first to split the API between Foundation and ApplicationKit and the first to use the "NS" prefix.[76] Traditionally, Cocoa programs have been mostly written in Objective-C, with Java as an alternative. However, on July 11, 2005, Apple announced that "features added to Cocoa in Mac OS X versions later than 10.4 will not be added to the Cocoa-Java programming interface."[88] macOS also used to support the Java Platform as a "preferred software package"—in practice this means that applications written in Java fit as neatly into the operating system as possible while still being cross-platform compatible, and that graphical user interfaces written in Swing look almost exactly like native Cocoa interfaces. Since 2014, Apple has promoted its new programming language Swift as the preferred language for software development on Apple platforms.

Apple's original plan with macOS was to require all developers to rewrite their software into the Cocoa APIs. This caused much outcry among existing Mac developers, who threatened to abandon the platform rather than invest in a costly rewrite, and the idea was shelved.[23][89] To permit a smooth transition from Mac OS 9 to Mac OS X, the Carbon Application Programming Interface (API) was created.[23] Applications written with Carbon were initially able to run natively on both classic Mac OS and Mac OS X, although this ability was later dropped as Mac OS X developed. Carbon was not included in the first product sold as Mac OS X: the little-used original release of Mac OS X Server 1.0, which also did not include the Aqua interface.[90] Apple limited further development of Carbon from the release of Leopard onwards and announced that Carbon applications would not run at 64-bit.[89][23] A number of macOS applications continued to use Carbon for some time afterwards, especially ones with heritage dating back to the classic Mac OS and for which updates would be difficult, uneconomic or not necessary. This included Microsoft Office up to Office 2016, and Photoshop up to CS5.[91][89] Early versions of macOS could also run some classic Mac OS applications through the Classic Environment with performance limitations; this feature was removed from 10.5 onwards and all Macs using Intel processors.

Because macOS is POSIX compliant, many software packages written for the other Unix-like systems including Linux can be recompiled to run on it, including many scientific and technical programs.[92] Third-party projects such as Homebrew, Fink, MacPorts and pkgsrc provide pre-compiled or pre-formatted packages. Apple and others have provided versions of the X Window System graphical interface which can allow these applications to run with an approximation of the macOS look-and-feel.[93][94][95] The current Apple-endorsed method is the open-source XQuartz project; earlier versions could use the X11 application provided by Apple, or before that the XDarwin project.[96]

Applications can be distributed to Macs and installed by the user from any source and by any method such as downloading (with or without code signing, available via an Apple developer account) or through the Mac App Store, a marketplace of software maintained by Apple through a process requiring the company's approval. Apps installed through the Mac App Store run within a sandbox, restricting their ability to exchange information with other applications or modify the core operating system and its features. This has been cited as an advantage, by allowing users to install apps with confidence that they should not be able to damage their system, but also as a disadvantage due to blocking the Mac App Store's use for professional applications that require elevated privileges.[97][98] Applications without any code signature cannot be run by default except from a computer's administrator account.[99][100]

Apple produces macOS applications. Some are included with macOS and some sold separately. This includes iWork, Final Cut Pro, Logic Pro, iLife, and the database application FileMaker. Numerous other developers also offer software for macOS.

In 2018, Apple introduced an application layer, codenamed Marzipan, to port iOS apps to macOS.[101][102] macOS Mojave included ports of four first-party iOS apps including Home and News, and it was announced that the API would be available for third-party developers to use from 2019.[103][104][105] With macOS Catalina in 2019, the application layer was made available to third-party developers as Mac Catalyst.[106]

Hardware compatibility
List of macOS versions, the supported systems on which they run, and their RAM requirements

Operating system	Release year(s)	Supported systems[107]	RAM requirement
10.0 – 10.2 (Jaguar)	2001 – 2002	G3, G4 and G5 iBook and PowerBook, Power Mac and iMac
(except PowerBook G3 "Kanga")	128 MB
10.3 (Panther)	2003	Macs with a New World ROM[108]
10.4 (Tiger)	2004	Macs with built-in FireWire and either a New World ROM or Intel processor	256 MB
10.5 (Leopard)	2006	Select G4, G5, and Intel Macs (32-bit or 64-bit) at 867 MHz or faster
Classic support dropped from 10.5 and later.	512 MB
10.6 (Snow Leopard)	2008	Intel Macs (32-bit or 64-bit)[109]	1 GB
10.7 (Lion)	2010	Intel Macs (64-bit)[109]
Rosetta support dropped from 10.7 and later.	2 GB
10.8 (Mountain Lion)
– 10.11 (El Capitan)

2012 – 2015	
Laptops: MacBook (Aluminum, Late 2008 or later), MacBook Air (Late 2008 or later), MacBook Pro (Mid 2007 or later)
Desktops: Mac Mini (Early 2009 or later), iMac (Mid 2007 or later), Mac Pro (Early 2008 or later)
Servers: Xserve (Early 2009)
10.12 (Sierra)
– 10.13 (High Sierra)

2016 – 2017	
Laptops: MacBook (Late 2009 or later), MacBook Air (Late 2010 or later), MacBook Pro (Mid 2010 or later)
Desktops: Mac Mini (Mid 2010 or later), iMac (Late 2009 or later), iMac Pro (2017) (macOS 10.13), Mac Pro (Mid 2010 or later)
10.14 (Mojave)	2018	
Laptops: MacBook (Early 2015 or later), MacBook Air (Mid 2012 or later), MacBook Pro (Mid 2012 or later)
Desktops: Mac Mini (Late 2012 or later), iMac (Late 2012 or later), iMac Pro (2017), Mac Pro (Mid 2010 or later[110])
10.15 (Catalina)	2019	
Laptops: MacBook (Early 2015 or later), MacBook Air (Mid 2012 or later), MacBook Pro (Mid 2012 or later)
Desktops: Mac Mini (Late 2012 or later), iMac (Late 2012 or later), iMac Pro (2017), Mac Pro (Late 2013 or later)
4 GB
11 (Big Sur)	2020	
Laptops: MacBook (Early 2015 or later), MacBook Air (Mid 2013 or later), MacBook Pro (Late 2013 or later)
Desktops: Mac Mini (Late 2014 or later), iMac (Mid 2014 or later), iMac Pro (2017), Mac Pro (Late 2013 or later)
12 (Monterey)	2021	
Laptops: MacBook (Early 2016 or later), MacBook Air (Early 2015 or later), MacBook Pro (Early 2015 or later)
Desktops: Mac Mini (Late 2014 or later), iMac (Late 2015 or later), iMac Pro (2017), Mac Studio (2022), Mac Pro (Late 2013 or later)
13 (Ventura)	2022	
Laptops: MacBook (2017), MacBook Air (2018 or later), MacBook Pro (2017 or later)
Desktops: Mac Mini (2018 or later), iMac (2017 or later), iMac Pro (2017), Mac Studio (2022 or later), Mac Pro (2019 or later)
8 GB
14 (Sonoma)	2023	
Laptops: MacBook Air (2018 or later), MacBook Pro (2018 or later)
Desktops: Mac Mini (2018 or later), iMac (2019 or later), iMac Pro (2017), Mac Studio (2022 or later), Mac Pro (2019 or later)
15 (Sequoia)	2024	
Laptops: MacBook Air (2020 or later), MacBook Pro (2018 or later)
Desktops: Mac Mini (2018 or later), iMac (2019 or later), iMac Pro (2017), Mac Studio (2022 or later), Mac Pro (2019 or later)
26 (Tahoe)	2025	
Laptops: MacBook Neo (2026), MacBook Air (M1 or later), MacBook Pro (16-inch 2019; 13-inch, 4 ports, 2020; or later)
Desktops: Mac Mini (M1 or later), iMac (2020 or later), Mac Studio (2022 or later), Mac Pro (2019 or later)
Tools such as XPostFacto and patches applied to the installation media have been developed by third parties to enable installation of newer versions of macOS on systems not officially supported by Apple. This includes a number of pre-G3 Power Macintosh systems that can be made to run up to and including Mac OS X 10.2 Jaguar, all G3-based Macs which can run up to and including Tiger, and sub-867 MHz G4 Macs can run Leopard by removing the restriction from the installation DVD or entering a command in the Mac's Open Firmware interface to tell the Leopard Installer that it has a clock rate of 867 MHz or greater. Except for features requiring specific hardware such as graphics acceleration or DVD writing, the operating system offers the same functionality on all supported hardware.

As most Mac hardware components, or components similar to those, since the Intel transition are available for purchase,[111] some technology-capable groups have developed software to install macOS on non-Apple computers. These are referred to as Hackintoshes, a portmanteau of the words "hack" and "Macintosh". This violates Apple's EULA (and is therefore unsupported by Apple technical support, warranties etc.), but communities that cater to personal users, who do not install for resale and profit, have generally been ignored by Apple.[112][113][114] These self-made computers allow more flexibility and customization of hardware, but at a cost of leaving the user more responsible for their own machine, such as on matter of data integrity or security.[115] Psystar, a business that attempted to profit from selling macOS on non-Apple certified hardware, was sued by Apple in 2008.[116]

PowerPC–Intel transition
Main article: Mac transition to Intel processors

Steve Jobs talks about the transition to Intel processors.
In April 2002, eWeek announced a rumor that Apple had a version of Mac OS X code-named Marklar, which ran on Intel x86 processors. The idea behind Marklar was to keep Mac OS X running on an alternative platform should Apple become dissatisfied with the progress of the PowerPC platform.[117] These rumors subsided until late in May 2005, when various media outlets, such as The Wall Street Journal[118] and CNET,[119] announced that Apple would unveil Marklar in the coming months.[120][121][122]

On June 6, 2005, Steve Jobs announced in his keynote address at WWDC that Apple would be making the transition from PowerPC to Intel processors over the following two years, and that Mac OS X would support both platforms during the transition. Jobs also confirmed rumors that Apple had versions of Mac OS X running on Intel processors for most of its developmental life. Intel-based Macs would run a new recompiled version of OS X along with Rosetta, a binary translation layer which enables software compiled for PowerPC Mac OS X to run on Intel Mac OS X machines.[123] The system was included with Mac OS X versions up to version 10.6.8.[124] Apple dropped support for Classic mode on the new Intel Macs. Third party emulation software such as Mini vMac, Basilisk II and SheepShaver provided support for some early versions of Mac OS. A new version of Xcode and the underlying command-line compilers supported building universal binaries that would run on either architecture.[125]

PowerPC-only software is supported with Apple's official binary translation software, Rosetta, though applications eventually had to be rewritten to run properly on the newer versions released for Intel processors. Apple initially encouraged developers to produce universal binaries with support for both PowerPC and Intel.[126] PowerPC binaries suffer a performance penalty when run on Intel Macs through Rosetta. Moreover, some PowerPC software, such as kernel extensions and System Preferences plugins, are not supported on Intel Macs at all. Plugins for Safari need to be compiled for the same platform as Safari, so when Safari is running on Intel, it requires plug-ins that have been compiled as Intel-only or universal binaries, so PowerPC-only plug-ins will not work.[127] While Intel Macs can run PowerPC, Intel, and universal binaries, PowerPC Macs support only universal and PowerPC builds.

Support for the PowerPC platform was dropped following the transition. In 2009, Apple announced at WWDC that Mac OS X 10.6 Snow Leopard would drop support for PowerPC processors and be Intel-only.[128] Rosetta continued to be offered as an optional download or installation choice in Snow Leopard before it was discontinued with Mac OS X 10.7 Lion.[129] In addition, new versions of Mac OS X first- and third-party software increasingly required Intel processors, including new versions of iLife, iWork, Aperture and Logic Pro.

Intel–Apple silicon transition
Main article: Mac transition to Apple silicon

An illustration of Apple's M1 processor
Rumors of Apple shifting Macs from Intel to in-house ARM processors used by iOS devices began circulating as early as 2011,[130] and ebbed and flowed throughout the 2010s.[131] Rumors intensified in 2020, when numerous reports announced that the company would announce its shift to its custom processors at WWDC.[132]

Apple officially announced its shift to processors designed in-house on June 22, 2020, at WWDC 2020, with the transition planned to last for approximately two years.[133] The first release of macOS to support ARM was macOS Big Sur. Big Sur and later versions support Universal 2 binaries, which are applications consisting of both Intel (x86-64) and Apple silicon (AArch64) binaries; when launched, only the appropriate binary is run. Additionally, Intel binaries can be run on Apple silicon-based Macs using the Rosetta 2 binary translation software. The transition was completed at WWDC 2023 with the announcement of the Apple silicon Mac Pro, ending the transition in 3 years, slightly behind schedule.

The change in processor architecture allows Macs with ARM processors to be able to run iOS and iPadOS apps natively.[134]

Features
User interface
The macOS user interface places a menu bar along the top edge of the screen, containing the Apple menu and application menus at the start, and status menus at the end. The Dock is placed along the bottom of the screen by default, and contains icons for pinned and active applications, file and folder shortcuts, minimized windows, and the Trash (or Bin). On most windows, the start of the title bar has three buttons resembling a horizontal traffic light, which respectively close, minimize, and resize the window.

Apple has continued to change aspects of the macOS appearance and design, particularly with tweaks to the appearance of windows and the menu bar. Since 2012, Apple has sold almost all of its Mac models with high-resolution Retina displays, and macOS and its APIs have extensive support for resolution-independent development on supporting high-resolution displays. Reviewers have described Apple's support for the technology as superior to that on Windows.[135][136][137]

The human interface guidelines published by Apple for macOS are followed by many applications, giving them consistent user interface and keyboard shortcuts.[138] Services available in every Cocoa application include spelling and grammar checkers, special characters palette, color picker, font chooser and dictionary. The graphics system OpenGL composites windows onto the screen to allow hardware-accelerated drawing. This technology, introduced in version 10.2, is called Quartz Extreme, a component of Quartz. Quartz's internal imaging model correlates well with the Portable Document Format (PDF) imaging model, making it easy to output PDF to multiple devices.[139] As a side result, PDF viewing and creating PDF documents from any application are built-in features.[140] Reflecting its popularity with design users, macOS also has system support for a variety of professional video and image formats and includes an extensive pre-installed font library, featuring many prominent brand-name designs.[141]

Aqua
Main article: Aqua (user interface)

The original Aqua user interface as seen in the Mac OS X Public Beta from 2000
A major addition between the classic Mac OS and the first major release of Mac OS X was Aqua, a design language with water-like elements. It was designed to appear lickable.[142] Every window element, text, graphic, or widget was drawn on-screen using spatial anti-aliasing technology.[143] The preexisting ColorSync technology was improved and built into the core drawing engine, to provide color matching for printing and multimedia professionals.[139] Drop shadows were added around windows and isolated text elements to provide a sense of depth. New interface elements were integrated, including sheets (dialog boxes attached to specific windows) and drawers, which would slide out and provide options.

The use of soft edges, translucent colors, and pinstripes, similar to the hardware design of the first iMacs, brought more texture and color to the user interface when compared to what Mac OS 9 and Mac OS X Server 1.0's Platinum appearance had offered. According to Siracusa, the introduction of Aqua and its departure from the then conventional look "hit like a ton of bricks."[144] Bruce Tognazzini (who founded the original Apple Human Interface Group) said that the Aqua interface in Mac OS X 10.0 represented a step backwards in usability compared with the original Mac OS interface.[145][146] Third-party developers started producing skins for customizable applications and other operating systems which mimicked the Aqua appearance. To some extent, Apple has used the successful transition to this design as leverage, at various times threatening legal action against people who make or distribute software with an interface the company says is derived from its copyrighted design.[147]

Following a similar design change in iOS 7, OS X Yosemite shifted to a flat design language, simplifying many of the Aqua elements and icons.[148] In 2025, macOS Tahoe adopted the Liquid Glass design language,[149] which was inspired in part by Aqua.[150]

Built-in components
Main article: List of built-in macOS apps
The Finder is a file browser allowing quick access to all areas of the computer, which has been modified throughout subsequent releases of macOS.[151][152] Quick Look has been part of the Finder since version 10.5. It allows for dynamic previews of files, including videos and multi-page documents without opening any other applications. Spotlight, a file searching technology which has been integrated into the Finder since version 10.4, allows rapid real-time searches of data files; mail messages; photos; and other information based on item properties (metadata) or content.[153][154]

Apple added Exposé in version 10.3 (called Mission Control since version 10.7), a feature which includes three functions to help accessibility between windows and desktop. Its functions are to instantly reveal all open windows as thumbnails for easy navigation to different tasks, display all open windows as thumbnails from the current application, and hide all windows to access the desktop.[155] FileVault is optional encryption of the user's files with the 128-bit Advanced Encryption Standard (AES-128).[156]

Features introduced in version 10.4 include Automator, an application designed to create an automatic workflow for different tasks;[157] Dashboard, a full-screen group of small applications called desktop widgets that can be called up and dismissed in one keystroke;[158] and Front Row, a media viewer interface accessed by the Apple Remote.[159] Sync Services allows applications to access a centralized extensible database for various elements of user data, including calendar and contact items. The operating system then managed conflicting edits and data consistency.[160]

All system icons are scalable up to 512×512 pixels as of version 10.5 to accommodate various places where they appear in larger size, including for example the Cover Flow view, a three-dimensional graphical user interface included with iTunes, the Finder, and other Apple products for visually skimming through files and digital media libraries via cover artwork. That version also introduced Spaces, a virtual desktop implementation which enables the user to have more than one desktop and display them in an Exposé-like interface;[161] an automatic backup technology called Time Machine, which allows users to view and restore previous versions of files and application data;[162] and Screen Sharing was built in for the first time.[163]

Apple has developed support for emoji characters by including the proprietary Apple Color Emoji font.[164][165] Apple has also connected macOS with social networks such as Twitter and Facebook through the addition of share buttons for content such as pictures and text.[166] Apple has brought several applications and features that originally debuted in iOS, its mobile operating system, to macOS, notably the intelligent personal assistant Siri, which was introduced in version 10.12 of macOS.[167][168]

Multilingual support
There are 47 system languages available in macOS for the user at the moment of installation; the system language is used throughout the entire operating system environment.[169] Input methods for typing in dozens of scripts can be chosen independently of the system language.[170] Updates have added increased support for Chinese characters and interconnections with popular social networks in China.[171][172][173][174]

Updating methods

macOS can be updated using the Software Update settings pane in System Settings or the softwareupdate command line utility. Until OS X 10.8 Mountain Lion, a separate Software Update application performed this functionality. In Mountain Lion and later, this was merged into the Mac App Store application, although the underlying update mechanism remains unchanged and is fundamentally different from the download mechanism used when purchasing an App Store application. In macOS 10.14 Mojave, the updating function was moved again to the Software Update settings pane.

Most Macs receive six or seven years of macOS updates. After a new major release of macOS, the previous two releases still receive occasional updates, but many security vulnerabilities are only patched in the latest macOS release.[175]

Release history
Main article: macOS version history § Releases

Timeline of versions
Mac OS X versions were named after big cats, with the exception of Mac OS X Server 1.0 and the original public beta, from Mac OS X 10.0 until OS X 10.9 Mavericks, when Apple switched to using California locations. Prior to its release, version 10.0 was code named internally at Apple as "Cheetah", and Mac OS X 10.1 was code named internally as "Puma". After the immense buzz surrounding Mac OS X 10.2, codenamed "Jaguar", Apple's product marketing began openly using the code names to promote the operating system. Mac OS X 10.3 was marketed as "Panther", Mac OS X 10.4 as "Tiger", Mac OS X 10.5 as "Leopard", Mac OS X 10.6 as "Snow Leopard", Mac OS X 10.7 as "Lion", OS X 10.8 as "Mountain Lion", and OS X 10.9 as "Mavericks".

"Panther", "Tiger" and "Leopard" are registered as trademarks of Apple,[176][177][178] but "Cheetah", "Puma" and "Jaguar" have never been registered. Apple has also registered "Lynx" and "Cougar" as trademarks, though these were allowed to lapse.[179][180] Computer retailer Tiger Direct sued Apple for its use of the name "Tiger". On May 16, 2005, a US federal court in the Southern District of Florida ruled that Apple's use did not infringe on Tiger Direct's trademark.[181]

Mac OS X Public Beta
Main article: Mac OS X Public Beta
On September 13, 2000, Apple released a US$29.95[182] "preview" version of Mac OS X, internally codenamed Kodiak, to gain feedback from users.

The "PB", as it was known, marked the first public availability of the Aqua interface and Apple made many changes to the UI based on customer feedback. Mac OS X Public Beta expired and ceased to function in Spring 2001.[183]

Mac OS X 10.0
Main article: Mac OS X 10.0

Screenshot of OS X 10.0
On March 24, 2001, Apple released Mac OS X 10.0 (internally codenamed Cheetah).[184] The initial version was slow,[185] incomplete,[186] and had very few applications available at launch, mostly from independent developers.[187] While many critics suggested that the operating system was not ready for mainstream adoption, they recognized the importance of its initial launch as a base on which to improve.[186] Simply releasing Mac OS X was received by the Macintosh community as a great accomplishment,[186] for attempts to overhaul the Mac OS had been underway since 1996, and had been delayed by countless setbacks.

Mac OS X 10.1
Main article: Mac OS X 10.1
Later that year, on September 25, 2001, Mac OS X 10.1 (internally codenamed Puma) was released. It featured increased performance and provided missing features, such as DVD playback. Apple released 10.1 as a free upgrade CD for 10.0 users, in addition to the $129 boxed version for people running Mac OS 9. It was discovered that the upgrade CDs were full install CDs that could be used with Mac OS 9 systems by removing a specific file; Apple later re-released the CDs in an actual stripped-down format that did not facilitate installation on such systems.[188] On January 7, 2002, Apple announced that Mac OS X was to be the default operating system for all Macintosh products by the end of that month.[189]

Mac OS X 10.2 Jaguar
Main article: Mac OS X Jaguar
On August 23, 2002,[190] Apple followed up with Mac OS X 10.2 Jaguar, the first release to use its code name as part of the branding.[191] It brought significant performance improvements, and an updated version of Aqua's visual design. Jaguar also included over 150[192] new user-facing features, including Quartz Extreme for compositing graphics directly on an ATI Radeon or Nvidia GeForce2 MX AGP-based video card with at least 16 MB of VRAM, a system-wide repository for contact information in the new Address Book, and the iChat instant messaging client.[193] The Happy Mac icon — which had appeared during the Mac OS startup sequence since the original Macintosh — was replaced with a grey Apple logo.[194]

Mac OS X 10.3 Panther
Main article: Mac OS X Panther
Mac OS X v10.3 Panther was released on October 24, 2003. It significantly improved performance and incorporated the most extensive update yet to the user interface. Panther included as many or more new features as Jaguar had the year before, including an updated Finder, incorporating a brushed-metal interface, Fast user switching, Exposé (Window manager), FileVault, Safari, iChat AV (which added video conferencing features to iChat), improved Portable Document Format (PDF) rendering and much greater Microsoft Windows interoperability.[195] Support for some early G3 computers such as "beige" Power Macs and "WallStreet" PowerBooks was discontinued.[196]

Mac OS X 10.4 Tiger
Main article: Mac OS X Tiger

Screenshot of Tiger
Mac OS X 10.4 Tiger was released on April 29, 2005. Apple stated that Tiger contained more than 200 new features.[197] As with Panther, certain older machines were no longer supported; Tiger requires a Mac with 256 MB and a built-in FireWire port.[108] Among the new features, Tiger introduced Spotlight, Dashboard, Smart Folders, updated Mail program with Smart Mailboxes, QuickTime 7, Safari 2, Automator, VoiceOver, Core Image and Core Video. The initial release of the Apple TV used a modified version of Tiger with a different graphical interface and fewer applications and services.[198] On January 10, 2006, Apple released the first Intel-based Macs along with the 10.4.4 update to Tiger. This operating system functioned identically on the PowerPC-based Macs and the new Intel-based machines, with the exception of the Intel release lacking support for the Classic environment.[199]

Mac OS X 10.5 Leopard
Main article: Mac OS X Leopard
Mac OS X 10.5 Leopard was released on October 26, 2007. It was called by Apple "the largest update of Mac OS X". It brought more than 300 new features.[200] Leopard supports both PowerPC- and Intel x86-based Macintosh computers; support for the G3 processor was dropped and the G4 processor required a minimum clock rate of 867 MHz, and at least 512 MB of RAM to be installed. The single DVD works for all supported Macs (including 64-bit machines). New features include a new look, an updated Finder, Time Machine, Spaces, Boot Camp pre-installed,[201] full support for 64-bit applications (including graphical applications), new features in Mail and iChat, and a number of new security features. Leopard is an Open Brand UNIX 03 registered product on the Intel platform. It was also the first BSD-based OS to receive UNIX 03 certification.[202][203] Leopard dropped support for the Classic Environment and all Classic applications.[204] It was the final version of Mac OS X to support the PowerPC architecture.[205]

Mac OS X 10.6 Snow Leopard
Main article: Mac OS X Snow Leopard
Mac OS X 10.6 Snow Leopard was released on August 28, 2009. Rather than delivering big changes to the appearance and end user functionality like the previous releases of Mac OS X, Snow Leopard focused on "under the hood" changes, increasing the performance, efficiency, and stability of the operating system. For most users, the most noticeable changes were: the disk space that the operating system frees up after a clean install compared to Mac OS X 10.5 Leopard, a more responsive Finder rewritten in Cocoa, faster Time Machine backups, more reliable and user-friendly disk ejects, a more powerful version of the Preview application, as well as a faster Safari web browser. Snow Leopard only supported machines with Intel CPUs, required at least 1 GB of RAM, and dropped default support for applications built for the PowerPC architecture (Rosetta could be installed as an additional component to retain support for PowerPC-only applications).[206]

Snow Leopard also featured new 64-bit technology capable of supporting greater amounts of RAM, improved support for multi-core processors through Grand Central Dispatch, and advanced GPU performance with OpenCL.[207]

The 10.6.6 update also introduced support for the Mac App Store, Apple's digital distribution platform for macOS applications.[208]


OS X Lion was announced at WWDC 2011 at Moscone West.
OS X 10.7 Lion
Main article: OS X Lion
OS X 10.7 Lion was released on July 20, 2011. It brought developments made in Apple's iOS, such as an easily navigable display of installed applications called Launchpad and a greater use of multi-touch gestures, to the Mac. This release removed Rosetta, making it incompatible with PowerPC applications.[129]

Changes made to the GUI include auto-hiding scrollbars that only appear when they are used, and Mission Control which unifies Exposé, Spaces, Dashboard, and full-screen applications within a single interface.[209] Apple also made changes to applications: they resume in the same state as they were before they were closed, similar to iOS. Documents auto-save by default.[210]

OS X 10.8 Mountain Lion
Main article: OS X Mountain Lion
OS X 10.8 Mountain Lion was released on July 25, 2012.[72] Following the release of Lion the previous year, it was the first of the annual rather than two-yearly updates to OS X (and later macOS), which also closely aligned with the annual iOS operating system updates. It incorporates some features seen in iOS 5, which include Game Center, support for iMessage in the new Messages messaging application, and Reminders as a to-do list app separate from iCal (which is renamed as Calendar, like the iOS app). It also includes support for storing iWork documents in iCloud.[211] Notification Center, which makes its debut in Mountain Lion, is a desktop version similar to the one in iOS 5.0 and higher. Application pop-ups are now concentrated on the corner of the screen, and the Center itself is pulled from the right side of the screen. Mountain Lion also includes more Chinese features including support for Baidu as an option for Safari search engine, QQ, 163.com and 126.com services for Mail, Contacts and Calendar, Youku, Tudou and Sina Weibo are integrated into share sheets.[174]

Starting with Mountain Lion, Apple software updates (including the OS) are distributed via the App Store.[212] This updating mechanism replaced the Apple Software Update utility.[213]

OS X 10.9 Mavericks
Main article: OS X Mavericks

Screenshot of OS X Mavericks
OS X 10.9 Mavericks was released on October 22, 2013. It was a free upgrade to all users running Snow Leopard or later with a 64-bit Intel processor.[214] Its changes include the addition of the previously iOS-only Maps and iBooks applications, improvements to the Notification Center, enhancements to several applications, and many under-the-hood improvements.[215]

OS X 10.10 Yosemite
Main article: OS X Yosemite
OS X 10.10 Yosemite was released on October 16, 2014. It features a redesigned user interface similar to that of iOS 7, intended to feature a more minimal, text-based 'flat' design, with use of translucency effects and intensely saturated colors.[216] Apple's showcase new feature in Yosemite is Handoff, which enables users with iPhones running iOS 8.1 or later to answer phone calls, receive and send SMS messages, and complete unfinished iPhone emails on their Mac. As of OS X 10.10.3, Photos replaced iPhoto and Aperture.[217]

OS X 10.11 El Capitan
Main article: OS X El Capitan

Screenshot of El Capitan
OS X 10.11 El Capitan was released on September 30, 2015. Similar to Mac OS X 10.6 Snow Leopard, Apple described this release as emphasizing "refinements to the Mac experience" and "improvements to system performance".[218] Refinements include public transport built into the Maps application, GUI improvements to the Notes application, adopting San Francisco as the system font for clearer legibility, and the introduction of System Integrity Protection.

The Metal API, first introduced in iOS 8, was also included in this operating system for "all Macs since 2012".[219] According to Apple, Metal accelerates system-level rendering by up to 50 percent, resulting in faster graphics performance for everyday apps. Metal also delivers up to 10 times faster draw call performance for more fluid experience in games and pro apps.[220]

macOS 10.12 Sierra
Main article: macOS Sierra
macOS 10.12 Sierra was released to the public on September 20, 2016. New features include the addition of Siri, Optimized Storage, and updates to Photos, Messages, and iTunes.[221][222]

macOS 10.13 High Sierra
Main article: macOS High Sierra
macOS 10.13 High Sierra was released to the public on September 25, 2017.[223] Like OS X El Capitan and OS X Mountain Lion, High Sierra is a refinement-based update having very few new features visible to the user, including updates to Safari, Photos, and Mail, among other changes.[224]

The major change under the hood is the switch to the Apple File System, optimized for the solid-state storage used in most new Mac computers.[225]

macOS 10.14 Mojave
Main article: macOS Mojave
macOS 10.14 Mojave was released on September 24, 2018.[63] The update introduced a system-wide dark mode and several new apps lifted from iOS, such as Apple News. It was the first version to require a GPU that supports Metal. Mojave also changed the system software update mechanism from the App Store (where it had been since OS X Mountain Lion) to a new panel in System Preferences. App updates remain in the App Store.

macOS 10.15 Catalina
Main article: macOS Catalina
macOS 10.15 Catalina was released on October 7, 2019.[226] Updates included enhanced voice control, and bundled apps for music, video, and podcasts that together replace the functions of iTunes, and the ability to use an iPad as an external monitor. Catalina officially dropped support for 32-bit applications.[227]

macOS 11 Big Sur
Main article: macOS Big Sur
macOS Big Sur was announced during the WWDC keynote speech on June 22, 2020,[228] and it was made available to the general public on November 12, 2020. This is the first time the major version number of the operating system has been incremented since the Mac OS X Public Beta in 2000. It brings Arm support,[229] new icons, and aesthetic user interface changes to the system.[230]

macOS 12 Monterey
Main article: macOS Monterey
macOS Monterey was announced during the WWDC keynote speech on June 7, 2021, and released on October 25, 2021, introducing Universal Control (which allows input devices to be used with multiple devices simultaneously), Focus modes (which allows selectively limiting notifications and alerts depending on user-defined user/work modes), Shortcuts (a task automation framework previously only available on iOS and iPadOS expected to replace Automator), a redesigned Safari Web browser, and updates and improvements to FaceTime.[231]

macOS 13 Ventura
Main article: macOS Ventura
macOS Ventura was announced during the WWDC keynote speech on June 6, 2022[232] and released on October 24, 2022.[233] It came with the redesigned System Preferences (named System Settings) to a more iOS-like design, and the new Freeform, Weather and Clock apps that run natively on Mac. Users can use an iPhone as a webcam for video conferencing with Continuity Camera. Siri's appearance was changed to look more like the versions on iOS 14 and iPadOS 14. Mail introduced schedule send and undo send for emails, and Message also got the ability to undo send and edit messages. Stage Manager was introduced as a new way to organize all open windows in a desktop. Maps gained the feature for multiple-stop routes, Metal 3 was added with support for spatial and temporal image upscaling, Lockdown Mode was added to reduce the risk of a cyberattack, and the ability to play ambient background sounds was added as an accessibility feature in System Settings.

macOS 14 Sonoma
Main article: macOS Sonoma

Screenshot of Sonoma
macOS Sonoma was announced during the WWDC keynote speech on June 5, 2023, and released on September 26, 2023.[234] macOS Sonoma revamped widgets—they can now be placed anywhere on the desktop. Game mode optimizes game performance by prioritizing gaming tasks and allocating more GPU and CPU capacity to the game, and by doing so is able to provide smoother frame rates for gameplay. The Spotlight Search bar and all app icons were made even more rounded, smoother animations were implemented for notifications and the lock screen, and new slow-motion screensavers of different locations worldwide were added. When logged in, they gradually slow down and become the desktop wallpaper.

macOS 15 Sequoia
Main article: macOS Sequoia
macOS Sequoia was announced during the WWDC keynote speech on June 10, 2024. It adds support for Apple Intelligence features (for example a redesigned Siri, writing tools, Image Playground, Genmoji, and system-wide integration with GPT-4o), as well as adding iPhone Mirroring, a new dedicated Passwords app for faster autofilling and more organized passwords, and window tiling—a similar feature to Microsoft Windows' Aero Snap window snapping feature.[235]

macOS 26 Tahoe
Main article: macOS Tahoe
macOS Tahoe was announced on June 9, 2025, during the WWDC 2025 keynote address. It is the first macOS version to feature the new Liquid Glass design introduced across Apple operating systems that year. It is also the first macOS to use Apple's new release number convention, which gives all of Apple's operating systems the same version number. It was released on September 15, 2025.[236]

Security
Apple publishes Apple Platform Security documents to lay out the security protections built into macOS and Mac hardware.[237]

macOS supports additional hardware-based security features on Apple silicon Macs:[238]

Write xor execute prevents some security vulnerabilities by making memory pages either writable or executable, but not both.[238]
PCIe or Thunderbolt devices are prevented by IOMMUs from reading system memory that is not explicitly mapped to them, unlike Intel-based Macs.[238][239]
macOS's optional Lockdown Mode enables additional protections, such as disabling just-in-time compilation for Safari's JavaScript engine, blocks FaceTime calls unless you have previously called that person or contact, location information is excluded when photos are being shared, Game Center is disabled, and accessories have to be approved and your Mac has to be unlocked. These prevent some vulnerabilities within macOS.[240]

Only the latest major release of macOS (currently macOS Tahoe) receives patches for all known security vulnerabilities. The previous two releases receive some security updates, but not for all vulnerabilities known to Apple. In 2021, Apple fixed a critical privilege escalation vulnerability in macOS Big Sur, but a fix remained unavailable for the previous release, macOS Catalina, for 234 days, until Apple was informed that the vulnerability was being used to infect the computers of Hong Kong citizens and other people who visited Hong Kong pro-democracy websites that may have been blocked in Hong Kong.[241][242]

macOS Ventura added support for Rapid Security Response (RSR) updates and Lockdown Mode. Rapid Security Response updates may require a reboot, but take less than a minute to install.[243][244] In an analysis, Hackintosh developer Mykola Grymalyuk noted that RSR updates can only fix userland vulnerabilities, and cannot patch the macOS kernel.[245] Lockdown Mode is an optional security feature designed to provide extreme protection for users who may be at risk of targeted cyberattacks, such as journalists, activists, and public figures. This mode significantly alters the functionality of the device to enhance security against sophisticated threats, particularly from spyware and state-sponsored attacks. Apple says most people are never impacted by these attacks.[246]

Malware and spyware
Main article: macOS malware
In its earlier years, Mac OS X enjoyed a near-absence of the types of malware and spyware that have affected Microsoft Windows users.[247][248][249] macOS has a smaller usage share compared to Windows.[250] Worms, as well as potential vulnerabilities, were noted in 2006, which led some industry analysts and anti-virus companies to issue warnings that Apple's Mac OS X is not immune to malware.[251] Increasing market share coincided with additional reports of a variety of attacks.[252] In early 2011, Mac OS X experienced a large increase in malware attacks,[253] and malware such as Mac Defender, MacProtector, and MacGuard was seen as an increasing problem for Mac users. At first, the malware installer required the user to enter the administrative password, but later versions installed without user input.[254] Initially, Apple support staff were instructed not to assist in the removal of the malware or admit the existence of the malware issue, but as the malware spread, a support document was issued. Apple announced an OS X update to fix the problem. An estimated 100,000 users were affected.[255][256] Apple releases security updates for macOS regularly,[257] as well as signature files containing malware signatures for Xprotect, an anti-malware feature part of File Quarantine present since Mac OS X Snow Leopard.[258]

Reception
Usage share
See also: Usage share of operating systems
As of January 2023, macOS is the second-most widely used general-purpose desktop operating system used on the World Wide Web following Microsoft Windows, with a 15.33% usage share, according to statistics compiled by StatCounter.[259]

Promotion
As a device company, Apple has mostly promoted macOS to sell Macs, with promotion of macOS updates focused on existing users, promotion at Apple Store and other retail partners, or through events for developers. In larger scale advertising campaigns, Apple specifically promoted macOS as better for handling media and other home-user applications, and comparing Mac OS X (especially versions Tiger and Leopard) with the heavy criticism Microsoft received for the long-awaited Windows Vista operating system.[260][261]

See also
Dock (macOS)
Classic Mac OS (1984–2001)
Comparison of BSD operating systems
Comparison of operating systems
List of operating systems
List of Mac software
Mac operating systems
References
 "The Register of UNIX© Certified Products". The Open Group. Archived from the original on August 7, 2025. Retrieved August 7, 2025.
 "What Is the I/O Kit?". IOKit Fundamentals. Archived from the original on January 22, 2021. Retrieved September 4, 2018. Apple considered several programming languages for the I/O Kit and chose a restricted subset of C++.
 "What's New in Swift". Apple Developer (Video). June 14, 2016. At 2:40. Archived from the original on August 4, 2016. Retrieved June 16, 2016.
 Clover, Juli (March 24, 2026). "macOS Tahoe 26.4 Now Available With Safari Compact Tab Bar, Battery Charge Limits and More". MacRumors. Retrieved March 24, 2026.
 "macOS Feature Availability". System Language. Archived from the original on January 22, 2021. Retrieved March 25, 2024.
 Gunnell, Marshall (June 5, 2024). "Macintosh Operating System (Mac OS)". Technopedia. Archived from the original on November 20, 2020. Retrieved January 13, 2025.
 "macOS". PC Magazine. Archived from the original on January 20, 2025. Retrieved January 13, 2025.
 Clover, Juli (September 16, 2025). "macOS Tahoe Now Available With Liquid Glass Design, Phone App, Spotlight Actions and More". MacRumors. Retrieved September 15, 2025.
 "Re: was OS X version 10.7 Lion UNIX 03 certified?". austin-group-l (Mailing list). Archived from the original on April 29, 2020. Retrieved July 22, 2021.
 *"Apple technology brief on UNIX" (PDF). Apple. Archived from the original (PDF) on July 10, 2012. Retrieved November 5, 2008.
"Mac OS X Version 10.5 on Intel-based Macintosh computers". The Open Group. May 18, 2007. Archived from the original on May 11, 2008. Retrieved February 21, 2013.
"Mac OS X Version 10.6 on Intel-based Macintosh computers". The Open Group. Archived from the original on November 16, 2014. Retrieved December 4, 2014.
"Mac OS X Version 10.8 on Intel-based Macintosh computers". The Open Group. Archived from the original on November 16, 2014. Retrieved December 4, 2014.
"OS X Version 10.9 on Intel-based Macintosh computers". The Open Group. Archived from the original on November 4, 2013. Retrieved December 4, 2014.
"OS X version 10.10 Yosemite on Intel-based Mac computers". The Open Group. Archived from the original on November 10, 2014. Retrieved December 4, 2014.
"OS X version 10.11 El Capitan on Intel-based Mac computers". The Open Group. Archived from the original on October 15, 2015. Retrieved October 23, 2015.
"macOS version 10.12 Sierra on Intel-based Mac computers". The Open Group. Archived from the original on October 2, 2016. Retrieved September 29, 2016.
"macOS version 10.13 High Sierra on Intel-based Mac computers". The Open Group. Archived from the original on September 28, 2017. Retrieved November 19, 2017.
"macOS version 10.14 Mojave on Intel-based Mac computers". The Open Group. Archived from the original on May 7, 2021. Retrieved September 24, 2018.
"macOS version 10.15 Catalina on Intel-based Mac computers". The Open Group. Archived from the original on April 10, 2021. Retrieved November 19, 2018.
"macOS version 11.0 Big Sur on Intel-based Mac computers". The Open Group. Archived from the original on October 20, 2021. Retrieved November 19, 2020.
"macOS version 11.0 Big Sur on Apple silicon-based Mac computers". The Open Group. Archived from the original on April 17, 2021. Retrieved November 19, 2020.
"macOS version 12.0 Monterey on Intel-based Mac computers". The Open Group. Archived from the original on November 5, 2021.
"macOS version 12.0 Monterey on Apple silicon-based Mac computers". The Open Group. Archived from the original on November 8, 2021.
"macOS version 13.0 Ventura on Apple Intel-based Mac computers". The Open Group. Archived from the original on December 31, 2022.
"macOS version 13.0 Ventura on Apple silicon-based Mac computers". The Open Group. Archived from the original on December 31, 2022.
"macOS version 14.0 Sonoma on Intel-based Mac computers". The Open Group. Archived from the original on October 15, 2023. Retrieved October 3, 2023.
"macOS version 14.0 Sonoma on Apple silicon-based Mac computers". The Open Group. Archived from the original on October 15, 2023. Retrieved October 3, 2023.
"macOS version 15.0 Sequoia on Intel-based Mac computers". The Open Group. Archived from the original on September 30, 2024. Retrieved September 12, 2024.
"macOS version 15.0 Sequoia on Apple silicon-based Mac computers". The Open Group. Archived from the original on October 1, 2024. Retrieved September 12, 2024.
"macOS version 26.0 Tahoe on Intel-based Mac computers". The Open Group. Archived from the original on September 15, 2025. Retrieved September 15, 2025.
"macOS version 26.0 Tahoe on Apple silicon-based Mac computers". The Open Group. Archived from the original on September 15, 2025. Retrieved September 15, 2025.
 Geller, Adam (April 27, 2012). "Mac OS X 10.4 Tiger: Perhaps the Best Version Ever". Low End Mac. Archived from the original on August 12, 2025. Retrieved July 14, 2025.
 Evans, Jonny (June 22, 2020). "WWDC 2020: Yes, Apple is dumping Intel, gently". Computerworld. Archived from the original on September 25, 2023. Retrieved September 25, 2023.
 Geller, Adam (March 14, 2012). "Good-bye, PowerPC". Low End Mac. Archived from the original on July 26, 2025. Retrieved July 14, 2025.
 "Apple Confirms End of Support for Intel Macs After macOS Tahoe". PCMAG. June 10, 2025. Archived from the original on June 26, 2025. Retrieved July 14, 2025.
 Ha, Anthony (June 10, 2013). "Apple Has A New, California-Based Naming Scheme For OS X, Starting With OS X Mavericks". TechCrunch. Archived from the original on July 9, 2017. Retrieved June 10, 2013.
 Mastroianni, Brian (June 13, 2016). "Apple unveils iOS 10, macOS, and more at WWDC 2016". CBS News. Archived from the original on September 25, 2023. Retrieved September 25, 2023. Perhaps one of the announcements that stood out the most was a slight name change. The desktop operating system Mac OS X will now be called macOS to better match with the way the company's other operating systems are named.
 Preston, Dominic (June 9, 2025). "Apple renames its operating systems". The Verge. Archived from the original on June 17, 2025. Retrieved June 10, 2025.
 "Apple BSD Overview". Apple. 2002. Archived from the original on November 7, 2018. Retrieved January 1, 2002.
 "1. System Overview". NeXTstep Concepts. NeXT. Archived from the original on November 21, 2021. Retrieved March 26, 2021.
 "Apple Facts". The Apple Museum. Archived from the original on December 21, 2008. Retrieved December 15, 2008. a joint venture with IBM, called Taligent, but was discontinued soon thereafter
 Markoff, John (December 23, 1996). "Why Apple Sees Next as a Match Made in Heaven". The New York Times. p. D1. Archived from the original on May 31, 2008.
 Fawcett, Neil (February 12, 1998). "Rhapsody suffers an identity crisis". Computer Weekly. Reed Business Information. Archived from the original on May 2, 2013. Retrieved April 19, 2012.(subscription required)
 Siracusa, John (April 3, 2008). "Rhapsody and Blues". Ars Technica. Archived from the original on November 4, 2015. Retrieved November 30, 2015.
 Siracusa, John (March 24, 2006). "Five years of Mac OS X". Ars Technica. Condé Nast Digital. Archived from the original on June 25, 2009. Retrieved April 15, 2009. Even Steve Jobs still says "ecks" instead of "ten" sometimes.
 Kelly, Spencer (February 26, 2011). Click – BBC TV programme. BBC. Archived from the original on March 18, 2011. Retrieved March 20, 2011. Of course X ("ex") does mean 10, but anyone who used to poke around on Unix systems will know that in those days anything Unix had an X ("ex") in it, and OS Ten is written OS X ("ex") in honour of the fact that it is based on UNIX, unlike its predecessors. So, hey, you can say it any way you want; me, I'm showing my age and sticking with X (ex).
 "What is an operating system (OS)?". Apple. July 15, 2004. Archived from the original on February 26, 2009. Retrieved December 20, 2006. The current version of Mac OS is Mac OS X (pronounced "Mac O-S ten").
 Siracusa, John (May 13, 2011). "Here's to the crazy ones: a decade of Mac OS X reviews". Ars Technica. Archived from the original on December 8, 2015. Retrieved November 30, 2015.
 Dalrymple, Jim (March 23, 2004). "Adobe discontinues FrameMaker for Macintosh". Macworld. Archived from the original on December 8, 2015. Retrieved November 30, 2015.
 Siracusa, John (July 20, 2011). "Lion review". Ars Technica. Archived from the original on December 14, 2015.
 Rubenstein, John (July 1, 2011). "Jon Rubinstein sends message to HP staff; Addresses TouchPad reviews". WebOS Nation. Archived from the original on December 8, 2015. Retrieved November 30, 2015.
 Spolsky, Joel (June 13, 2004). "How Microsoft Lost the API War". Archived from the original on April 26, 2009. Retrieved April 15, 2009. The developers of the Macintosh OS at Apple have always been in this camp [i.e. not trying to be backwards compatible no matter what]. It's why so few applications from the early days of the Macintosh still work...
 Siracusa, John (October 15, 2001). "Mac OS X 10.1". Ars Technica. Archived from the original on December 13, 2023. Retrieved June 24, 2025.
 "Apple Makes Mac OS X the Default Operating System on All Macs". Apple Newsroom. Archived from the original on October 10, 2017. Retrieved June 24, 2025.
 "About Mac OS 10.2 (Jaguar) and 10.3 (Panther)". University of California. Archived from the original on October 11, 2013.
 Siracusa, John (November 9, 2003). "OS X Panther review". Ars Technica. Archived from the original on November 26, 2015. Retrieved November 30, 2015.
 Gregg Keizer (January 29, 2007). "Microsoft's Vista Had Major Mac Envy, Company E-Mails Reveal". Information Week. Archived from the original on July 11, 2021. Retrieved July 10, 2021.
 Orlowski, Andrew. "The Jagwyre Review". The Register. Archived from the original on September 20, 2017. Retrieved September 19, 2017. Using Mac OS X is like touring a land of fabulous ancient treasures – with a tourist authority that's still busy renovating them, and that hasn't quite completed the infrastructure. The sights can be breathtaking, but the roads are potholed and incomplete, and sometimes you have to get out and push. There are a few magnificent modern additions – Rendezvous, AppleScript Studio, for example – but in places the modern Apple archaeologists seem to have forgotten their ancestors techniques, and have resorted to inferior contemporary methods such as the Windows bodge of using three letter extensions for identifying the file type.
 Thompson, Ben (August 2, 2017). "Apple and the Oak Tree". Stratechery. Archived from the original on September 20, 2017. Retrieved September 19, 2017.
 Rizzo, John (November 12, 2003). "Mac OS X 10.3 Panther". Archived from the original on December 8, 2008. Retrieved April 15, 2009. Once you reboot, you'll notice that Apple has abandoned the light and airy Aqua interface for the darker, heavier brushed-metal look of iTunes.
 W., Jeff (May 27, 2008). "Mac OS X (10.5) – User Interface Changes". University of Wisconsin. Archived from the original on July 20, 2011. Retrieved April 15, 2009.
 Siracusa, John (October 29, 2007). "OS X Leopard review". Ars Technica. Archived from the original on November 25, 2015. Retrieved November 30, 2015.
 "Mac OS X versions (builds) for computers – Apple Support". support.apple.com. Archived from the original on May 14, 2015. Retrieved May 24, 2015.
 Chartier, David (April 12, 2007). "Apple announces Leopard delays due to the iPhone". Engadget. Archived from the original on December 8, 2015. Retrieved November 30, 2015.
 Gruber, John. "WWDC 2009 Wrap-Up". Daring Fireball. Archived from the original on December 8, 2015. Retrieved November 30, 2015.
 "Apple to Ship Mac OS X Leopard on October 26". apple.com (Press release). Archived from the original on January 28, 2018. Retrieved January 2, 2018.
 "Mac OS X 10.6 Snow Leopard". Apple Store (U.S.). Archived from the original on May 25, 2015. Retrieved May 24, 2015.
 Turner, Dan. "Apple's Snow Leopard—an OS without new features". Macworld. Archived from the original on January 9, 2018. Retrieved January 8, 2018.
 Brand, Thomas (July 24, 2012). "Apple's History of Skeuomorphism". Egg Freckles. Archived from the original on August 3, 2020. Retrieved March 21, 2020.
 Cunningham, Andrew (July 29, 2012). "Server, simplified: A power user's guide to OS X Server". Ars Technica. Archived from the original on December 8, 2015. Retrieved December 2, 2015.
 Arthur, Charles (October 30, 2012). "Apple's Tim Cook shows ruthless streak in firing maps and retail executives | Technology | guardian.co.uk". Guardian. London. Archived from the original on October 24, 2017. Retrieved December 6, 2012.
 Siracusa, John (October 22, 2013). "OS X Mavericks review". Ars Technica. Archived from the original on November 22, 2015. Retrieved November 30, 2015.
 Siracusa, John (October 16, 2014). "OS X Yosemite review". Ars Technica. Archived from the original on November 24, 2015. Retrieved November 30, 2015.
 Siracusa, John (September 1, 2009). "Mac OS X 10.6 Snow Leopard: the Ars Technica review". Ars Technica. Archived from the original on December 5, 2022. Retrieved June 24, 2025.
 Gruber, John. "Mountain Lion". Daring Fireball. Archived from the original on August 11, 2015. Retrieved August 15, 2015.
 Arment, Marco. "Apple has lost the functional high ground". Archived from the original on October 31, 2021. Retrieved August 15, 2015.
 Hattersley, Lucy. "Mac OS X El Capitan review: The best (and worst) new features". Macworld UK. Archived from the original on May 11, 2017. Retrieved May 19, 2017.
 "Apple just renamed one of its oldest and most important products". Business Insider. June 13, 2016. Archived from the original on November 11, 2016. Retrieved November 11, 2016.
 Apple – WWDC 2016 Keynote. June 15, 2016. Event occurs at 2:02:50. Archived from the original on August 31, 2019. Retrieved August 21, 2019.
 Siracusa, John (July 20, 2011). "Mac OS X 10.7 Lion: the Ars Technica review". Ars Technica. Archived from the original on May 4, 2012. Retrieved October 7, 2022.
 Bhartiya, Swapnil (January 13, 2015). "Linus Torvalds: Apple's HFS+ is probably the worst file system ever". CIO. Archived from the original on October 3, 2022. Retrieved October 7, 2022.
 Oakley, Howard (May 16, 2022). "Should you continue using HFS+?". The Eclectic Light Company. Archived from the original on June 19, 2022. Retrieved October 7, 2022.
 Swain, Chris. "APFS in macOS High Sierra". Macs in Chemistry. Archived from the original on October 26, 2022. Retrieved October 7, 2022.
 Juli Clover (September 24, 2018). "Apple Releases macOS Mojave With Dark Mode, Stacks, Dynamic Desktop and More". MacRumors. Archived from the original on September 21, 2022. Retrieved September 24, 2018.
 Cunningham, Andrew (October 7, 2019). "macOS 10.15 Catalina: The Ars Technica review". Ars Technica. Archived from the original on September 22, 2022. Retrieved October 7, 2019.
 Tung, Liam (June 23, 2020). "Apple Big Sur: Here's what makes new macOS 'biggest update to design in over a decade'". ZDNet. Archived from the original on April 5, 2022. Retrieved June 23, 2020.
 Preston, Dominic (June 9, 2025). "Apple renames its operating systems". The Verge. Archived from the original on June 17, 2025. Retrieved June 10, 2025.
 Benedetto, Antonio G. Di (June 9, 2025). "Apple announces macOS Tahoe 26 with new design and revamped search features". The Verge. Archived from the original on June 16, 2025. Retrieved June 10, 2025.
 "Intel Macs Won't Get Updates After macOS Tahoe". MacRumors. June 9, 2025. Archived from the original on June 11, 2025. Retrieved June 10, 2025.
 John Siracusa (April 28, 2005). "Mac OS X 10.4 Tiger". Ars Technica. p. 4. Retrieved February 25, 2007.
 Apple (March 6, 2006). "Developing 64-bit applications". Apple Developer Connection. Archived from the original on September 25, 2007. Retrieved March 5, 2007.
 "Road to Mac OS X Snow Leopard: 64-bit to the Kernel". AppleInsider. October 28, 2008. Archived from the original on September 28, 2015. Retrieved September 28, 2015.
 "Mountain Lion Available Today From the Mac App Store" (Press release). Apple. July 25, 2012. Archived from the original on October 10, 2017. Retrieved January 2, 2018.
 "Older 64-bit Macs out of the picture for Mountain Lion". CNET. July 11, 2012. Archived from the original on October 1, 2015. Retrieved September 28, 2015.
 Lucy (2007). "Inside the Mac OS X Kernel" (PDF). 24th Chaos Communication Congress 24C3. Archived (PDF) from the original on August 29, 2017. Retrieved June 13, 2012.
 Grothaus, Michael (April 12, 2011). "Mac OS X Lion to tone down the Aqua". The Unofficial Apple Weblog. AOL. Archived from the original on August 28, 2011. Retrieved April 9, 2012.
 "Cocoa Fundamentals Guide: A Bit of History". ADC Reference Library. Apple Developer Connection. Archived from the original on March 7, 2016. Retrieved January 18, 2018.
 Bhartiya, Swapnil (January 13, 2015). "Linus Torvalds: Apple's HFS+ is probably the worst file system ever". ITworld. Archived from the original on May 25, 2015.
 Junio C Hamano (Gitster) (December 22, 2014). "CVE-2014-9390 aka "Git on case-insensitive filesystems"". Google+. Archived from the original on May 14, 2015.
 Griffiths, Rob (January 23, 2005). "Prevent Mac Disasters". Macworld. IDG. Archived from the original on December 31, 2023. Retrieved December 31, 2023.
 Frakes, Dan (August 5, 2006). "Repairing permissions: what you need to know". Macworld. IDG. Archived from the original on February 19, 2009. Retrieved February 8, 2009.
 Frakes, Dan (June 2, 2008). "Five Mac maintenance myths". Macworld. IDG. Archived from the original on January 23, 2009. Retrieved February 8, 2009.
 "About Developing for Mac". Apple. Archived from the original on June 2, 2012. Retrieved April 4, 2012.
 Zepko, Tom (November 6, 2003). "Why Cocoa?". Archived from the original on August 4, 2009. Retrieved April 15, 2009.
 "Adopting Universal Binaries on Mac OS X". Apple. February 22, 2007. Archived from the original on December 20, 2008. Retrieved December 15, 2008.
 Productions, Nyhthawk. "AppleScript: Graphic User Interface (GUI) Scripting". www.macosxautomation.com. Archived from the original on November 21, 2016. Retrieved January 3, 2017.
 "AppleScript Introduction". whitefiles.org. Archived from the original on January 31, 2016. Retrieved January 3, 2017.
 "The really simple guide to Automator in OS X on the Mac | RAW Mac". www.rawinfopages.com. Archived from the original on January 3, 2017. Retrieved January 3, 2017.
 "Introduction to Cocoa-Java Integration Guide". ADC Reference Library. Apple Developer Connection. Archived from the original on August 31, 2009. Retrieved April 8, 2006.
 Nack, John (April 2, 2008). "Photoshop, Lightroom, and Adobe's 64-bit roadmap". John Nack on Adobe. Adobe Systems. Archived from the original on April 14, 2015. Retrieved March 30, 2016.
 "Looking back at OS X's origins". Macworld. Archived from the original on January 3, 2012. Retrieved September 25, 2020.
 Hall, Zac (March 5, 2015). "Back to the Mac: Microsoft releases redesigned Office for Mac 2016 Preview w/ Retina support, collaboration, more". 9to5 Mac. Archived from the original on December 28, 2017. Retrieved December 27, 2017.
 Steele, Billy (May 24, 2013). "NASA WISE Deputy Project Scientist Amy Mainzer". Engadget. Archived from the original on June 25, 2017. As an astrophysicist, having the Unix core underlying the OS is key, since virtually all of our software is Unix-based in some sense
 "X11 for Mac OS X 1.0". Apple. October 28, 2003. Archived from the original on December 24, 2008. Retrieved December 15, 2008.
 Ben Byer (October 27, 2007). "Re: X11 in Leopard: xterm on start-up". Apple's x11-users mailing list. Archived from the original on February 10, 2008. Retrieved January 18, 2008.
 Michael Larabel (May 28, 2011). "X.Org Server 1.10.2 Brings A Bunch Of Bug-Fixes". phoronix. Archived from the original on June 3, 2011. Retrieved May 29, 2011.
 Slivka, Eric (February 17, 2012). "Apple Removes X11 in OS X Mountain Lion, Shifts Support to Open Source XQuartz". MacRumors. Archived from the original on February 22, 2012. Retrieved February 23, 2012.
 Counsell, Dan (November 16, 2015). "Not on the Mac App Store". Archived from the original on December 8, 2015.
 "Distributing Apps Outside the Mac App Store". Apple Developer. Apple. Archived from the original on December 8, 2015. Retrieved December 1, 2015.
 Kazmucha, Allyson (October 4, 2019). "How to open apps from an unidentified developer in OS X Mountain Lion". IMore. Archived from the original on December 31, 2021. Retrieved September 25, 2020.
 "About Gatekeeper". Apple. Archived from the original on December 4, 2015. Retrieved December 1, 2015.
 Gurman, Masrk (December 20, 2017). "Apple Plans Combined iPhone, iPad & Mac Apps to Create One User Experience". Bloomberg.com. Archived from the original on November 23, 2021. Retrieved February 2, 2019.
 Steinberger, Peter. "Marzipan: Porting iOS Apps to the Mac". PSPDFKit. Archived from the original on August 26, 2022. Retrieved February 2, 2019.
 Gartenberg, Chaim; Bohn, Dieter (June 7, 2018). "The future of the Mac comes from iOS apps". The Verge. Archived from the original on November 11, 2021. Retrieved January 29, 2019.
 Ritchie, Rene (June 4, 2018). "Marzipan: What you need to know about iOS apps on the Mac". iMore. Archived from the original on August 18, 2021. Retrieved January 29, 2019.
 Mayo, Benjamin (September 25, 2018). "Marzipan". benjaminmayo.co.uk. Archived from the original on April 14, 2019. Retrieved January 29, 2019.
 "Mac Catalyst". Apple Developer. Archived from the original on September 22, 2022. Retrieved October 6, 2022.
 macOS – Mac Hardware Requirements at the Wayback Machine (archive index)
 "Mac OS X: System Requirements". Apple. April 28, 2005. Archived from the original on August 9, 2007. Retrieved December 20, 2006.
 "System requirements for OS X Lion and Mac OS X v10.6". Apple Support. Archived from the original on September 23, 2016. Retrieved September 22, 2016.
 "Install macOS 10.14 Mojave on Mac Pro (Mid 2010) and Mac Pro (Mid 2012)". Apple Support. Archived from the original on November 12, 2020. Retrieved March 3, 2021.
 "iMac – Tech Specs – Apple". Apple Inc. Archived from the original on July 28, 2015. Retrieved July 28, 2015.
 "Home page – footer". tonymacx86.com. Archived from the original on July 28, 2015. Retrieved July 28, 2015.
 K, M. "Is installing Mavericks on Hackintosh legal?". apple.stackexchange.com. Archived from the original on August 23, 2015. Retrieved July 28, 2015.
 "Choosing the right CPU for your hackintosh". www.macbreaker.com. Archived from the original on July 11, 2015. Retrieved July 28, 2015.
 Arment, Marco. "Far Too Much Analysis Of The Alleged New Mac Pro Geekbench Score". Marco.org. Archived from the original on April 5, 2015. Retrieved August 14, 2015.
 Taub, Eric (July 16, 2008). "Apple sues Psystar to block Macintosh clones". The New York Times. Archived from the original on October 20, 2021. Retrieved August 1, 2015.
 Rothenbourg, Matthew; dePlume, Nick (August 30, 2002). "Apple Keeps x86 Torch Lit with 'Marklar'". eWeek.com. Archived from the original on September 27, 2022. Retrieved June 8, 2013.
 Clark, Don; Wingfield, Nick (May 23, 2005). "Apple Explores Use Of Chips From Intel For Macintosh Line". The Wall Street Journal. Dow Jones & Company. Archived from the original on January 15, 2015. Retrieved February 8, 2009.
 Kanellos, Michael (May 24, 2005). "Apple to Intel: Some advantage, lots of risk". CNET. CBS Interactive. Archived from the original on January 22, 2022. Retrieved January 22, 2022.
 Gruber, John. "I'll See You Intel". Daring Fireball. Archived from the original on March 13, 2016. Retrieved March 31, 2016.
 Gruber, John. "Intel-Apple Odds and Ends". Daring Fireball. Archived from the original on June 8, 2005. Retrieved March 31, 2016.
 Gruber, John. "Bombs Away". Daring Fireball. Archived from the original on April 11, 2016. Retrieved March 31, 2016.
 Siracusa, John (June 7, 2005). "Picking up the pieces: John Siracusa mourns the Power PC". Ars Technica. Archived from the original on March 29, 2016. Retrieved March 31, 2016.
 AppleInsider Staff (February 26, 2011). "Mac OS X Lion drops Front Row, Java runtime, Rosetta". AppleInsider. AppleInsider, Inc. Archived from the original on March 1, 2011. Retrieved February 27, 2011.
 "Apple to Use Intel Microprocessors Beginning in 2006" (Press release). Apple. June 6, 2005. Archived from the original on January 30, 2018. Retrieved January 2, 2018.
 "Adopting Universal Binaries". Apple. January 2006. Archived from the original on October 17, 2006. Retrieved December 20, 2006.
 Landau, Ted (May 2006). "OS X First Aid". Macworld. IDG. Archived from the original on January 9, 2009. Retrieved February 8, 2009.
 Stevens, Tim (June 10, 2009). "Snow Leopard officially puts PowerPC Macs on endangered species list". Engadget. AOL. Archived from the original on March 23, 2010. Retrieved June 15, 2009.
 Arnold Kim (February 27, 2011). "Mac OS X Lion: Drops PowerPC Emulation, Adds QuickTime Pro Features, Much More". MacRumors. Archived from the original on February 27, 2011. Retrieved February 27, 2011.
 Demerjian, Charlie (May 5, 2011). "Apple dumps Intel from laptop lines". SemiAccurate. Stone Arch Networking Services, Inc. Archived from the original on May 17, 2022. Retrieved June 25, 2020.
 "Apple Testing ARM Based Mac Prototypes with Large Magic Trackpad?". MacRumors. May 25, 2014. Archived from the original on September 15, 2022. Retrieved June 22, 2020.
 "ARM Macs: Expected at WWDC 2020, What We Know". MacRumors. Archived from the original on June 25, 2020. Retrieved June 22, 2020.
 "Apple announces Mac transition to Apple silicon" (Press release). Apple Inc. Archived from the original on June 22, 2020. Retrieved June 22, 2020.
 Lee, Nicole (June 22, 2020). "iOS apps will run natively on ARM-powered Macs". Engadget. Archived from the original on December 8, 2020. Retrieved June 23, 2020.
 Castle, Alex (February 19, 2014). "How to make the Windows desktop look good on high-DPI displays". PC World. Archived from the original on August 14, 2021. Retrieved September 25, 2020.
 Cunningham, Andrew (April 13, 2015). "Using the Retina MacBook as a Windows PC". Ars Technica. Archived from the original on July 9, 2015. Retrieved July 9, 2015.
 Hutchinson, Lee (October 28, 2014). "The Retina iMac and its 5K display… as a gaming machine? [Updated]". Ars Technica. Archived from the original on July 10, 2015. Retrieved July 9, 2015.
 O'Malley, Kevin (2003). Programming Mac OS X: A Guide for Unix Developers. Manning. p. 7. ISBN 1-930110-85-5.
 Davidson, James Duncan (2002). Learning Cocoa With Objective-C. O'Reilly. p. 6. ISBN 0-596-00301-3.
 "Mac OS X. It's what makes a Mac a Mac". Apple. Archived from the original on February 22, 2011. Retrieved March 2, 2011.
 Girard, Dave (September 9, 2013). "Making the ultimate creative content OS from bits of Windows, Mac, and Linux". Ars Technica. Archived from the original on August 19, 2015. Retrieved August 14, 2015.
 "Macworld San Francisco 2000". August 20, 2006. 6 min 45 sec. Archived from the original on December 12, 2021. Retrieved January 6, 2009 – via YouTube.
 "The Aqua Interface". Apple Human Interface Guidelines. Apple. June 9, 2008. Archived from the original on December 9, 2008. Retrieved December 16, 2008.
 Siracusa, John (October 28, 2007). "Mac OS X 10.5 Leopard: the Ars Technica review". Ars Technica. Condé Nast Digital. Archived from the original on December 16, 2008. Retrieved December 16, 2008.
 Tognazzini, Bruce (February 2000). "OS X: A First Look". Archived from the original on September 27, 2008. Retrieved November 5, 2008.
 Thomas, Matthew Paul (February 16, 2004). "My first 48 hours enduring Mac OS X". Archived from the original on October 14, 2008. Retrieved November 5, 2008.
 "Apple lowers boom on Aqua 'skins'". ZDNet. CBS Interactive. February 2, 2001. Archived from the original on January 11, 2023. Retrieved January 11, 2023.
 Siracusa, John (October 16, 2014). "OS X 10.10 Yosemite: The Ars Technica Review". Ars Technica. Archived from the original on November 24, 2015. Retrieved December 7, 2015.
 Cunningham, Andrew (June 9, 2025). "Apple's macOS 26 Tahoe has new Liquid Glass look, customizable folders, and more". Ars Technica. Archived from the original on June 10, 2025. Retrieved June 10, 2025.
 "Meet Liquid Glass - WWDC25 - Videos". Apple Developer. Archived from the original on June 10, 2025. Retrieved June 10, 2025.
 Holwerda, Thom (December 6, 2007). "Review: Mac OS X 10.5 Leopard". OS News. Archived from the original on May 15, 2009. Retrieved April 15, 2009. The next area where Apple claims to have made major improvements is the Finder.
 Siracusa, John (January 26, 2006). "Finding Leopard". Ars Technica. Condé Nast Digital. Archived from the original on February 4, 2009. Retrieved April 15, 2009. Unsurprisingly, each new Mac OS X release has been the vehicle for a parade of Finder fantasies.
 Siracusa, John (April 28, 2005). "Mac OS X 10.4 Tiger". Ars Technica. Condé Nast Digital. Archived from the original on April 2, 2009. Retrieved April 15, 2009.
 "Mac 101: Spotlight". Apple. November 6, 2008. Archived from the original on January 19, 2009. Retrieved April 15, 2009.
 "Mac 101: Exposé". Apple. October 31, 2008. Archived from the original on December 16, 2008. Retrieved December 16, 2008.
 "About FileVault". Mac OS X 10.5 Help. Apple. Archived from the original on January 13, 2009. Retrieved December 16, 2008.
 "Mac 101: Automator". Apple. November 6, 2008. Archived from the original on December 21, 2008. Retrieved December 16, 2008.
 "Mac 101: Dashboard". Apple. November 11, 2008. Archived from the original on December 10, 2008. Retrieved December 16, 2008.
 "Front Row". Apple. Archived from the original on December 15, 2008. Retrieved December 16, 2008.
 "Why Use Sync Services?". Apple. October 31, 2007. Archived from the original on October 12, 2008. Retrieved December 16, 2008.
 "Spaces. Room for everything". Apple. Archived from the original on December 15, 2008. Retrieved December 16, 2008.
 "Time Machine. A giant leap backward". Apple. Archived from the original on December 15, 2008. Retrieved December 16, 2008.
 "Finder". Apple. Archived from the original on December 15, 2008. Retrieved December 16, 2008.
 Jeff Blagdon (March 4, 2013). "How emoji conquered the world". The Verge. Archived from the original on March 6, 2013. Retrieved July 28, 2014.
 Sternbergh, Adam (November 17, 2014). "Smile, You're Speaking EMOJI: the rapid evolution of a wordless tongue". New York magazine. Archived from the original on March 26, 2017. Retrieved August 15, 2015.
 "OS X Mountain Lion: Share with iCloud, Facebook, Twitter, and other services". Apple. Archived from the original on April 19, 2016. Retrieved August 14, 2015.
 "13 Things You Can Do with macOS Sierra You Couldn't Before". Gizmodo. September 27, 2016. Archived from the original on September 27, 2016. Retrieved September 28, 2016.
 "How to use Siri in macOS Sierra: A look at using the Apple's virtual assistant on the Mac". Macworld. Archived from the original on February 4, 2017. Retrieved September 28, 2016.
 "macOS – How to Upgrade – Apple". Apple. Archived from the original on September 27, 2016. Retrieved September 28, 2016.
 "System – New system languages". Apple. Archived from the original on June 23, 2011. Retrieved June 6, 2011.
 Cheng, Jacqui (January 10, 2013). "Apple's Tim Cook visits China to talk expansion, expansion, expansion". Ars Technica. Archived from the original on September 18, 2015. Retrieved August 14, 2015.
 Foresman, Chris (February 16, 2012). "Next version of OS X to be more iOS-like than ever with Mountain Lion". Ars Technica. Conde Nast. Archived from the original on August 20, 2015. Retrieved August 14, 2015.
 Campbell, Mikey (June 8, 2015). "Apple targets China, Japan with new OS X El Capitan system fonts and input". Apple Insider. Archived from the original on September 6, 2015. Retrieved August 14, 2015.
 Panzarino, Matthew (February 16, 2012). "Apple courts China with Sina Weibo, Baidu, Youku and more integrated in Mountain Lion". The Next Web. Archived from the original on March 21, 2012. Retrieved March 15, 2012.
 Cunningham, Andrew (October 27, 2022). "Apple clarifies security update policy: Only the latest OSes are fully patched". Ars Technica. Archived from the original on February 12, 2023. Retrieved February 12, 2023.
 U.S. Trademark 78,257,226
 U.S. Trademark 78,269,988
 U.S. Trademark 78,270,003
 U.S. Trademark 78,271,630
 U.S. Trademark 78,271,639
 Kasper, Jade (May 13, 2005). "Court sides with Apple over "Tiger" trademark dispute". AppleInsider. Archived from the original on September 27, 2007. Retrieved April 25, 2006.
 John Siracusa. "Mac OS X Beta – Page 1 – (10/2000)". Ars Technica. Condé Nast Digital. Archived from the original on October 30, 2009. Retrieved March 11, 2010.
 "Mac OS X Public Beta Expires Today | News". The Mac Observer. Archived from the original on June 8, 2011. Retrieved March 11, 2010.
 Although the version is now called Cheetah by users, rare evidences can be found to prove that it was called so internally. For instance, a Q&A was created in 2005 which mentions it."Technical Q&A". Apple. October 4, 2005. Archived from the original on May 18, 2008. Retrieved December 20, 2006.
 "Mac OS X 10.0". Ars Technica. Archived from the original on April 17, 2017. Retrieved April 17, 2017.
 "Mac OS X 10.0 – Page 17 – (03/2001)". archive.arstechnica.com. Archived from the original on August 17, 2016. Retrieved April 29, 2017.
 Williams, Justin (March 11, 2008). Getting StartED with Mac OS X Leopard. Apress. ISBN 978-1-4302-0519-7. Archived from the original on January 11, 2023. Retrieved October 19, 2020.
 "Apple Cease-And-Desists Stupidity Leak". Slashdot. 2001. Archived from the original on March 25, 2021. Retrieved July 10, 2021.
 "Apple Makes Mac OS X the Default Operating System on All Macs" (Press release). Apple. January 7, 2002. Archived from the original on October 10, 2017. Retrieved January 2, 2018.
 "Jaguar "Unleashed" at 10:20 pm Tonight" (Press release). Apple. August 23, 2002. Archived from the original on January 3, 2018. Retrieved January 2, 2018.
 The headline of the press release mention "Jaguar", while the codename was not mentioned for earlier versions. See Apple's "Jaguar" press release Archived January 3, 2018, at the Wayback Machine, compared to their Mac OS X v10.0 press release Archived January 3, 2018, at the Wayback Machine and their Mac OS X v10.1 press release Archived January 3, 2018, at the Wayback Machine
 "Mac OS X 10.2 Product Information Page". Apple. August 29, 2002. Archived from the original on August 29, 2002. Retrieved June 12, 2008.
 "Apple Previews "Jaguar," the Next Major Release of Mac OS X" (Press release). Apple. May 6, 2002. Archived from the original on January 3, 2018. Retrieved January 2, 2018.
 Thomas, Tommy. "Murder on Macintosh Row: Happy Mac, 1984–2002". lowendmac.com. Archived from the original on January 3, 2018. Retrieved April 29, 2017.
 "Apple Announces Mac OS X "Panther"" (Press release). Apple. October 8, 2003. Archived from the original on January 3, 2018. Retrieved January 2, 2018.
 "Mac OS X 10.3 Panther". Low End Mac. October 24, 2003. Archived from the original on December 30, 2016. Retrieved December 31, 2016.
 "Apple Unleashes "Tiger" Friday at 6:00 p.m." (Press release). Apple. April 28, 2005. Archived from the original on March 22, 2018. Retrieved January 2, 2018.
 Mossberg, Walter S. (March 21, 2007). "From PC to TV – via Apple". All Things Digital. Dow Jones & Company. Archived from the original on May 20, 2008. Retrieved May 18, 2008.
 "Apple unveils Intel iMacs". AppleInsider. January 2006. Archived from the original on January 13, 2009. Retrieved December 15, 2008.
 "Apple – Mac OS X Leopard – Features – 300+ New Features". Apple. 2008. Archived from the original on May 1, 2008. Retrieved June 13, 2008.
 "Apple – BootCamp". Apple. 2006. Archived from the original on June 2, 2006. Retrieved June 5, 2006.
 "Mac OS X Version 10.5 on Intel-based Macintosh computers". The Open Group. Archived from the original on May 11, 2008. Retrieved December 4, 2014.
 "Mac OS X Leopard – Technology – UNIX". Leopard Technology Overview. Apple. Archived from the original on June 9, 2011. Retrieved October 26, 2007. Leopard is now an Open Brand UNIX 03 Registered Product, conforming to the SUSv3 and POSIX 1003.1 specifications for the C API, Shell Utilities, and Threads.
 "Do Classic applications work with Mac OS X 10.5 or Intel-based Macs?". Knowledge Base. Apple. January 13, 2006. Archived from the original on October 25, 2007. Retrieved October 25, 2007.
 Cheeseman, Bill (April 26, 2010). Cocoa Recipes for Mac OS X. Pearson Education. ISBN 978-0-321-70288-3. Archived from the original on January 11, 2023. Retrieved October 19, 2020.
 Lynch, Steven (June 12, 2008). "Mac OS X Snow Leopard Drops PowerPC Support". [H]ard|OCP. HardOCP. Archived from the original on September 27, 2011. Retrieved October 20, 2010.
 "The 64-Bitness of Mac OS X 10.6 Snow Leopard". Low End Mac. August 19, 2009. Archived from the original on December 27, 2016. Retrieved December 31, 2016.
 Reisinger, Don (January 6, 2011). "Mac App Store launches on Snow Leopard". CNET. CBS Interactive. Archived from the original on August 10, 2012.
 "Apple – OS X Lion – The world's most advanced desktop operating system". Apple. October 20, 2010. Archived from the original on May 23, 2011. Retrieved October 20, 2010.
 "Mac OS X 10.7 Lion Review – Document Model". Ars Technica. July 20, 2011. Archived from the original on December 20, 2016. Retrieved December 11, 2016.
 "Apple – OS X Mountain Lion – The world's most advanced desktop operating system". Apple. February 16, 2012. Archived from the original on February 16, 2012. Retrieved February 16, 2012.
 "Inside OS X 10.8 Mountain Lion: Apple overhauls software updates, App Store". AppleInsider. February 22, 2012. Archived from the original on July 6, 2016. Retrieved April 29, 2017.
 Slivka, Eric (February 16, 2012). "Software Update to Move Inside Mac App Store in OS X Mountain Lion". Archived from the original on July 1, 2016. Retrieved April 29, 2017.
 Gupta, Poornima; Chan, Edwin (October 22, 2013). "Apple gives away Mac software, unveils iPad Air". Reuters. Archived from the original on February 4, 2017.
 "OS X Mavericks Available Today Free from the Mac App Store" (Press release). Apple Inc. October 22, 2013. Archived from the original on October 10, 2017.
 Siracusa, John (October 16, 2014). "Yosemite review". Ars Technica. Archived from the original on July 20, 2017.
 Gibbs, Samuel (April 16, 2015). "Upgrading from iPhoto or Aperture to Apple's Photos? Read this". The Guardian. London. Archived from the original on May 27, 2018. Retrieved July 27, 2017.
 "Apple Announces OS X El Capitan with Refined Experience & Improved Performance". Apple Inc. June 8, 2015. Archived from the original on September 22, 2022. Retrieved August 6, 2020.
 Dhiraj, Rav (June 2015). "What's New in Metal, Part 1" (PDF). Apple Developer. Apple. p. 84. Archived from the original (PDF) on June 17, 2015. Retrieved June 17, 2015.
 "Apple – Press Info – Apple Announces OS X El Capitan with Refined Experience & Improved Performance" (Press release). Apple Inc. Archived from the original on June 8, 2015.
 "macOS". Archived from the original on September 26, 2016. Retrieved September 26, 2016.
 "Siri for Mac: How it works in Apple's macOS Sierra and what it's capable of". AppleInsider. June 14, 2016. Archived from the original on October 1, 2016. Retrieved September 28, 2016.
 Dillet, Romain. "Apple is releasing macOS High Sierra on September 25". TechCrunch. Archived from the original on October 13, 2017. Retrieved October 12, 2017.
 "macOS 10.13 High Sierra Release Date Set for Fall". OS X Daily. June 5, 2017. Archived from the original on June 27, 2017. Retrieved October 12, 2017.
 "Apple macOS High Sierra preview: the biggest Mac update you'll never see". The Verge. Archived from the original on October 13, 2017. Retrieved October 13, 2017.
 "macOS Catalina". Apple Inc. Archived from the original on November 10, 2020. Retrieved October 7, 2019.
 Nield, David (October 7, 2019). "12 Things You Can Do in macOS Catalina That You Couldn't Before". Gizmodo. G/O Media Group. Archived from the original on August 15, 2021. Retrieved October 7, 2019.
 "Apple introduces macOS Big Sur with a beautiful new design" (Press release). Apple Inc. June 22, 2020. Archived from the original on September 25, 2022. Retrieved June 22, 2020.
 "Apple debuts macOS Big Sur with all-new design, Arm support". VentureBeat. June 22, 2020. Archived from the original on July 9, 2022. Retrieved June 22, 2020.
 Heater, Brian (June 22, 2020). "Apple unveils macOS 11.0 Big Sur, featuring a new aesthetic and redesigned apps". TechCrunch. Archived from the original on September 27, 2022. Retrieved June 22, 2020.
 Apple Inc. (June 7, 2021). "Apple WWDC 2021 Keynote". apple.com. Apple Inc. Archived from the original on February 22, 2022. Retrieved June 7, 2021.
 "macOS Ventura adds powerful productivity tools and new Continuity features that make the Mac experience better than ever". Apple Inc. June 6, 2022. Archived from the original on November 3, 2022. Retrieved November 3, 2022.
 "macOS Ventura is now available". Apple Inc. October 24, 2022. Archived from the original on October 24, 2022. Retrieved November 3, 2022.
 "macOS Sonoma comes out on September 26th". The Verge. September 12, 2023. Archived from the original on September 12, 2023. Retrieved September 13, 2023.
 "macOS Sequoia Preview". Apple. Archived from the original on June 12, 2024. Retrieved June 11, 2024.
 "macOS Tahoe Now Available With Liquid Glass Design, Phone App, Spotlight Actions and More". MacRumors. September 15, 2025. Retrieved October 2, 2025.
 "Apple Platform Security". Apple Support. Archived from the original on February 12, 2023. Retrieved February 12, 2023.
 "Explore the new system architecture of Apple silicon Macs - WWDC20 - Videos". Apple Developer. Archived from the original on February 12, 2023. Retrieved February 12, 2023.
 "Direct memory access protections for Mac computers". Apple Support. Archived from the original on February 12, 2023. Retrieved February 12, 2023.
 "Apple's Lockdown Mode offers extreme security for iPhone, iPad, and Mac". Macworld. Archived from the original on February 12, 2023. Retrieved February 12, 2023.
 Cunningham, Andrew (November 12, 2021). "PSA: Apple isn't actually patching all the security holes in older versions of macOS". Ars Technica. Archived from the original on January 1, 2023. Retrieved February 12, 2023.
 Schneier, Bruce (October 31, 2022). "Apple Only Commits to Patching Latest OS Version". Schneier on Security. Archived from the original on September 27, 2023. Retrieved September 28, 2023.
 Lawler, Richard (May 1, 2023). "Apple's first iPhone Rapid Security Response patch had a problem, but it's fine now". The Verge. Archived from the original on May 2, 2023. Retrieved May 2, 2023.
 Cunningham, Andrew (May 1, 2023). "Apple uses iOS and macOS Rapid Security Response feature for the first time". Ars Technica. Archived from the original on October 3, 2023. Retrieved September 28, 2023.
 Grymalyuk, Mykola (April 18, 2023). "macOS' Rapid Security Response: Designed into a Corner". Mykola's blog. Archived from the original on May 2, 2023. Retrieved May 2, 2023.
 "About Lockdown Mode". Apple Support. Archived from the original on October 16, 2024. Retrieved October 19, 2024.
 Welch, John (January 6, 2007). "Review: Mac OS X Shines In Comparison With Windows Vista". Information Week. Archived from the original on February 9, 2007. Retrieved February 5, 2007.
 Granneman, Scott (October 6, 2003). "Linux vs. Windows Viruses". The Register. Archived from the original on September 7, 2015. Retrieved February 5, 2007.
 Gruber, John (June 4, 2004). "Broken Windows". Daring Fireball. Archived from the original on September 4, 2011. Retrieved April 24, 2006.
 "Operating System Market Share". September 2009. Archived from the original on January 25, 2010. Retrieved April 10, 2009.
 Roberts, Paul (February 21, 2006). "New Safari Flaw, Worms Turn Spotlight on Apple Security". eWeek. Archived from the original on September 27, 2022. Retrieved January 22, 2022.
 Conneally, Tim (August 28, 2009). "'Macs don't get viruses' myth dissolves before public's eyes". BetaNews. Archived from the original on August 30, 2009.
 Grimes, Roger A. (May 23, 2011). "7 questions about the Mac malware scare | Security". InfoWorld. Archived from the original on June 7, 2011. Retrieved July 5, 2011.
 "Mac Security Boasts Threatened by Malware Surge – International Business Times". Ibtimes.com. May 26, 2011. Archived from the original on August 8, 2011. Retrieved July 5, 2011.
 Trenholm, Rich (May 20, 2011). "Apple tells support staff not to confirm Mac Defender infections". CNET. Archived from the original on June 22, 2021. Retrieved March 21, 2020.
 Seltzer, Larry (May 25, 2011). "Mac Defender 2.0 Released – Security Watch". PC Mag. Archived from the original on July 17, 2011. Retrieved July 5, 2011.
 "Apple security updates". Apple. January 21, 2009. Archived from the original on February 5, 2009. Retrieved January 29, 2009.
 "XProtect Explained: How Your Mac's Built-in Anti-malware Software Works". How-To Geek. May 18, 2015. Archived from the original on March 23, 2018.
 "Desktop Operating System Market Share Worldwide". StatCounter Global Stats. Archived from the original on February 2, 2020. Retrieved February 26, 2023.
 Nudd, Tim (April 13, 2011). "Apple's Get a Mac campaign". AdWeek. Archived from the original on October 5, 2011. Retrieved December 2, 2015.
 Arthur, Charles (October 23, 2008). "Apple tweaks Microsoft over Vista ad spending". The Guardian. Archived from the original on December 8, 2015. Retrieved December 2, 2015.
External links
Wikimedia Commons logo
Wikimedia Commons has media related to macOS.
Official website Edit this at Wikidata
macOS Support – official support page
vte
macOS
vte
macOS developer tools
Links to related articles
Authority control databases Edit this at Wikidata
Categories: MacOSMacintosh operating systems1999 softwareApple Inc. operating systemsApple Inc. softwareComputer-related introductions in 1999Mach (kernel)PowerPC operating systemsX86-64 operating systemsARM operating systemsUnix variantsObject-oriented operating systems
This page was last edited on 3 April 2026, at 14:17 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policyAbout WikipediaDisclaimersContact WikipediaLegal & safety contactsCode of ConductDevelopersStatisticsCookie statementMobile view
Wikimedia Foundation
Powered by MediaWiki

    """
    """

WikipediaThe Free Encyclopedia
Search Wikipedia
Search
Donate
Create account
Log in
Contents hide
(Top)
Description
Attack

Defensive response
Attribution
Impact

Affected organisations
Reactions

United Kingdom
See also
References
External links
WannaCry ransomware attack

Article
Talk
Read
Edit
View history

Tools
Appearance hide
Birthday mode (Baby Globe)

Disabled

Enabled
Learn more about Birthday mode
Text

Small

Standard

Large
Width

Standard

Wide
Color (beta)

Automatic

Light

Dark
From Wikipedia, the free encyclopedia
For the June 2017 worldwide EternalBlue Petya cyberattack, see 2017 Ukraine ransomware attacks.
WannaCry

Screenshot of the ransom note left on an infected system
Malware details
Technical name	
WORM_WCRY.[letter] (Trend Micro)
Win32/Exploit.CVE-2017-0147.[letter] (ESET-NOD32)
Ransom:Win32/WannaCrypt (Microsoft)
Ransom.Wannacry (Symantec)
Trojan.Ransom.WannaCryptor.[letter] (BitDefender)
W32/Wanna.D!tr (Fortinet)
Aliases	Transformations:
Wanna → Wana
Cryptor → Crypt0r
Cryptor → Decryptor
Cryptor → Crypt → Cry
Addition of "2.0"
Short names:

Wanna → WN → W
Cry → CRY
Type	Worm
Subtype	Ransomware
Origin	Pyongyang, North Korea (unconfirmed)
Cyberattack event
Date	12 May 2017 – 15 May 2017 (initial outbreak)
Location	Worldwide
Theme	Ransomware encrypting files with US$300–600 demand (via Bitcoin)
Outcome	300,000+ computers infected[1][2][3]
Losses	Up to US$4 billion
Suspect	Lazarus Group
Convicted	None
Technical details
Platform	Microsoft Windows
Filename	mssecsvc.exe
Size	3.64 MB
Ports used	Server Message Block
Abused exploits	CVE-2017-0145
Written in	Microsoft Visual C++ 6.0
The WannaCry ransomware attack was a worldwide cyberattack in May 2017 by the WannaCry ransomware cryptoworm, which targeted computers running the Microsoft Windows operating system by encrypting data and demanding ransom payments in the form of bitcoin cryptocurrency.[4] It was propagated using EternalBlue, an exploit developed by the United States National Security Agency (NSA) for Microsoft Windows systems. EternalBlue was stolen and leaked by a group called The Shadow Brokers (TSB) a month prior to the attack. While Microsoft had released patches previously to close the exploit, much of WannaCry's spread was from organizations that had not applied these patches, or were using older Windows systems that were past their end of life. These patches were imperative to cyber security, but many organizations did not apply them, citing a need for 24/7 operation, the risk of formerly working applications breaking because of the changes, lack of personnel or time to install them, or other reasons.

The attack began at 07:44 UTC on 12 May 2017 and was halted a few hours later at 15:03 UTC by the registration of a kill switch discovered by Marcus Hutchins. The kill switch prevented already infected computers from being encrypted or further spreading WannaCry.[5] The attack was estimated to have affected more than 300,000 computers[6] across 150 countries,[6] with total damages ranging from hundreds of millions to billions of dollars. At the time, security experts believed from preliminary evaluation of the worm that the attack originated from North Korea or agencies working for the country. In December 2017, the United States and United Kingdom formally asserted that North Korea was behind the attack, although North Korea has denied any involvement with the attack.[7]

A new variant of WannaCry forced Taiwan Semiconductor Manufacturing Company (TSMC) to temporarily shut down several of its chip-fabrication factories in August 2018. The worm spread onto 10,000 machines in TSMC's most advanced facilities.[8][9]

Description
WannaCry is a ransomware crypto worm, which targets computers running the Microsoft Windows operating system by encrypting (locking) data and demanding ransom payments in the Bitcoin cryptocurrency. The worm is also known as WannaCrypt,[10] Wana Decrypt0r 2.0,[11] WanaCrypt0r 2.0,[12] and Wanna Decryptor.[13] It is considered a network worm because it also includes a transport mechanism to automatically spread itself. This transport code scans for vulnerable systems, then uses the EternalBlue exploit to gain access, and the DoublePulsar tool to install and execute a copy of itself.[14] WannaCry versions 0, 1 and 2 were created using Microsoft Visual C++ 6.0.[15]

EternalBlue is an exploit of Microsoft's implementation of their Server Message Block (SMB) protocol released by The Shadow Brokers. Much of the attention and comment around the event was occasioned by the fact that the U.S. National Security Agency (NSA) (from whom the exploit was likely stolen) had already discovered the vulnerability, but used it to create an exploit for its own offensive work, rather than report it to Microsoft.[16][17] Microsoft eventually discovered the vulnerability, and on Tuesday, 14 March 2017, they issued security bulletin MS17-010, which detailed the flaw and announced that patches had been released for all Windows versions that were currently supported at that time, these being Windows Vista, Windows 7, Windows 8.1, Windows 10, Windows Server 2008, Windows Server 2008 R2, Windows Server 2012, Windows Server 2012 R2, and Windows Server 2016.[18]

DoublePulsar is a backdoor tool, also released by The Shadow Brokers on 14 April 2017. Starting from 21 April 2017, security researchers reported that there were tens of thousands of computers with the DoublePulsar backdoor installed.[19] By 25 April, reports estimated that the number of infected computers could be up to several hundred thousand, with numbers increasing every day.[20][21] The WannaCry code can take advantage of any existing DoublePulsar infection, or installs it itself.[14][22][23] On 9 May 2017, private cybersecurity company RiskSense released code on GitHub with the stated purpose of allowing legal white hat penetration testers to test the CVE-2017-0144 exploit on unpatched systems.[24]

When executed, the WannaCry malware first checks the kill switch domain name (iuqerfsodp9ifjaposdfjhgosurijfaewrwergwea.com); if it is not found, then the ransomware encrypts the computer's data,[25][26][27] then attempts to exploit the SMB vulnerability to spread out to random computers on the Internet,[28] and laterally to computers on the same network.[29] On the local system, the WannaCry executable file extracts and installs binary and configuration files from its resource section. It also hides the extracted directory, modifies security descriptors, creates an encryption key, deletes shadow copies, and so on. As with other modern ransomware, the payload displays a message informing the user that their files have been encrypted, and demands a payment of around US$300 in bitcoin within three days, or US$600 within seven days,[26][30] warning that "you have not so enough time. [sic]" Three hardcoded bitcoin addresses, or wallets, are used to receive the payments of victims. As with all such wallets, their transactions and balances are publicly accessible even though the cryptocurrency wallet owners remain unknown.[31]

Several organizations released detailed technical write-ups of the malware, including a senior security analyst at RiskSense,[32][33] Microsoft,[34] Cisco,[14] Malwarebytes,[28] Symantec, and McAfee.[29]

Attack
The attack began on Friday, 12 May 2017,[35][36] with evidence pointing to an initial infection in Asia at 07:44 UTC.[35][37] The initial infection was likely through an exposed vulnerable SMB port,[38] rather than email phishing as initially assumed.[35] Within a day the code was reported to have infected more than 230,000 computers in over 150 countries.[39][40]

Organizations that had not installed Microsoft's security update from March were affected by the attack.[41] Those still running unsupported versions of Microsoft Windows, such as Windows XP and Windows Server 2003[42][43] were at particularly high risk because no security patches had been released since April 2014 for Windows XP and July 2015 for Windows Server 2003.[10] A Kaspersky Lab study reported, however, that less than 0.1 percent of the affected computers were running Windows XP, and that 98 percent of the affected computers were running Windows 7.[10][44] In a controlled testing environment, the cybersecurity firm Kryptos Logic found that it was unable to infect a Windows XP system with WannaCry using just the exploits, as the payload failed to load, or caused the operating system to crash rather than actually execute and encrypt files. However, when executed manually, WannaCry could still operate on Windows XP.[45][46][47]

Defensive response
Experts quickly advised affected users against paying the ransom due to no reports of people getting their data back after payment and as high revenues would encourage more of such campaigns.[48][49][50] As of 14 June 2017, after the attack had subsided, a total of 327 payments totaling US$130,634.77 (51.62396539 BTC) had been transferred (worth approximately US$3,390,765.29 as of 27 February 2026).[51]

The day after the initial attack in May, Microsoft released out-of-band security updates for end-of-life products Windows XP, Windows Server 2003 and Windows 8; these patches had been created in February, but were previously only available to those who paid for a custom support plan.[43][52] Organizations were advised to patch Windows and plug the vulnerability in order to protect themselves from the cyber attack.[53] The head of Microsoft's Cyber Defense Operations Center, Adrienne Hall, said that "Due to the elevated risk for destructive cyber-attacks at this time, we made the decision to take this action because applying these updates provides further protection against potential attacks with characteristics similar to WannaCrypt [alternative name to WannaCry]".[54][55]

Researcher Marcus Hutchins[56][57] discovered the kill switch domain hardcoded in the malware.[58][59][60] Registering a domain name for a DNS sinkhole stopped the attack spreading as a worm, because the ransomware only encrypted the computer's files if it was unable to connect to that domain, which all computers infected with WannaCry before the website's registration had been unable to do. While this did not help already infected systems, it severely slowed the spread of the initial infection and gave time for defensive measures to be deployed worldwide, particularly in North America and Asia, which had not been attacked to the same extent as elsewhere.[61][62][63][64][65] On 14 May, a first variant of WannaCry appeared with a new and second[66] kill-switch registered by Matt Suiche on the same day. This was followed by a second variant with the third and last kill-switch on 15 May, which was registered by Check Point threat intelligence analysts.[67][68] A few days later, a new version of WannaCry was detected that lacked the kill switch altogether.[69][70][71][72]

On 19 May, it was reported that hackers were trying to use a Mirai botnet variant to effect a distributed denial-of-service attack on WannaCry's kill-switch domain with the intention of knocking it offline.[73] On 22 May, Hutchins protected the domain by switching to a cached version of the site, capable of dealing with much higher traffic loads than the live site.[74]

Separately, researchers from University College London and Boston University reported that their PayBreak system could defeat WannaCry and several other families of ransomware by recovering the keys used to encrypt the user's data.[75][76]

It was discovered that Windows encryption APIs used by WannaCry may not completely clear the prime numbers used to generate the payload's private keys from the memory, making it potentially possible to retrieve the required key if they had not yet been overwritten or cleared from resident memory. The key is kept in the memory if the WannaCry process has not been killed and the computer has not been rebooted after being infected.[77] This behaviour was used by a French researcher to develop a tool known as WannaKey, which automates this process on Windows XP systems.[78][79][80] This approach was iterated upon by a second tool known as Wanakiwi, which was tested to work on Windows 7 and Server 2008 R2 as well.[81]

Within four days of the initial outbreak, new infections had slowed to a trickle due to these responses.[82]

Attribution
Linguistic analysis of the ransom notes suggested the authors were likely fluent in Chinese and proficient in English, as the versions of the notes in those languages appeared to be human-written while the rest seemed to be machine-translated.[83][84] According to an analysis by the FBI's Cyber Behavioral Analysis Center, the computer that created the ransomware language files had Hangul language fonts installed, as indicated by the presence of the "\fcharset129" Rich Text Format tag.[15] Metadata in the language files also showed that the computers used to create the ransomware were set to UTC+09:00, a time zone used in Korea.[15]

A security researcher[85][86] initially posted a tweet[87] referencing code similarities between WannaCry and previous malware. The cybersecurity companies[88] Kaspersky Lab and Symantec stated that the code shares some similarities with malware previously used by the Lazarus Group,[89] which has been linked to North Korea and is believed to have carried out the cyberattack on Sony Pictures in 2014 and a Bangladesh bank heist in 2016.[89] However, these similarities could result from either code reuse by another group[90] or an attempt to misattribute responsibility—as in a cyber false flag operation.[89] A leaked internal NSA memo is also alleged to have linked the creation of the worm to North Korea.[91] Brad Smith, the president of Microsoft, stated he believed North Korea was behind the WannaCry attack,[92] and the UK's National Cyber Security Centre reached the same conclusion.[93]

On 18 December 2017, the United States Government formally announced that it considers North Korea to be the main culprit behind the WannaCry attack.[94] President Donald Trump's Homeland Security Advisor, Tom Bossert, wrote an op-ed in The Wall Street Journal stating, "We do not make this allegation lightly. It is based on evidence."[95] In a press conference the following day, Bossert stated that the evidence indicated that Kim Jong-un had given the order to launch the malware attack.[96] Bossert stated that Canada, New Zealand, and Japan agreed with the United States' assessment of the evidence linking the attack to North Korea,[97] while the United Kingdom's Foreign and Commonwealth Office expressed support for the United States' assertion.[98] North Korea denied responsibility for the cyberattack.[99][100]

On 6 September 2018, the U.S. Department of Justice (DoJ) announced formal charges against Park Jin-hyok for his alleged involvement in the Sony Pictures hack of 2014. The DoJ stated that Park was a North Korean hacker working as part of a team affiliated with the North Korean Reconnaissance General Bureau. The Department of Justice further claimed this team was also involved in the WannaCry attack, among other activities.[101][102]

Impact

Map of the countries initially affected[103]
The ransomware campaign was unprecedented in scale according to Europol,[39] which estimates that around 200,000 computers were infected across 150 countries. According to Kaspersky Lab, the four most affected countries were Russia, Ukraine, India and Taiwan.[104]

One of the largest agencies struck by the attack was the National Health Service hospitals in England and Scotland,[105][106] and up to 70,000 devices—including computers, MRI scanners, blood-storage refrigerators and theatre equipment—may have been affected.[107] On 12 May, some NHS services had to turn away non-critical emergencies, and some ambulances were diverted.[108][109] In 2016, thousands of computers in 42 separate NHS trusts in England were reported to be still running Windows XP.[42] In 2018 a report by Members of Parliament concluded that all 200 NHS hospitals or other organisations checked in the wake of the WannaCry attack still failed cybersecurity checks.[110][111] NHS hospitals in Wales and Northern Ireland were unaffected by the attack.[108][112]

Nissan Motor Manufacturing UK in Tyne and Wear, England, halted production after the ransomware infected some of their systems. Renault also stopped production at several sites in an attempt to stop the spread of the ransomware.[113][114] Spain's Telefónica, FedEx and Germany's Deutsche Bahn were hit, along with many other countries and companies worldwide.[115][116][117]

The attack's impact is said to be relatively low compared to other potential attacks of the same type and could have been much worse had Hutchins not discovered that a kill switch had been built in by its creators[118][119] or if it had been specifically targeted on highly critical infrastructure, like nuclear power plants, dams or railway systems.[120][121]

According to cyber-risk-modeling firm Cyence, economic losses from the cyber attack could reach up to US$4 billion, with other groups estimating the losses to be in the hundreds of millions.[122]

Affected organisations
The following is an alphabetical list of organisations confirmed to have been affected:

Andhra Pradesh Police, India[123]
Aristotle University of Thessaloniki, Greece[124][125]
Automobile Dacia, Romania[126]
Boeing Commercial Airplanes[127]
Cambrian College, Canada[128]
Chinese public security bureau[129]
CJ CGV (a cinema chain)[130]
Dalian Maritime University[131]
Deutsche Bahn[132]
Dharmais Hospital, Indonesia[133]
Faculty Hospital, Nitra, Slovakia[134]
FedEx[135]
Garena Blade and Soul[136]
Guilin University of Aerospace Technology[131]
Guilin University of Electronic Technology[131]
Harapan Kita Hospital, Indonesia[133]
Hezhou University[131]
Hitachi[137]
Honda[138]
Instituto Nacional de Salud, Colombia[139]
Lakeridge Health, Canada[140]
LAKS, Netherlands[141]
LATAM Airlines Group[142]
MegaFon[143]
Ministry of Internal Affairs of the Russian Federation[144]
National Health Service (England)[108][112][145]
NHS Scotland[108][112]
Nissan Motor Manufacturing UK[145]
O2, Germany[146][147]
Petrobrás[148]
PetroChina[115][129]
Portugal Telecom[149]
Pulse FM[150]
Q-Park[151]
Renault[152]
Russian Railways[153]
Sandvik[133]
Justice Court of São Paulo[148]
Sberbank[154]
Shandong University[131]
State Governments of India
Government of Gujarat[155]
Government of Kerala[155]
Government of Maharashtra[156]
Government of West Bengal[155]
Suzhou Vehicle Administration[131]
Sun Yat-sen University, China[133]
Telefónica, Spain[157]
Yettel Hungary, Hungary[158]
Telkom (South Africa)[159]
Timrå Municipality, Sweden[160]
TSMC, Taiwan[161]
Universitas Jember, Indonesia[162]
University of Milano-Bicocca, Italy[163]
University of Montreal, Canada[164]
Vivo, Brazil[148]
Reactions
A number of experts highlighted the NSA's non-disclosure of the underlying vulnerability, and their loss of control over the EternalBlue attack tool that exploited it. Edward Snowden said that if the NSA had "privately disclosed the flaw used to attack hospitals when they found it, not when they lost it, the attack may not have happened".[109] British cybersecurity expert Graham Cluley also sees "some culpability on the part of the U.S. intelligence services". According to him and others "they could have done something ages ago to get this problem fixed, and they didn't do it". He also said that despite obvious uses for such tools to spy on people of interest, they have a duty to protect their countries' citizens.[165] Others have also commented that this attack shows that the practice of intelligence agencies to stockpile exploits for offensive purposes rather than disclosing them for defensive purposes may be problematic.[119] Microsoft president and chief legal officer Brad Smith wrote, "Repeatedly, exploits in the hands of governments have leaked into the public domain and caused widespread damage. An equivalent scenario with conventional weapons would be the U.S. military having some of its Tomahawk missiles stolen."[166][167][168] Russian President Vladimir Putin placed the responsibility of the attack on U.S. intelligence services for having created EternalBlue.[154]

On 17 May 2017, United States bipartisan lawmakers introduced the PATCH Act[169] that aims to have exploits reviewed by an independent board to "balance the need to disclose vulnerabilities with other national security interests while increasing transparency and accountability to maintain public trust in the process".[170]

On 15 June 2017, the United States Congress was to hold a hearing on the attack.[171] Two subpanels of the House Science Committee were to hear the testimonies from various individuals working in the government and non-governmental sector about how the U.S. can improve its protection mechanisms for its systems against similar attacks in the future.[171]

Marcus Hutchins, a cybersecurity researcher, working in loose collaboration with UK's National Cyber Security Centre,[172][173] researched the malware and discovered a "kill switch".[57] Later globally dispersed security researchers collaborated online to develop open-source tools[174][175] that allow for decryption without payment under some circumstances.[176] Snowden states that when "NSA-enabled ransomware eats the Internet, help comes from researchers, not spy agencies" and asks why this is the case.[173][177][178]

Adam Segal, director of the digital and cyberspace policy program at the Council on Foreign Relations, stated that "the patching and updating systems are broken, basically, in the private sector and in government agencies".[119] In addition, Segal said that governments' apparent inability to secure vulnerabilities "opens a lot of questions about backdoors and access to encryption that the government argues it needs from the private sector for security".[119] Arne Schönbohm, president of Germany's Federal Office for Information Security (BSI), stated that "the current attacks show how vulnerable our digital society is. It's a wake-up call for companies to finally take IT security [seriously]".[179]

United Kingdom
The effects of the attack also had political implications; in the United Kingdom, the impact on the National Health Service quickly became political, with claims that the effects were exacerbated by government underfunding of the NHS; in particular, the NHS ceased its paid Custom Support arrangement to continue receiving support for unsupported Microsoft software used within the organization, including Windows XP.[180] Home Secretary Amber Rudd refused to say whether patient data had been backed up, and Shadow Health Secretary Jon Ashworth accused Health Secretary Jeremy Hunt of refusing to act on a critical note from Microsoft, the National Cyber Security Centre (NCSC) and the National Crime Agency that had been received two months previously.[181]

Others argued that hardware and software vendors often fail to account for future security flaws, selling systems that—due to their technical design and market incentives—eventually won't be able to properly receive and apply patches.[182]

The NHS denied that it was still using XP, claiming only 4.7% of devices within the organization ran Windows XP.[45][183] The cost of the attack to the NHS was estimated as £92 million in disruption to services and IT upgrades.[184]

After the attack, NHS Digital refused to finance the estimated £1 billion to meet the Cyber Essentials Plus standard, an information security certification organized by the UK NCSC, saying this would not constitute "value for money", and that it had invested over £60 million and planned "to spend a further £150 [million] over the next two years" to address key cyber security weaknesses.[185]

See also
BlueKeep
Computer security § Medical systems
Conficker
CryptoLocker
Cyber self-defense
Cyberweapon § Control
Health Service Executive cyberattack
International Multilateral Partnership Against Cyber Threats
List of NSA controversies
Proactive cyber defence § Measures
Security engineering
Software versioning
SQL Slammer
Timeline of computer viruses and worms
Vault 7
Windows Update
2016 Dyn cyberattack
2017 Petya cyberattack
2026 Belgian hospital cyberattack
References
 "Ransomware attack still looms in Australia as Government warns WannaCry threat not over". Australian Broadcasting Corporation. 14 May 2017. Archived from the original on 15 May 2017. Retrieved 15 May 2017.
 Cameron, Dell (13 May 2017). "Today's Massive Ransomware Attack Was Mostly Preventable; Here's How To Avoid It". Gizmodo. Archived from the original on 9 April 2019. Retrieved 13 May 2017.
 "Shadow Brokers threaten to release Windows 10 hacking tools". The Express Tribune. 31 May 2017. Archived from the original on 10 July 2017. Retrieved 31 May 2017.
 "Two years after WannaCry, a million computers remain at risk". TechCrunch. 12 May 2019. Archived from the original on 4 June 2021. Retrieved 16 January 2021.
 "What is the domain name that stopped WannaCry?". 15 May 2017. Archived from the original on 21 January 2023. Retrieved 13 July 2021.
 Chappell, Bill; Neuman, Scott (19 December 2017). "U.S. Says North Korea 'Directly Responsible' For WannaCry Ransomware Attack". NPR. Archived from the original on 2 December 2022. Retrieved 2 December 2022.
 "Cyber-attack: US and UK blame North Korea for WannaCry". BBC News. 19 December 2017. Archived from the original on 8 February 2021. Retrieved 18 February 2021.
 "iPhone Chipmaker Blames WannaCry Variant for Plant Closures". Bloomberg.com. Archived from the original on 19 May 2023. Retrieved 11 February 2026.
 "TSMC Details Impact of Computer Virus Incident". Taiwan Semiconductor Manufacturing Company Limited. 5 August 2018. Retrieved 11 February 2026.
 MSRC Team (13 May 2017). "Customer Guidance for WannaCrypt attacks". Microsoft. Archived from the original on 21 May 2017. Retrieved 13 May 2017.
 Jakub Kroustek (12 May 2017). "Avast reports on WanaCrypt0r 2.0 ransomware that infected NHS and Telefonica". Avast Security News. Avast Software, Inc. Archived from the original on 5 May 2019. Retrieved 14 May 2017.
 Fox-Brewster, Thomas. "An NSA Cyber Weapon Might Be Behind A Massive Global Ransomware Outbreak". Forbes. Archived from the original on 28 June 2018. Retrieved 12 May 2017.
 Woollaston, Victoria. "Wanna Decryptor: what is the 'atom bomb of ransomware' behind the NHS attack?". WIRED UK. Archived from the original on 17 March 2018. Retrieved 13 May 2017.
 "Player 3 Has Entered the Game: Say Hello to 'WannaCry'". blog.talosintelligence.com. 12 May 2017. Archived from the original on 4 June 2021. Retrieved 16 May 2017.
 Shields, Nathan P. (8 June 2018). "Criminal Complaint". United States Department of Justice. Archived from the original on 6 September 2018. Retrieved 6 September 2018.
 "NHS cyber attack: Edward Snowden says NSA should have prevented cyber attack". The Independent. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 Graham, Chris (13 May 2017). "NHS cyber attack: Everything you need to know about 'biggest ransomware' offensive in history". The Daily Telegraph. Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 "NSA-leaking Shadow Brokers just dumped its most damaging release yet". Ars Technica. Archived from the original on 13 May 2017. Retrieved 15 April 2017.
 Goodin, Dan. "10,000 Windows computers may be infected by advanced NSA backdoor". Ars Technica. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 Goodin, Dan. "NSA backdoor detected on >55,000 Windows boxes can now be remotely removed". Ars Technica. Archived from the original on 10 July 2017. Retrieved 14 May 2017.
 Broersma, Matthew. "NSA Malware 'Infects Nearly 200,000 Systems'". Silicon. Archived from the original on 6 May 2017. Retrieved 14 May 2017.
 Cameron, Dell (13 May 2017). "Today's Massive Ransomware Attack Was Mostly Preventable; Here's How To Avoid It". Gizmodo Australia. Archived from the original on 9 April 2019. Retrieved 15 May 2017.
 "How One Simple Trick Just Put Out That Huge Ransomware Fire". Forbes. 24 April 2017. Archived from the original on 4 June 2021. Retrieved 15 May 2017.
 "Enterprise Ransomware" (PDF). August 2019. Archived (PDF) from the original on 20 September 2021. Retrieved 27 February 2022.
 "Russian-linked cyber gang blamed for NHS computer hack using bug stolen from US spy agency". The Telegraph. Archived from the original on 12 May 2017. Retrieved 12 May 2017.
 "What you need to know about the WannaCry Ransomware". Symantec Security Response. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 Bilefsky, Dan; Perlroth, Nicole (12 May 2017). "Hackers Hit Dozens of Countries Exploiting Stolen N.S.A. Tool". The New York Times. ISSN 0362-4331. Archived from the original on 12 May 2017. Retrieved 12 May 2017.
 Clark, Zammis (13 May 2017). "The worm that spreads WanaCrypt0r". Malwarebytes Labs. malwarebytes.com. Archived from the original on 17 May 2017. Retrieved 13 May 2017.
 Samani, Raj (12 May 2017). "An Analysis of the WANNACRY Ransomware outbreak". McAfee. Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 Thomas, Andrea; Grove, Thomas; and Gross, Jenny (13 May 2017). "More Cyberattack Victims Emerge as Agencies Search for Clues". The Wall Street Journal. ISSN 0099-9660. Archived from the original on 13 May 2017. Retrieved 14 May 2017.
 Collins, Keith (12 May 2017). "Watch as these bitcoin wallets receive ransomware payments from the global cyberattack". Quartz. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 "MS17-010 (SMB RCE) Metasploit Scanner Detection Module". @zerosum0x0. 18 April 2017. Archived from the original on 25 September 2017. Retrieved 18 April 2017.
 "DoublePulsar Initial SMB Backdoor Ring 0 Shellcode Analysis". @zerosum0x0. 21 April 2017. Archived from the original on 12 August 2017. Retrieved 21 April 2017.
 "WannaCrypt ransomware worm targets out-of-date systems". Microsoft Security. Microsoft. 12 May 2017. Archived from the original on 17 June 2025. Retrieved 13 October 2025.
 Brenner, Bill (16 May 2017). "WannaCry: the ransomware worm that didn't arrive on a phishing hook". Naked Security. Sophos. Archived from the original on 11 July 2017. Retrieved 18 May 2017.
 Newman, Lily Hay (12 May 2017). "The Ransomware Meltdown Experts Warned About Is Here". Wired. Archived from the original on 19 May 2017. Retrieved 13 May 2017.
 Yuzifovich, Yuriy. "WannaCry: views from the DNS frontline". Security and Data Science. nominum. Archived from the original on 21 May 2017. Retrieved 18 May 2017.
 Goodin, Dan. "An NSA-derived ransomware worm is shutting down computers worldwide". Ars Technica. Archived from the original on 12 May 2017. Retrieved 14 May 2017.
 "Cyber-attack: Europol says it was unprecedented in scale". BBC News. 13 May 2017. Archived from the original on 14 May 2017. Retrieved 13 May 2017.
 "'Unprecedented' cyberattack hits 200,000 in at least 150 countries, and the threat is escalating". CNBC. 14 May 2017. Archived from the original on 15 May 2017. Retrieved 16 May 2017.
 "WannaCry Ransomware Attack Hits Victims With Microsoft SMB Exploit". eWeek. Retrieved 13 May 2017.
 "NHS Hospitals Are Running Thousands of Computers on Unsupported Windows XP". Motherboard. 29 September 2016. Archived from the original on 18 May 2017. Retrieved 13 May 2017.
 "Microsoft issues 'highly unusual' Windows XP patch to prevent massive ransomware attack". The Verge. Vox Media. 13 May 2017. Archived from the original on 14 May 2017. Retrieved 13 May 2017.
 Brandom, Russell (19 May 2017). "Almost all WannaCry victims were running Windows 7". The Verge. Vox Media. Archived from the original on 16 November 2020. Retrieved 10 December 2020.
 Brandom, Russell (30 May 2017). "Windows XP computers were mostly immune to WannaCry". The Verge. Vox Media. Archived from the original on 11 February 2021. Retrieved 10 December 2020.
 "WannaCry: Two Weeks and 16 Million Averted May 2017". 30 May 2017. Archived from the original on 30 May 2017.
 "Παγκόσμιος τρόμος: Πάνω από 100 χώρες "χτύπησε" ο WannaCry που ζητάει λύτρα!". newsit.gr. 13 May 2017. Archived from the original on 16 November 2019. Retrieved 16 November 2019.
 Reynolds, Matt (17 May 2017). "Ransomware attack hits 200,000 computers across the globe". New Scientist. Archived from the original on 19 April 2019. Retrieved 10 December 2020.
 Baraniuk, Chris (15 May 2017). "Should you pay the WannaCry ransom?". BBC News. Archived from the original on 29 November 2020. Retrieved 10 December 2020.
 Palmer, Danny (22 May 2017). "Ransomware: WannaCry was basic, next time could be much worse". ZDNet. Archived from the original on 29 November 2020. Retrieved 10 December 2020.
 Collins, Keith (13 May 2017). "Watch as these bitcoin wallets receive ransomware payments from the ongoing global cyberattack". Quartz. Archived from the original on 4 June 2021. Retrieved 10 December 2020.
 Thompson, Iain (16 May 2017). "While Microsoft griped about NSA exploit stockpiles, it stockpiled patches: Friday's WinXP fix was built in February". The Register. Archived from the original on 22 December 2017. Retrieved 19 December 2017.
 "Microsoft Patch Zero-Click Windows Vulnerability". Cyber Kendra. 6 March 2025. Retrieved 15 October 2025.
 Hern, Alex (14 June 2017). "WannaCry attacks prompt Microsoft to release Windows updates for older versions". The Guardian. ISSN 0261-3077. Archived from the original on 14 June 2017. Retrieved 14 June 2017.
 "Microsoft rushes out patch for Windows XP to prevent another WannaCry attack via a Shadow Brokers release". Computing.com. 14 June 2017. ISSN 0261-3077. Archived from the original on 14 June 2017. Retrieved 14 June 2017.
 "'Just doing my bit': The 22yo who blocked the WannaCry cyberattack". ABC News. 16 May 2017. Archived from the original on 17 May 2017. Retrieved 17 May 2017.
 MalwareTech (13 May 2017). "How to Accidentally Stop a Global Cyber Attacks". Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 Bodkin, Henry; Henderson, Barney; Donnelly, Laura; Mendick, Robert; Farmer, Ben; and Graham, Chris (12 May 2017). "Government under pressure after NHS crippled in global cyber attack as weekend of chaos looms". The Telegraph. Archived from the original on 27 March 2018. Retrieved 5 April 2018.
 Thomson, Iain (13 May 2017). "74 countries hit by NSA-powered WannaCrypt ransomware backdoor: Emergency fixes emitted by Microsoft for WinXP+". The Register. Archived from the original on 13 May 2017. Retrieved 14 May 2017.
 Khomami, Nadia and Solon, Olivia (13 May 2017). "'Accidental hero' halts ransomware attack and warns: this is not over". The Guardian. Archived from the original on 23 May 2019. Retrieved 13 May 2017.
 Newman, Lily Hay. "How an Accidental 'Kill Switch' Slowed Friday's Massive Ransomware Attack". Wired Security. Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 Solon, Olivia (13 May 2017). "'Accidental hero' finds kill switch to stop spread of ransomware cyber-attack". The Guardian. London. Archived from the original on 23 May 2019. Retrieved 13 May 2017.
 Foxx, Chris (13 May 2017). "Global cyber-attack: Security blogger halts ransomware 'by accident'". BBC. Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 Kan, Micael (12 May 2017). "A 'kill switch' is slowing the spread of WannaCry ransomware". PC World. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 "How an Accidental 'Kill Switch' Slowed Friday's Massive Ransomware Attack". 12 May 2017. Archived from the original on 22 December 2017. Retrieved 19 December 2017.
 Wong, Joon Ian (15 May 2017). "Just two domain names now stand between the world and global ransomware chaos". Quartz. Archived from the original on 19 March 2018. Retrieved 25 March 2018.
 "The Hours of WannaCry". 17 May 2017. Archived from the original on 26 March 2018. Retrieved 25 March 2018.
 "WannaCry – New Kill-Switch, New Sinkhole". Check Point Software Blog. 15 May 2017. Archived from the original on 11 April 2019. Retrieved 11 April 2019.
 Khandelwal, Swati. "It's Not Over, WannaCry 2.0 Ransomware Just Arrived With No 'Kill-Switch'". The Hacker News. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 Shieber, Jonathan. "Companies, governments brace for a second round of cyberattacks in WannaCry's wake". TechCrunch. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 Chan, Sewell; Scott, Mark (14 May 2017). "Cyberattack's Impact Could Worsen in 'Second Wave' of Ransomware". The New York Times. Archived from the original on 14 April 2021. Retrieved 14 May 2017.
 "Warning: Blockbuster 'WannaCry' malware could just be getting started". NBC News. Archived from the original on 13 April 2021. Retrieved 14 May 2017.
 Greenberg, Andy (19 May 2017). "Botnets Are Trying to Reignite the Ransomware Outbreak". WIRED. Archived from the original on 22 May 2017. Retrieved 22 May 2017.
 Gibbs, Samuel (22 May 2017). "WannaCry hackers still trying to revive attack says accidental hero". The Guardian. Archived from the original on 4 March 2020. Retrieved 22 May 2017.
 "Protection from Ransomware like WannaCry". College of Engineering. Boston University. Archived from the original on 31 May 2017. Retrieved 19 May 2017.
 Kolodenker, Eugene (16 May 2017). "PayBreak able to defeat WannaCry/WannaCryptor ransomware". Information Security Research & Education. Bentham's Gaze. University College London. Archived from the original on 16 May 2017. Retrieved 19 May 2017.
 Suiche, Matt (19 May 2017). "WannaCry — Decrypting files with WanaKiwi + Demos". Comae Technologies. Archived from the original on 8 August 2019. Retrieved 11 February 2019.
 "Windows XP hit by WannaCry ransomware? This tool could decrypt your infected files". ZDNet. Archived from the original on 23 May 2017. Retrieved 30 May 2017.
 "Windows XP PCs infected by WannaCry can be decrypted without paying ransom". Ars Technica. 18 May 2017. Archived from the original on 31 May 2017. Retrieved 30 May 2017.
 Greenberg, Andy (18 May 2017). "A WannaCry flaw could help some windows XP users get files back". Wired. Archived from the original on 18 May 2017. Retrieved 18 May 2017.
 "More people infected by recent WCry worm can unlock PCs without paying ransom". Ars Technica. 19 May 2017. Archived from the original on 22 May 2017. Retrieved 30 May 2017.
 Volz, Dustin (17 May 2017). "Cyber attack eases, hacking group threatens to sell code". Reuters. Archived from the original on 21 May 2017. Retrieved 21 May 2017.
 Leyden, John (26 May 2017). "WannaCrypt ransomware note likely written by Google Translate-using Chinese speakers". The Register. Archived from the original on 26 May 2017. Retrieved 26 May 2017.
 Condra, Jon; Costello, John; Chu, Sherman (25 May 2017). "Linguistic Analysis of WannaCry Ransomware Messages Suggests Chinese-Speaking Authors". Flashpoint. Archived from the original on 27 May 2017. Flashpoint assesses with high confidence that the author(s) of WannaCry's ransomware notes are fluent in Chinese, as the language used is consistent with that of Southern China, Hong Kong, Taiwan, or Singapore. Flashpoint also assesses with high confidence that the author(s) are familiar with the English language, though not native. [...] Flashpoint assesses with moderate confidence that the Chinese ransom note served as the original source for the English version, which then generated machine translated versions of the other notes. The Chinese version contains content not in any of the others, though no other notes contain content not in the Chinese. The relative familiarity found in the Chinese text compared to the others suggests the authors were fluent in the language—perhaps comfortable enough to use the language to write the initial note.
 Greenberg, Andy (15 May 2017). "The Ransomware Outbreak Has a Possible Link to North Korea". Wired. Archived from the original on 23 March 2018. Retrieved 25 March 2018.
 "Google Researcher Finds Link Between WannaCry Attacks and North Korea". The Hacker News — Cyber Security and Hacking News Website. Archived from the original on 25 March 2018. Retrieved 25 March 2018.
 Mehta, Neel [@neelmehta] (15 May 2017). "9c7c7149387a1c79679a87dd1ba755bc @ 0x402560, 0x40F598 ac21c8ad899727137c4b94458d7aa8d8 @ 0x10004ba0, 0x10012AA4 #WannaCryptAttribution" (Tweet) – via Twitter.
 McMillan, Robert (16 May 2017). "Researchers Identify Clue Connecting Ransomware Assault to Group Tied to North Korea". The Wall Street Journal. Archived from the original on 23 March 2018. Retrieved 25 March 2018.
 Solong, Olivia (15 May 2017). "WannaCry ransomware has links to North Korea, cybersecurity experts say". The Guardian. Archived from the original on 16 May 2017. Retrieved 16 May 2017.
 Talmadge, Eric (19 May 2017). "Experts question North Korea role in WannaCry cyber attack". independent.ie. AP. Archived from the original on 23 May 2017. Retrieved 22 May 2017.
 Nakashima, Ellen. "The NSA has linked the WannaCry computer worm to North Korea". The Washington Post. Archived from the original on 4 June 2021. Retrieved 15 June 2017.
 Harley, Nicola (14 October 2017). "North Korea behind WannaCry attack which crippled the NHS after stealing US cyber weapons, Microsoft chief claims". The Telegraph. ISSN 0307-1235. Archived from the original on 14 October 2017. Retrieved 14 October 2017.
 Hern, Alex (26 October 2017). "NHS could have avoided WannaCry hack with basic IT security' says report". The Guardian. Archived from the original on 26 October 2017. Retrieved 26 October 2017.
 Nakashima, Ellen (18 December 2017). "U.S. declares North Korea carried out massive WannaCry cyberattack". The Washington Post. Archived from the original on 19 December 2017. Retrieved 18 December 2017.
 Bossert, Thomas P. (18 December 2017). "It's Official: North Korea Is Behind WannaCry". The Wall Street Journal. Archived from the original on 19 December 2017. Retrieved 18 December 2017.
 Uchill, Joe (19 December 2017). "WH: Kim Jong Un behind massive WannaCry malware attack". The Hill. Archived from the original on 22 December 2017. Retrieved 19 December 2017.
 "White House says WannaCry attack was carried out by North Korea". CBS News. 19 December 2017. Archived from the original on 22 December 2017. Retrieved 19 December 2017.
 Hern, Alex; McCurry, Justin (19 December 2017). "UK and US blame WannaCry cyber-attack on North Korea". The Guardian. Archived from the original on 19 December 2017. Retrieved 19 December 2017.
 "North Korea says linking cyber attacks to Pyongyang is 'ridiculous'". Reuters. 19 May 2017. Archived from the original on 20 May 2017. Retrieved 21 May 2017.
 "Experts Question North Korea Role in WannaCry Cyberattack". The New York Times. 19 May 2017. Retrieved 21 May 2017.
 Sanger, David; Benner, Katie; Goldman, Adam (6 September 2018). "North Korean Spy to Be Charged in Sony Pictures Hacking". The New York Times. Archived from the original on 6 September 2018. Retrieved 6 September 2018.
 Talley, Ian; Volz, Dustin (16 September 2019). "U.S. Targets North Korean Hacking as National-Security Threat". msn. Archived from the original on 20 September 2019. Retrieved 16 September 2019.
 "Cyber-attack: Europol says it was unprecedented in scale". BBC. 13 May 2017. Archived from the original on 14 May 2017. Retrieved 22 June 2018.
 Jones, Sam (14 May 2017). "Global alert to prepare for fresh cyber attacks". Financial Times.
 Millar, Sheila A.; Marshall, Tracy P.; Cardon, Nathan A. (22 May 2017). "WannaCry: Are Your Security Tools Up to Date?". The National Law Review. Keller and Heckman LLP. Archived from the original on 4 August 2017. Retrieved 9 July 2017.
 "Global cyberattack strikes dozens of countries, cripples U.K. hospitals". CBS News. 12 May 2017. Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 Ungoed-Thomas, Jon; Henry, Robin; Gadher, Dipesh (14 May 2017). "Cyber-attack guides promoted on YouTube". The Sunday Times. Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 "NHS cyber-attack: GPs and hospitals hit by ransomware". BBC News. 12 May 2017. Archived from the original on 12 May 2017. Retrieved 12 May 2017.
 Wong, Julia Carrie; Solon, Olivia (12 May 2017). "Massive ransomware cyber-attack hits 74 countries around the world". The Guardian. London. Archived from the original on 21 May 2017. Retrieved 12 May 2017.
 Smyth, Chris (18 April 2018). "Every hospital tested for cybersecurity has failed". The Times. ISSN 0140-0460. Archived from the original on 18 April 2018. Retrieved 18 April 2018.
 "Cyber-attack on the NHS" (PDF). Archived (PDF) from the original on 21 April 2018. Retrieved 20 April 2018.
 Marsh, Sarah (12 May 2017). "The NHS trusts hit by malware – full list". The Guardian. London. Archived from the original on 15 May 2017. Retrieved 12 May 2017.
 Sharman, Jon (13 May 2017). "Cyber-attack that crippled NHS systems hits Nissan car factory in Sunderland and Renault in France". The Independent. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 Rosemain, Mathieu; Le Guernigou, Yann; Davey, James (13 May 2017). "Renault stops production at several plants after ransomware cyber attack as Nissan also hacked". Daily Mirror. Archived from the original on 15 May 2017. Retrieved 13 May 2017.
 Larson, Selena (12 May 2017). "Massive ransomware attack hits 99 countries". CNN. Archived from the original on 12 May 2017. Retrieved 12 May 2017.
 "The WannaCry ransomware attack has spread to 150 countries". The Verge. 14 May 2017. Archived from the original on 15 May 2017. Retrieved 16 May 2017.
 Hern, Alex; Gibbs, Samuel (12 May 2017). "What is 'WanaCrypt0r 2.0' ransomware and why is it attacking the NHS?". The Guardian. London. ISSN 0261-3077. Archived from the original on 12 May 2017. Retrieved 12 May 2017.
 "Lucky break slows global cyberattack; what's coming could be worse". Chicago Tribune. 14 May 2017. Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 Helmore, Edward (13 May 2017). "Ransomware attack reveals breakdown in US intelligence protocols, expert says". The Guardian. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 "The Latest: Researcher who helped halt cyberattack applauded". Star Tribune. Archived from the original on 16 May 2017. Retrieved 14 May 2017.
 "Global 'WannaCry' ransomware cyberattack seeks cash for data". Washington Post. Archived from the original on 16 May 2017. Retrieved 16 May 2017.
 ""WannaCry" ransomware attack losses could reach $4 billion". Archived from the original on 14 June 2017. Retrieved 14 June 2017.
 "Andhra police computers hit by cyberattack". The Times of India. 13 May 2017. Archived from the original on 14 May 2017. Retrieved 13 May 2017.
 ""Χάκαραν" και το ΑΠΘ στην παγκόσμια κυβερνοεπίθεση!". Proto Thema (in Greek). 13 May 2017. Archived from the original on 17 May 2017. Retrieved 18 May 2017.
 "Θεσσαλονίκη: Στόχος της παγκόσμιας κυβερνοεπίθεσης το Αριστοτέλειο – Συναγερμός για τον ισχυρό ιό!". NewsIT (in Greek). 13 May 2017. Archived from the original on 1 September 2020. Retrieved 28 September 2020.
 "Atacul cibernetic global a afectat și Uzina Dacia de la Mioveni. Renault a anunțat că a oprit producția și în Franța". Pro TV (in Romanian). 13 May 2017. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 "Boeing production plant hit with WannaCry ransomware attack". theverge.com. 28 March 2018. Archived from the original on 29 March 2018. Retrieved 29 March 2018.
 "Hackers demand $54K in Cambrian College ransomware attack". CBC.ca. Archived from the original on 10 May 2017. Retrieved 16 May 2017.
 Mimi Lau (14 May 2017). "Chinese police and petrol stations hit by ransomware attack". South China Morning Post. Archived from the original on 15 May 2017. Retrieved 15 May 2017.
 "Korean gov't computers safe from WannaCry attack". The Korea Herald. Archived from the original on 15 May 2017. Retrieved 15 May 2017.
 "一夜之间 勒索病毒"永恒之蓝"席卷 国内近3万机构被攻陷 全球 超十万台电脑"中毒"江苏等十省市受害最严重". Archived from the original on 19 May 2017. Retrieved 27 May 2017.
 "Weltweite Cyberattacke trifft Computer der Deutschen Bahn". Frankfurter Allgemeine Zeitung (in German). 13 May 2017. Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 "Global cyber attack: A look at some prominent victims" (in Spanish). elperiodico.com. 13 May 2017. Archived from the original on 20 May 2017. Retrieved 14 May 2017.
 "Hackerský útok zasiahol aj Fakultnú nemocnicu v Nitre". etrend.sk (in Slovak). 15 May 2017. Archived from the original on 16 May 2017. Retrieved 15 May 2017.
 "What is Wannacry and how can it be stopped?". Financial Times. 12 May 2017. Archived from the original on 21 May 2017. Retrieved 13 May 2017.
 "เซิร์ฟเวอร์เกม Blade & Soul ของ Garena ประเทศไทยถูก WannaCrypt โจมตี" (in Thai). blognone.com. 13 May 2017. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 "日立、社内システムの一部に障害 サイバー攻撃の影響か". 日本経済新聞 (in Japanese). 15 May 2017. Archived from the original on 16 May 2017. Retrieved 21 June 2017.
 "Honda halts Japan car plant after WannaCry virus hits computer network". Reuters. 21 June 2017. Archived from the original on 21 June 2017. Retrieved 21 June 2017.
 "Instituto Nacional de Salud, entre víctimas de ciberataque mundial". El Tiempo (in Spanish). 13 May 2017. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 "Ontario health ministry on high alert amid global cyberattack". Toronto Star. 13 May 2017. Archived from the original on 4 June 2021. Retrieved 14 May 2017.
 "Laks second Dutch victim of WannaCry". Nu.nl. 19 May 2017. Archived from the original on 19 May 2017. Retrieved 20 May 2017.
 "LATAM Airlines también está alerta por ataque informático". Fayerwayer. 12 May 2017. Archived from the original on 12 May 2017. Retrieved 13 May 2017.
 "Massive cyber attack creates chaos around the world". news.com.au. 12 May 2017. Archived from the original on 19 May 2017. Retrieved 13 May 2017.
 "Researcher 'accidentally' stops spread of unprecedented global cyberattack". ABC News. Archived from the original on 14 May 2017. Retrieved 13 May 2017.
 "Cyber-attack that crippled NHS systems hits Nissan car factory in Sunderland and Renault in France". The Independent. 13 May 2017. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 "Nach Attacke mit Trojaner WannaCry: Kundensystem bei O2 ausgefallen" (in German). FOCUS Online. Archived from the original on 23 May 2017. Retrieved 20 May 2017.
 "Erhebliche Störungen – WannaCry: Kundendienst von O2 ausgefallen – HAZ – Hannoversche Allgemeine" (in German). Hannoversche Allgemeine Zeitung. Archived from the original on 19 May 2017. Retrieved 20 May 2017.
 "WannaCry no Brasil e no mundo". O Povo (in Portuguese). 13 May 2017. Archived from the original on 21 May 2017. Retrieved 13 May 2017.
 "PT Portugal alvo de ataque informático internacional". Observador (in Portuguese). 12 May 2017. Archived from the original on 12 May 2017. Retrieved 13 May 2017.
 "Ransomware infects narrowcast radio station". RadioInfo. 15 May 2017. Archived from the original on 1 October 2017. Retrieved 30 September 2017.
 "Parkeerbedrijf Q-Park getroffen door ransomware-aanval". Nu.nl (in Dutch). 13 May 2017. Retrieved 14 May 2017.
 "France's Renault hit in worldwide 'ransomware' cyber attack" (in Spanish). France 24. 13 May 2017. Archived from the original on 21 May 2017. Retrieved 13 May 2017.
 "Компьютеры РЖД подверглись хакерской атаке и заражены вирусом". Радио Свобода. Radio Free Europe/Radio Liberty. 13 May 2017. Archived from the original on 16 May 2017. Retrieved 13 May 2017.
 Vidal Liy, Macarena (15 May 2017). "Putin culpa a los servicios secretos de EE UU por el virus 'WannaCry' que desencadenó el ciberataque mundial". El País (in Spanish). Archived from the original on 16 May 2017. Retrieved 16 May 2017.
 "Ransomware WannaCry Surfaces In Kerala, Bengal: 10 Facts". New Delhi Television Limited (NDTV). Archived from the original on 16 May 2017. Retrieved 15 May 2017.
 Sanjana Nambiar (16 May 2017). "Hit by WannaCry ransomware, civic body in Mumbai suburb to take 3 more days to fix computers". Hindustan Times. Archived from the original on 16 May 2017. Retrieved 17 May 2017.
 "Un ataque informático masivo con 'ransomware' afecta a medio mundo" (in Spanish). elperiodico.com. 12 May 2017. Archived from the original on 12 May 2017. Retrieved 13 May 2017.
 Balogh, Csaba (12 May 2017). "Ideért a baj: Magyarországra is elért az óriási kibertámadás". HVG (in Hungarian). Archived from the original on 13 May 2017. Retrieved 13 May 2017.
 "Telkom systems crippled by WannaCry ransomware". MyBroadband. 21 May 2017. Archived from the original on 29 August 2018. Retrieved 21 May 2017.
 "Timrå kommun drabbat av utpressningsattack" (in Swedish). Sveriges Television. 13 May 2017. Archived from the original on 15 May 2017. Retrieved 15 May 2017.
 Kirk, Jeremy. "WannaCry Outbreak Hits Chipmaker, Could Cost $170 Million". Information Security Media Group, Corp. Archived from the original on 10 August 2018. Retrieved 10 August 2018. Taiwan Semiconductor Manufacturing Co., the world's largest chip manufacturer, says a WannaCry infection hit unpatched Windows 7 systems in its fabrication facilities, leaving multiple factories crippled.
 "Virus Ransomware Wannacry Serang Perpustakaan Universitas Jember". Tempo (in Indonesian). 16 May 2017. Archived from the original on 16 May 2017. Retrieved 17 May 2017.
 "Il virus Wannacry arrivato a Milano: colpiti computer dell'università Bicocca". la Repubblica (in Italian). 12 May 2017. Archived from the original on 17 May 2017. Retrieved 13 May 2017.
 "Some University of Montreal computers hit with WannaCry virus". The Globe and Mail. 16 May 2017. Archived from the original on 17 May 2017. Retrieved 16 May 2017.
 Hui, Sylvia; Burnett, Sara; and Breed, Allen G. (14 May 2017). "Lucky break slows global cyberattack; what's coming could be worse". Chicago Tribune. Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 "Ransomware attack 'like having a Tomahawk missile stolen', says Microsoft boss". The Guardian. 14 May 2017. Archived from the original on 7 April 2022. Retrieved 15 May 2017.
 Storm, Darlene (15 May 2017). "WikiLeaks posts user guides for CIA malware implants Assassin and AfterMidnight". Computerworld. Archived from the original on 17 May 2017. Retrieved 17 May 2017.
 Smith, Brad (14 May 2017). "The need for urgent collective action to keep people safe online". Microsoft. Archived from the original on 16 May 2017. Retrieved 14 May 2017.
 "Patch Act bill before Congress". Archived from the original on 18 May 2017. Retrieved 23 May 2017.
 Whittaker, Zack. "Congress introduces bill to stop US from stockpiling cyber-weapons". ZDNet. Archived from the original on 22 May 2017. Retrieved 23 May 2017.
 Chalfant, Morgan (12 June 2017). "Lawmakers to hold hearing on 'Wanna Cry' ransomware attack". TheHill. Archived from the original on 15 June 2017. Retrieved 14 June 2017.
 "Finding the kill switch to stop the spread of ransomware – NCSC Site". ncsc.gov.uk. Archived from the original on 23 March 2019. Retrieved 21 May 2017.
 "Sky Views: Stop the cyberattack blame game". Sky News. Archived from the original on 19 May 2017. Retrieved 21 May 2017.
 "gentilkiwi/wanakiwi". GitHub. Archived from the original on 20 May 2017. Retrieved 20 May 2017.
 "aguinet/wannakey". GitHub. Archived from the original on 20 May 2017. Retrieved 20 May 2017.
 Auchard, Eric (19 May 2017). "French researchers find way to unlock WannaCry without ransom". Reuters. Archived from the original on 19 May 2017. Retrieved 19 May 2017.
 Snowden, Edward [@Snowden] (13 May 2017). "When @NSAGov-enabled ransomware eats the internet, help comes from researchers, not spy agencies. Amazing story" (Tweet). Retrieved 20 May 2017 – via Twitter.
 Snowden, Edward [@Snowden] (13 May 2017). "Pause a moment to consider why we're left with researchers, not governments, trying to counter the @NSAGov-enabled ransomware mess. Hint" (Tweet). Retrieved 20 May 2017 – via Twitter.
 "WannaCry: BSI ruft Betroffene auf, Infektionen zu melden" (in German). heise online. 13 May 2017. Archived from the original on 8 April 2022. Retrieved 14 May 2017.
 "The ransomware attack is all about the insufficient funding of the NHS". The Guardian. 13 May 2017. Archived from the original on 14 May 2017. Retrieved 14 May 2017.
 "Jeremy Hunt 'ignored warning signs' before cyber-attack hit NHS". The Guardian. 13 May 2017. Archived from the original on 13 May 2017. Retrieved 14 May 2017.
 Larson, Selena (17 May 2017). "Why WannaCry ransomware took down so many businesses". CNN Money. CNN. Archived from the original on 21 May 2017. Retrieved 22 May 2017.
 "UPDATED Statement on reported NHS cyber-attack (13 May)". National Health Service. Archived from the original on 13 May 2017. Retrieved 30 May 2017.
 "Cyber-attack cost NHS £92m – DHSC". Health Service Journal. 11 October 2018. Archived from the original on 13 November 2018. Retrieved 13 November 2018.
 "Health chiefs refuse to foot £1bn bill to improve NHS cyber security". Building Better Healthcare. 15 October 2018. Archived from the original on 27 November 2018. Retrieved 27 November 2018.
External links
Wikimedia Commons logo
Wikimedia Commons has media related to WannaCry ransomware attack.
Ransom:Win32/WannaCrypt at Microsoft Malware Protection Center
@actual_ransom on X, a Twitterbot tracking the ransom payments
vte
Hacking in the 2010s
← 2000s	
Timeline of security hacking incidentsTimeline of computer viruses and worms
2020s → 
Major incidents	
2010	
Operation Aurora (publication of 2009 events)Australian cyberattacksOperation Olympic GamesOperation ShadowNetOperation Payback
2011	
Canadian governmentDigiNotarDNSChangerHBGary FederalOperation AntiSecPlayStation network outageRSA SecurID compromise
2012	
LinkedIn hackStratfor email leakOperation High Roller
2013	
South Korea cyberattackSnapchat hackCyberterrorism attack of June 252013 Yahoo! data breachSingapore cyberattacks
2014	
Anthem medical data breachOperation Tovar2014 celebrity nude photo leak2014 JPMorgan Chase data breach2014 Sony Pictures hackRussian hacker password theft2014 Yahoo! data breach
2015	
Office of Personnel Management data breachHackingTeamAshley Madison data breachTalkTalk data breachVTech data breachUkrainian Power Grid CyberattackSWIFT banking hack
2016	
Bangladesh Bank robberyHollywood Presbyterian Medical Center ransomware incidentCommission on Elections data breachDemocratic National Committee cyber attacksVietnam Airport HacksDCCC cyber attacksIndian Bank data breachesSurkov leaksDyn cyberattackRussian interference in the 2016 U.S. elections2016 Bitfinex hack
2017	
SHAttered2017 Macron e-mail leaksWannaCry ransomware attackWestminster data breachPetya and NotPetya 2017 Ukraine ransomware attacksEquifax data breachDeloitte breachDisqus breach
2018	
TrusticoAtlanta cyberattackBritish Airways data breachSingHealth data breach
2019	
Sri Lanka cyberattackBaltimore ransomware attackBulgarian revenue agency hackWhatsApp snooping scandalJeff Bezos phone hacking incident
Hacktivism	
Anonymous associated eventsCyberBerkutGNAAGoatse SecurityLizard SquadLulzRaftLulzSecNew World HackersNullCrewOurMinePayPal 14RedHackTeamp0isonTDOUGNaziUkrainian Cyber Alliance
Groups	
AppinBangladesh Black Hat HackersBureau 121Charming KittenCozy BearDark BasinDarkMatterElfin TeamEquation GroupFancy BearGOSSIPGIRL (confederation)Guccifer 2.0Hacking TeamHelix KittenIranian Cyber ArmyIslamic State Hacking DivisionLazarus Group BlueNorOffAndArielLords of DharmarajaNSO GroupNumbered PandaPLA Unit 61398PLA Unit 61486PLATINUMPranknetRed ApolloRocket KittenStealth FalconSyrian Electronic ArmyTailored Access OperationsThe Shadow BrokersxDedicYemen Cyber Army
Individuals	
Ryan AckroydMustafa Al-BassamKim Anh VoGeorge HotzGucciferElliott GuntonJeremy HammondSam HocevarJunaid HussainMLTSabuTrack2TopiaryThe Jester
Major vulnerabilities
publicly disclosed	
Evercookie (2010)iSeeYou (2013)Heartbleed (2014)Shellshock (2014)POODLE (2014)Rootpipe (2014)Row hammer (2014)SS7 vulnerabilities (2014)WinShock (2014)JASBUG (2015)Stagefright (2015)DROWN (2016)Badlock (2016)Dirty COW (2016)Cloudbleed (2017)Broadcom Wi-Fi (2017)EternalBlue (2017)DoublePulsar (2017)Silent Bob is Silent (2017)KRACK (2017)ROCA vulnerability (2017)BlueBorne (2017)Meltdown (2018)Spectre (2018)EFAIL (2018)Exactis (2018)Speculative Store Bypass (2018)Lazy FP state restore (2018)TLBleed (2018)SigSpoof (2018)Foreshadow (2018)Dragonblood (2019)Microarchitectural Data Sampling (2019)BlueKeep (2019)Kr00k (2019)
Malware	
2010	
Bad RabbitBlack Energy 2BlackshadesCorefloodKelihosStuxnet
2011	
CitadelAndromedaAlureonDuquGameover ZeuSMetulji botnetStarsZeroAccess botnet
2012	
AlinaCarnaDexterDridexFBI MoneyPakFlameGrumMahdiRed OctoberShamoon
2013	
BlackPOSCryptoLockerDarkSeoulHavex
2014	
BrambulBlack Energy 3CarbanakCaretoDarkHotelDuqu 2.0EmotetFinFisherGameover ZeuSKronosRegin
2015	
CenterPOSHidden TearKasidetRombertikTeslaCryptProject Sauron
2016	
FastPOSHitlerIndustroyerJigsawKeRangerLockyNecursMEMZMiraiPegasusPetya and NotPetyaPhiladelphiaX-Agent
2017	
BrickerBotKirkLogicLockerRensenwareTritonWannaCryXafecopy
2018	
AnnabelleJoanapVPNFilter
2019	
R2D2Tiny BankerTitanium
Portals:
icon Law
icon Internet
Categories: 2017 in computingCyberattacksCybercrime2010s in hackingMay 2017 crimes in AsiaRansomwareComputer security exploitsWindows malware2010s internet outagesCyberwarfare in North KoreaCybercrime in India
This page was last edited on 27 March 2026, at 04:25 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policyAbout WikipediaDisclaimersContact WikipediaLegal & safety contactsCode of ConductDevelopersStatisticsCookie statementMobile view
Wikimedia Foundation
Powered by MediaWiki

    """

    # Simuliere eine Logik, die Hardware-IDs prüft
    for i in range(100):
        _temp_id = f"HDAUDIO\\FUNC_01&VEN_10EC&DEV_0256&SUBSYS_1028080C"
        _temp_status = "DRIVER_LOADED" if i % 2 == 0 else "DEVICE_READY"

    return report_header

def internal_buffer_cleanup():
    """Simuliert eine Speicherbereinigung."""
    junk_data = ["0x" + os.urandom(4).hex() for _ in range(500)]
    return True if len(junk_data) > 0 else False

