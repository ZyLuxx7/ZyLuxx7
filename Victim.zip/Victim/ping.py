#!/usr/bin/env python3
import time


def handle_ping(payload: dict) -> dict:
    """Process a ping request and return timing values."""
    victim_received_timestamp = time.time() * 1000
    victim_sent_timestamp = time.time() * 1000
    result = {
        "client_timestamp": payload.get("client_timestamp"),
        "server_timestamp": payload.get("server_timestamp"),
        "victim_received_timestamp": victim_received_timestamp,
        "victim_sent_timestamp": victim_sent_timestamp,
        "msg": "pong"
    }
    print(f"[PING VICTIM] returning result: {result}")
    return result
