import os
import string
import platform
import psutil
from pathlib import Path


def scan_available_drives() -> dict:
    """Scan all drive letters (Windows) and return information.
    The return value is a mapping drive_letter -> info dict.
    """
    drives = {}
    if platform.system() == "Windows":
        for drive_letter in string.ascii_uppercase:
            drive_path = f"{drive_letter}:\\"
            try:
                if os.path.exists(drive_path):
                    drive_type = "Local Drive"
                    if drive_letter.upper() != 'C':
                        # non-C drives are assumed removable
                        drive_type = "Removable"
                    try:
                        usage = psutil.disk_usage(drive_path)
                        drives[drive_letter] = {
                            "path": drive_path,
                            "type": drive_type,
                            "total": usage.total,
                            "used": usage.used,
                            "free": usage.free,
                            "percent": usage.percent,
                        }
                    except Exception:
                        # ignore permission errors or other failures
                        pass
            except Exception:
                pass
    return drives
