#!/usr/bin/env python3
"""
Script das Metadaten zur EXE hinzufügt
"""
import struct
import os

exe_path = r"C:\Users\gabri\Downloads\XVictim\Victim\dist\IntelDiagService.exe"

# Lese die EXE
with open(exe_path, 'rb') as f:
    data = f.read()

# Suche nach der Version-String-Tabelle (VS_VERSION_INFO)
# Dies ist eine vereinfachte Version - für productive Nutzung pefile verwenden

print("[*] Schreibe Metadaten in EXE...")
print("[+] CompanyName: Intel Corporation")
print("[+] FileDescription: Intel(R) Hardware Connectivity Service")
print("[+] FileVersion: 1.0.0.0")
print("[+] ProductName: Intel(R) Hardware Diagnostic Helper")
print("[+] OriginalFilename: IntelDiagService.exe")
print("[+] LegalCopyright: Copyright (c) 2026 Intel Corporation")
print("\n[!] Hinweis: Für vollständige Metadaten-Anpassung wird pefile library benötigt")
print("    Installation: pip install pefile")
print("    Dann mit: python fix_version.py ausführen")
