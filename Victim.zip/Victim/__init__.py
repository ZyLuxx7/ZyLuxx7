"""Victim package initializer.

This file makes the Victim directory a proper Python package so that
`from Victim import ...` works consistently (including in frozen/EXE builds).
"""

__all__ = []
