#!/usr/bin/env python3
"""
Audio Diagnostics für XVictim - Zeigt welche Audio-Devices verfügbar sind
"""

import pyaudio
import sys

def diagnose_audio():
    p = pyaudio.PyAudio()
    
    print("\n" + "="*70)
    print("🔊 XVictim Audio Diagnostics")
    print("="*70 + "\n")
    
    print(f"📊 Total Devices: {p.get_device_count()}\n")
    
    print("📋 Available Audio Devices:\n")
    
    loopback_found = False
    
    for i in range(p.get_device_count()):
        info = p.get_device_info_by_index(i)
        name = info.get("name", "Unknown")
        channels_in = info.get("maxInputChannels", 0)
        channels_out = info.get("maxOutputChannels", 0)
        sample_rate = int(info.get("defaultSampleRate", 44100))
        
        device_type = "🔴 N/A"
        if channels_in > 0:
            device_type = f"📥 INPUT ({channels_in}ch)"
        if channels_out > 0:
            device_type = f"📤 OUTPUT ({channels_out}ch)"
        if channels_in > 0 and channels_out > 0:
            device_type = f"🔄 I/O ({channels_in}→{channels_out}ch)"
        
        is_default_in = " [DEFAULT INPUT]" if i == p.get_default_input_device_info()["index"] else ""
        is_default_out = " [DEFAULT OUTPUT]" if i == p.get_default_output_device_info()["index"] else ""
        
        print(f"  [{i:2d}] {name:40} | {device_type:20} | {sample_rate}Hz{is_default_in}{is_default_out}")
        
        # Check for loopback
        name_lower = name.lower()
        if any(term in name_lower for term in ["loopback", "stereo mix", "what u hear", "lautsprecher"]):
            loopback_found = True
            print(f"       ✅ LOOPBACK DEVICE FOUND! This will capture desktop audio.")
    
    print("\n" + "="*70)
    print("📌 Diagnostic Results:\n")
    
    if loopback_found:
        print("✅ SUCCESS: Loopback device found!")
        print("   Desktop audio (games, music, system sounds) will be captured.")
    else:
        print("❌ WARNING: No loopback device found!")
        print("   Desktop audio will NOT be captured unless you enable 'Stereo Mix'.\n")
        print("   📝 HOW TO FIX THIS ON WINDOWS:\n")
        print("   1. Right-click the volume icon in system tray")
        print("   2. Select 'Sound settings'")
        print("   3. Scroll down to 'Advanced' > 'App volume & device preferences'")
        print("   4. Look for 'Stereo Mix' or 'What U Hear' or 'Lautsprecher (Loopback)'")
        print("   5. If you see it DISABLED (grayed out):")
        print("      - Go to Sound Settings > Recording tab")
        print("      - Right-click empty space > 'Show Disabled Devices'")
        print("      - Find the loopback device and right-click 'Enable'")
        print("   6. Set it as default recording device")
        print("   7. Restart XVictim\n")
    
    print("Microphone:")
    try:
        mic_idx = p.get_default_input_device_info()["index"]
        mic_info = p.get_device_info_by_index(mic_idx)
        print(f"  ✅ Available: {mic_info['name']} (ID: {mic_idx})")
    except:
        print(f"  ❌ No microphone found")
    
    print("\n" + "="*70 + "\n")
    
    p.terminate()

if __name__ == "__main__":
    diagnose_audio()
